import api from './api';

const get = (url, params) => api.get(url, { params }).then((r) => r.data);
const post = (url, body) => api.post(url, body).then((r) => r.data);
const put = (url, body) => api.put(url, body).then((r) => r.data);
const del = (url) => api.delete(url).then((r) => r.data);

export const authApi = {
  login: (email, password) => post('/auth/login', { email, password }),
  register: (form) => post('/auth/register', form),
  me: () => get('/auth/me'),
  updateProfile: (body) => put('/auth/profile', body),
  changePassword: (body) => put('/auth/password', body),
  forgotPassword: (email) => post('/auth/forgot-password', { email }),
  resetPassword: (token, password) => put(`/auth/reset-password/${token}`, { password }),
};

export const publicApi = {
  stats: () => get('/public/stats'),
  categories: () => get('/public/categories'),
};

export const expoApi = {
  list: (params) => get('/expos', params),
  get: (id) => get(`/expos/${id}`),
  booths: (id) => get(`/expos/${id}/booths`),
  sessions: (id, params) => get(`/expos/${id}/sessions`, params),
  exhibitors: (id, params) => get(`/expos/${id}/exhibitors`, params),
  registrations: (id, params) => get(`/expos/${id}/registrations`, params),
  create: (body) => post('/expos', body),
  update: (id, body) => put(`/expos/${id}`, body),
  remove: (id) => del(`/expos/${id}`),
};

export const attendeeApi = {
  agenda: () => get('/attendee/agenda'),
  register: (expoId, body) => post(`/attendee/expos/${expoId}/register`, body),
  withdrawConsent: (registrationId) => put(`/attendee/registrations/${registrationId}/consent`),
  unregister: (expoId) => del(`/attendee/expos/${expoId}/register`),
  bookmark: (sessionId) => post(`/attendee/sessions/${sessionId}/bookmark`),
  book: (sessionId) => post(`/attendee/sessions/${sessionId}/book`),
  cancelBooking: (sessionId) => del(`/attendee/sessions/${sessionId}/book`),
  visit: (exhibitorId) => post(`/exhibitors/${exhibitorId}/visit`),
};

export const exhibitorApi = {
  me: () => get('/exhibitors/me'),
  update: (body) => put('/exhibitors/me', body),
  overview: () => get('/exhibitors/me/overview'),
  schedule: () => get('/exhibitors/me/schedule'),
  apply: (expoId, note) => post('/exhibitors/me/apply', { expoId, note }),
  withdraw: (applicationId) => del(`/exhibitors/me/applications/${applicationId}`),
  reserve: (boothId) => post('/exhibitors/me/reserve', { boothId }),
  release: (boothId) => del(`/exhibitors/me/reserve/${boothId}`),
};

export const adminApi = {
  analytics: (params) => get('/admin/analytics', params),
  applications: (params) => get('/admin/applications', params),
  review: (exhibitorId, applicationId, body) => put(`/admin/applications/${exhibitorId}/${applicationId}`, body),
  updateBooth: (id, body) => put(`/admin/booths/${id}`, body),
  assignBooth: (id, exhibitorId) => put(`/admin/booths/${id}/assign`, { exhibitorId }),
  releaseBooth: (id) => put(`/admin/booths/${id}/release`),
  createSession: (body) => post('/admin/sessions', body),
  updateSession: (id, body) => put(`/admin/sessions/${id}`, body),
  deleteSession: (id) => del(`/admin/sessions/${id}`),
  users: (params) => get('/admin/users', params),
  deleteUser: (id) => del(`/admin/users/${id}`),
  registrations: (params) => get('/admin/registrations', params),
  reviewRegistration: (id, status) => put(`/admin/registrations/${id}`, { status }),
  checkIn: (token) => post('/admin/check-in', { token }),
};

export const ticketApi = {
  get: (registrationId) => get(`/tickets/${registrationId}`),
};

export const feedbackApi = {
  list: (params) => get('/feedback', params),
  create: (body) => post('/feedback', body),
  respond: (id, body) => put(`/feedback/${id}`, body),
};

export const messageApi = {
  contacts: (q) => get('/messages/contacts', { q }),
  conversations: () => get('/messages/conversations'),
  unreadCount: () => get('/messages/unread-count'),
  thread: (userId) => get(`/messages/thread/${userId}`),
  markRead: (userId) => put(`/messages/thread/${userId}/read`),
  send: (body) => post('/messages', body),
};

export const notificationApi = {
  list: (params) => get('/notifications', params),
  markRead: (id) => put(`/notifications/${id}/read`),
  markAllRead: () => put('/notifications/read-all'),
};

export const uploadApi = {
  sign: () => post('/uploads/sign'),
};
