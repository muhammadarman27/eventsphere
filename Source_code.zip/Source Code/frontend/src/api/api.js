import axios from 'axios';

export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

const api = axios.create({ baseURL: `${API_URL}/api`, timeout: 20000 });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    const url = error.config?.url || '';
    const isAuthForm = /\/auth\/(login|register|forgot-password|reset-password)/.test(url);
    if (error.response?.status === 401 && localStorage.getItem('token') && !isAuthForm) {
      window.dispatchEvent(new Event('auth:expired'));
    }
    return Promise.reject(error);
  }
);

export const errMsg = (error) => {
  if (error.code === 'ECONNABORTED') return 'The request took too long. Check your connection and try again.';
  if (!error.response) return 'Cannot reach the server. Check your connection and try again.';
  return error.response.data?.message || 'Something went wrong. Please try again.';
};

export const fieldErrors = (error) => error.response?.data?.errors || {};

export default api;
