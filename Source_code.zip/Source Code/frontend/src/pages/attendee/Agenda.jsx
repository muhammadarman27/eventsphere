import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, CalendarDays, Download, QrCode } from 'lucide-react';
import { attendeeApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useAgenda from '../../hooks/useAgenda';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import SessionCard from '../../components/SessionCard';
import { ListSkeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { dayKey, fmtDateRange, fmtDay, fmtShortDay } from '../../utils/format';
import { passName } from '../../utils/passes';
import { downloadCalendar } from '../../utils/calendar';

const TABS = [{ v: 'all', l: 'Everything' }, { v: 'tickets', l: 'Tickets' }, { v: 'saved', l: 'Bookmarked' }];

export default function Agenda() {
  const { socket, toast } = useSocket();
  const confirm = useConfirm();
  const { agenda, loading, reload, bookmarkedIds, bookedIds } = useAgenda();
  const [tab, setTab] = useState('all');
  const [busyId, setBusyId] = useState('');

  useEffect(() => {
    if (!socket) return undefined;
    socket.on('schedule-updated', reload);
    socket.on('notification', reload);
    return () => { socket.off('schedule-updated', reload); socket.off('notification', reload); };
  }, [socket, reload]);

  const groups = useMemo(() => {
    const byId = new Map();
    if (tab !== 'saved') agenda.booked.forEach((s) => byId.set(s._id, s));
    if (tab !== 'tickets') agenda.bookmarked.forEach((s) => byId.set(s._id, s));
    const map = new Map();
    [...byId.values()].sort((a, b) => new Date(a.startTime) - new Date(b.startTime)).forEach((s) => { const k = dayKey(s.startTime); map.set(k, [...(map.get(k) || []), s]); });
    return [...map.entries()];
  }, [agenda, tab]);

  const act = (sid, request, message) => async () => {
    setBusyId(sid);
    try { await request(); await reload(); toast(message, 'Agenda updated', 'success'); }
    catch (err) { toast(errMsg(err), 'Action failed', 'error'); reload(); }
    finally { setBusyId(''); }
  };

  const withdrawConsent = async (reg) => {
    try { await attendeeApi.withdrawConsent(reg._id); toast('You will not get optional event emails for this registration.', 'Consent withdrawn', 'success'); reload(); }
    catch (err) { toast(errMsg(err), 'Could not update', 'error'); }
  };

  const exportCalendar = () => {
    const unique = new Map();
    [...agenda.booked, ...agenda.bookmarked].forEach((s) => unique.set(s._id, s));
    downloadCalendar([...unique.values()].sort((a, b) => new Date(a.startTime) - new Date(b.startTime)));
  };
  const hasSessions = agenda.booked.length + agenda.bookmarked.length > 0;

  const cancelRegistration = async (expo) => {
    if (!(await confirm({ title: `Cancel registration for ${expo.title}?`, message: 'Your session tickets for this event are cancelled too.', confirmLabel: 'Cancel registration', cancelLabel: 'Keep it', tone: 'danger' }))) return;
    try { const r = await attendeeApi.unregister(expo._id); toast(r.ticketsCancelled ? `${r.ticketsCancelled} ticket(s) were cancelled too.` : 'Registration cancelled.', 'Done', 'success'); reload(); }
    catch (err) { toast(errMsg(err), 'Could not cancel', 'error'); }
  };

  return (
    <>
      <PageHeader title="My agenda" subtitle="Your registrations, session tickets and bookmarks in time order."
        actions={<button onClick={exportCalendar} disabled={!hasSessions} className="btn btn-secondary btn-sm"><Download size={15} /> Add to calendar (.ics)</button>} />

      <section aria-labelledby="regs" className="mb-8">
        <h2 id="regs" className="mb-3 text-lg font-semibold">My events</h2>
        {loading ? <ListSkeleton rows={2} /> : agenda.registrations.length === 0 ? (
          <EmptyState icon={CalendarDays} title="You are not registered for any event" text="Register to book session tickets." action={<Link to="/attendee/events" className="btn btn-primary">Discover events</Link>} />
        ) : (
          <ul className="grid gap-3 md:grid-cols-2">
            {agenda.registrations.map((reg) => {
              const { expo } = reg;
              return (
                <li key={expo._id} className="card p-4">
                  <div className="flex items-center gap-3">
                    <div className="min-w-0 flex-1"><Link to={`/attendee/events/${expo._id}`} className="block truncate font-medium hover:text-brand-dark">{expo.title}</Link><p className="text-sm text-ink-muted">{fmtDateRange(expo.startDate, expo.endDate)} · {expo.location}</p></div>
                    <Badge status={reg.status} />
                  </div>
                  <p className="mt-2 text-sm text-ink-muted">
                    {reg.day ? `${fmtShortDay(reg.day)} · ${passName(reg.passType)}` : 'Registered'}
                    {reg.status === 'pending' && ' · waiting for organizer approval'}
                    {reg.status === 'rejected' && ' · not approved by the organizer'}
                    {reg.checkedIn && ' · checked in'}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {reg.status === 'confirmed' && <Link to={`/tickets/${reg._id}`} className="btn btn-primary btn-sm"><QrCode size={15} /> QR ticket</Link>}
                    {reg.marketingConsent && <button onClick={() => withdrawConsent(reg)} className="btn btn-secondary btn-sm">Withdraw marketing consent</button>}
                    {expo.status !== 'completed' && <button onClick={() => cancelRegistration(expo)} className="btn btn-secondary btn-sm">{reg.status === 'rejected' ? 'Remove' : 'Cancel'}</button>}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="sess">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <h2 id="sess" className="text-lg font-semibold">Sessions</h2>
          <div role="group" aria-label="Filter sessions" className="flex gap-1.5">{TABS.map((t) => <button key={t.v} onClick={() => setTab(t.v)} aria-pressed={tab === t.v} className={`btn btn-sm ${tab === t.v ? 'btn-primary' : 'btn-secondary'}`}>{t.l}</button>)}</div>
        </div>
        {loading ? <ListSkeleton /> : groups.length === 0 ? (
          <EmptyState icon={Bookmark} title={tab === 'tickets' ? 'No tickets booked' : tab === 'saved' ? 'No bookmarks yet' : 'Your agenda is empty'} text="Open an event, go to Sessions and book a ticket or bookmark a talk." action={<Link to="/attendee/events" className="btn btn-secondary">Find sessions</Link>} />
        ) : groups.map(([day, list]) => (
          <div key={day} className="mb-6">
            <h3 className="mb-3 text-sm font-semibold text-ink-muted">{fmtDay(list[0].startTime)}</h3>
            <div className="space-y-3">
              {list.map((s) => (
                <SessionCard key={s._id} session={s} bookmarked={bookmarkedIds.has(s._id)} booked={bookedIds.has(s._id)} busy={busyId === s._id}
                  onBookmark={act(s._id, () => attendeeApi.bookmark(s._id), bookmarkedIds.has(s._id) ? 'Bookmark removed.' : 'Session bookmarked.')}
                  onBook={act(s._id, () => attendeeApi.book(s._id), 'Ticket booked.')} onCancel={act(s._id, () => attendeeApi.cancelBooking(s._id), 'Ticket cancelled.')} />
              ))}
            </div>
          </div>
        ))}
      </section>
    </>
  );
}
