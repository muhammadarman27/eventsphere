import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search, Store } from 'lucide-react';
import { attendeeApi, expoApi } from '../../api/services';
import useDebounce from '../../hooks/useDebounce';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import ExhibitorCard from '../../components/ExhibitorCard';
import Pagination from '../../components/Pagination';
import { CardGridSkeleton } from '../../components/Skeleton';
import { CATEGORIES } from '../../utils/constants';

export default function Exhibitors() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const expos = useFetch(() => expoApi.list({ limit: 100, sort: 'date_desc' }), []);
  const expoId = params.get('expo') || expos.data?.data?.find((e) => e.status !== 'completed')?._id || expos.data?.data?.[0]?._id || '';
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [booth, setBooth] = useState('');
  const [page, setPage] = useState(1);
  const dSearch = useDebounce(search, 350);
  const dBooth = useDebounce(booth, 350);
  useEffect(() => setPage(1), [expoId, dSearch, dBooth, category]);

  const { data, loading, error, reload } = useFetch(
    () => expoApi.exhibitors(expoId, { search: dSearch.trim(), category, booth: dBooth.trim(), page, limit: 9 }),
    [expoId, dSearch, dBooth, category, page], { enabled: !!expoId }
  );
  const list = data?.data || [];
  const filtered = dSearch || category || dBooth;

  return (
    <>
      <PageHeader title="Exhibitors" subtitle="Find companies by name, product, category or booth number." />
      {expos.error ? <ErrorState message={expos.error} onRetry={expos.reload} /> : expos.data && !expos.data.data.length ? (
        <EmptyState icon={Store} title="No events yet" text="Exhibitors are listed per event once events are published." />
      ) : (
        <>
          <div className="card mb-5 grid gap-3 p-3 md:grid-cols-[14rem_1fr_11rem_9rem]">
            <div><label htmlFor="x-expo" className="sr-only">Event</label><select id="x-expo" className="input" value={expoId} onChange={(e) => setParams({ expo: e.target.value }, { replace: true })}>{(expos.data?.data || []).map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}</select></div>
            <div className="relative"><label htmlFor="x-search" className="sr-only">Search exhibitors</label><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" /><input id="x-search" type="search" className="input pl-9" placeholder="Company or product" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
            <div><label htmlFor="x-cat" className="sr-only">Category</label><select id="x-cat" className="input" value={category} onChange={(e) => setCategory(e.target.value)}><option value="">All categories</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
            <div><label htmlFor="x-booth" className="sr-only">Booth number</label><input id="x-booth" className="input" placeholder="Booth, e.g. A2" value={booth} onChange={(e) => setBooth(e.target.value)} /></div>
          </div>

          {error ? <ErrorState message={error} onRetry={reload} /> : (loading && !data) || !expoId ? <CardGridSkeleton /> : list.length === 0 ? (
            <EmptyState icon={Store} title={filtered ? 'No exhibitors match' : 'No exhibitors yet'} text={filtered ? 'Try different search words or clear the filters.' : 'Approved exhibitors for this event will appear here.'}
              action={filtered ? <button className="btn btn-secondary" onClick={() => { setSearch(''); setCategory(''); setBooth(''); }}>Clear filters</button> : null} />
          ) : (
            <div className={`grid gap-5 sm:grid-cols-2 lg:grid-cols-3 ${loading ? 'opacity-60' : ''}`}>
              {list.map((ex) => <ExhibitorCard key={ex._id} ex={ex} onOpen={(x) => attendeeApi.visit(x._id).catch(() => {})}
                onMessage={(x) => navigate('/attendee/messages', { state: { partner: { _id: x.user, name: x.companyName, role: 'exhibitor', companyName: x.companyName } } })} />)}
            </div>
          )}
          <Pagination pagination={data?.pagination} onPage={setPage} />
        </>
      )}
    </>
  );
}
