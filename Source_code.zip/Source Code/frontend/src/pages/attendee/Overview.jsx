import { Link } from 'react-router-dom';
import { Bookmark, CalendarCheck, CalendarDays, Ticket } from 'lucide-react';
import { expoApi } from '../../api/services';
import { useAuth } from '../../context/AuthContext';
import useAgenda from '../../hooks/useAgenda';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import EventCard from '../../components/EventCard';
import SessionCard from '../../components/SessionCard';
import StatCard from '../../components/StatCard';
import { CardGridSkeleton, StatsSkeleton } from '../../components/Skeleton';
import { fmtDateTime } from '../../utils/format';

export default function Overview() {
  const { user } = useAuth();
  const { agenda, loading } = useAgenda();
  const events = useFetch(() => expoApi.list({ status: 'upcoming', limit: 6 }), []);

  const now = Date.now();
  const upcomingTickets = agenda.booked.filter((s) => new Date(s.endTime).getTime() > now);
  const next = upcomingTickets[0];
  const suggestions = (events.data?.data || []).filter((e) => !e.isRegistered).slice(0, 3);

  return (
    <>
      <PageHeader title={`Hello, ${user.name.split(' ')[0]}`} subtitle="Your events, tickets and what to do next." actions={<Link to="/attendee/events" className="btn btn-primary"><CalendarDays size={16} /> Discover events</Link>} />
      {loading ? <StatsSkeleton /> : (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Registered events" value={agenda.registrations.length} icon={CalendarCheck} tone="violet" to="/attendee/agenda" />
          <StatCard label="Session tickets" value={upcomingTickets.length} icon={Ticket} tone="indigo" hint="Upcoming" to="/attendee/agenda" />
          <StatCard label="Bookmarks" value={agenda.bookmarked.length} icon={Bookmark} tone="amber" to="/attendee/agenda" />
          <StatCard label="Next session" value={next ? new Date(next.startTime).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : 'None'} icon={Ticket} tone="emerald" hint={next ? `${next.title}, ${fmtDateTime(next.startTime)}` : 'Book a session to see it here'} />
        </div>
      )}

      <section className="mt-8">
        <h2 className="mb-3 text-lg font-semibold">Your upcoming sessions</h2>
        {upcomingTickets.length === 0 ? (
          <EmptyState icon={Ticket} title="No tickets yet" text="Register for an event, then book the sessions you want to attend." action={<Link to="/attendee/events" className="btn btn-secondary">Find an event</Link>} />
        ) : <div className="space-y-3">{upcomingTickets.slice(0, 3).map((s) => <SessionCard key={s._id} session={s} booked />)}</div>}
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-center justify-between"><h2 className="text-lg font-semibold">Events you may like</h2><Link to="/attendee/events" className="link text-sm">See all</Link></div>
        {events.loading ? <CardGridSkeleton count={3} cols="sm:grid-cols-2 lg:grid-cols-3" /> : suggestions.length === 0 ? (
          <p className="text-sm text-ink-muted">You are registered for all upcoming events, or none are published yet.</p>
        ) : <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{suggestions.map((e) => <EventCard key={e._id} event={e} basePath="/attendee/events" />)}</div>}
      </section>
    </>
  );
}
