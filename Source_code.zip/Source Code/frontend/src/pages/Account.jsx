import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Building2 } from 'lucide-react';
import PageHeader from '../components/PageHeader';
import { TextAreaField, TextField } from '../components/Fields';
import { Spinner } from '../components/Skeleton';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useSubmit from '../hooks/useSubmit';
import { authApi } from '../api/services';
import { errMsg, fieldErrors } from '../api/api';
import { hasErrors, isEmail, passwordError } from '../utils/validate';
import { ROLE_LABELS } from '../utils/constants';
import { fmtDate } from '../utils/format';

function ProfileForm() {
  const { user, updateUser } = useAuth();
  const { toast } = useSocket();
  const [form, setForm] = useState({ name: user.name, email: user.email, phone: user.phone || '', bio: user.bio || '' });
  const [errors, setErrors] = useState({});
  const set = (f) => (e) => setForm({ ...form, [f]: e.target.value });

  const [save, busy] = useSubmit(async (e) => {
    e.preventDefault();
    const next = { name: form.name.trim().length >= 2 ? '' : 'Enter your name', email: isEmail(form.email.trim()) ? '' : 'Enter a valid email address' };
    setErrors(next);
    if (hasErrors(next)) return;
    try {
      const res = await authApi.updateProfile({ ...form, name: form.name.trim(), email: form.email.trim() });
      updateUser(res.user);
      toast('Your profile was updated.', 'Profile saved', 'success');
    } catch (err) {
      setErrors(fieldErrors(err));
      toast(errMsg(err), 'Could not save profile', 'error');
    }
  });

  return (
    <form onSubmit={save} className="card space-y-4 p-5" noValidate>
      <h2 className="text-lg font-semibold">Profile</h2>
      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label="Full name" required autoComplete="name" value={form.name} error={errors.name} onChange={set('name')} />
        <TextField label="Email" type="email" required autoComplete="email" value={form.email} error={errors.email} onChange={set('email')} />
        <TextField label="Phone" type="tel" autoComplete="tel" value={form.phone} error={errors.phone} onChange={set('phone')} />
        <div>
          <span className="label">Role</span>
          <p className="input bg-slate-50 text-ink-muted">{ROLE_LABELS[user.role]}</p>
        </div>
      </div>
      <TextAreaField label="About you" rows={3} maxLength={500} value={form.bio} error={errors.bio} onChange={set('bio')} />
      <button disabled={busy} className="btn btn-primary">{busy ? <><Spinner size={16} /> Saving…</> : 'Save profile'}</button>
    </form>
  );
}

function PasswordForm() {
  const { replaceToken } = useAuth();
  const { toast } = useSocket();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const set = (f) => (e) => setForm({ ...form, [f]: e.target.value });

  const [save, busy] = useSubmit(async (e) => {
    e.preventDefault();
    const next = {
      currentPassword: form.currentPassword ? '' : 'Enter your current password',
      newPassword: passwordError(form.newPassword),
      confirm: form.confirm === form.newPassword ? '' : 'Passwords do not match',
    };
    setErrors(next);
    if (hasErrors(next)) return;
    try {
      const res = await authApi.changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword });
      replaceToken(res.token);
      setForm({ currentPassword: '', newPassword: '', confirm: '' });
      toast('Other devices were signed out.', 'Password changed', 'success');
    } catch (err) {
      setErrors(fieldErrors(err));
      toast(errMsg(err), 'Could not change password', 'error');
    }
  });

  return (
    <form onSubmit={save} className="card space-y-4 p-5" noValidate>
      <h2 className="text-lg font-semibold">Change password</h2>
      <TextField label="Current password" type="password" autoComplete="current-password" value={form.currentPassword} error={errors.currentPassword} onChange={set('currentPassword')} />
      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label="New password" type="password" autoComplete="new-password" hint="At least 8 characters, with a letter and a number." value={form.newPassword} error={errors.newPassword} onChange={set('newPassword')} />
        <TextField label="Confirm new password" type="password" autoComplete="new-password" value={form.confirm} error={errors.confirm} onChange={set('confirm')} />
      </div>
      <button disabled={busy} className="btn btn-primary">{busy ? <><Spinner size={16} /> Updating…</> : 'Update password'}</button>
    </form>
  );
}

export default function Account() {
  const { user } = useAuth();
  return (
    <>
      <PageHeader title="Account" subtitle={`Member since ${fmtDate(user.createdAt)}.`} />
      <div className="max-w-3xl space-y-6">
        {user.role === 'exhibitor' && (
          <Link to="/exhibitor/profile" className="card flex items-center gap-3 p-4 transition-shadow hover:shadow-lift">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-soft text-brand-dark"><Building2 size={20} /></span>
            <span><span className="block font-medium">Company profile</span><span className="text-sm text-ink-muted">Edit what attendees see about your company.</span></span>
          </Link>
        )}
        <ProfileForm />
        <PasswordForm />
      </div>
    </>
  );
}
