import EventsExplorer from '../components/EventsExplorer';
import EventDetail from '../components/EventDetail';
import { Breadcrumbs } from '../components/PageHeader';

export function PublicEventList() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Events' }]} />
      <h1 className="text-3xl font-semibold">Explore events</h1>
      <p className="mb-8 mt-1 max-w-2xl text-ink-muted">Search expos by name, category or date. You can browse everything without an account.</p>
      <EventsExplorer basePath="/events" />
    </div>
  );
}

export function PublicEventDetail() {
  return <EventDetail basePath="/events" rootLabel="Events" wrap />;
}
