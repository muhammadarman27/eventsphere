import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Logo from '../components/Logo';

export default function NotFound() {
  const { user } = useAuth();
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-navy-900 px-6 text-center text-white">
      <Logo />
      <p className="mt-10 text-6xl font-semibold text-brand-light">404</p>
      <h1 className="mt-3 text-2xl font-semibold">This page does not exist</h1>
      <p className="mt-2 max-w-md text-white/70">The link may be old, or the page may have moved.</p>
      <div className="mt-8 flex gap-3">
        <Link to="/" className="btn btn-light">Back to home</Link>
        {user && <Link to={`/${user.role}`} className="btn btn-outline-light">Open dashboard</Link>}
      </div>
    </div>
  );
}
