import { Link } from 'react-router-dom';
import { ArrowRight, CalendarDays } from 'lucide-react';
import { expoApi, publicApi } from '../api/services';
import useFetch from '../hooks/useFetch';
import { useAuth } from '../context/AuthContext';
import { CATEGORIES } from '../utils/constants';
import { CATEGORY_ICONS } from '../components/EventBanner';
import EventCard from '../components/EventCard';
import EmptyState from '../components/EmptyState';
import { LogoMark } from '../components/Logo';
import { CardGridSkeleton, Skeleton } from '../components/Skeleton';

const QR = '1110111100101101011101010011110100111011101101010'.split('').map((c) => c === '1');

function AccessPass() {
  return (
    <div className="relative mx-auto w-full max-w-[22rem]" aria-hidden="true">
      <div className="absolute inset-0 -rotate-6 rounded-3xl border border-gold/30" />
      <div className="relative animate-drop overflow-hidden rounded-3xl bg-gradient-to-b from-navy-700 to-navy-900 p-7 shadow-pass">
        <div className="absolute inset-y-0 left-0 w-1/3 animate-sheen bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="flex items-center justify-between">
          <LogoMark size={28} />
          <span className="rounded-full border border-gold/60 px-3 py-0.5 text-xs font-semibold tracking-widest text-gold">VIP</span>
        </div>
        <p className="mt-10 font-display text-4xl leading-none text-ivory">Muhammad Arman</p>
        <p className="mt-2 text-sm text-white/60">Head of Partnerships</p>
        <div className="my-6 border-t border-dashed border-white/20" />
        <div className="flex items-end justify-between">
          <dl className="space-y-3 text-sm">
            <div><dt className="text-white/50">Booth</dt><dd className="font-medium text-ivory">C2, Hall B</dd></div>
            <div><dt className="text-white/50">Access</dt><dd className="font-medium text-ivory">All sessions, lounge</dd></div>
          </dl>
          <div className="grid grid-cols-7 gap-[3px] rounded-lg bg-ivory p-2">
            {QR.map((on, i) => <span key={i} className={`h-2.5 w-2.5 rounded-[2px] ${on ? 'bg-navy-900' : 'bg-transparent'}`} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

const STEPS = [
  { title: 'Organizers publish', text: 'Dates, venue and capacity go in once. The booth map and the session schedule are ready to fill.' },
  { title: 'Exhibitors apply', text: 'Companies pick the spot they want on the map and hear back from the organizer.' },
  { title: 'Attendees plan their day', text: 'Register, book session seats, bookmark talks and message the exhibitors you want to meet.' },
];

export default function Landing() {
  const { user } = useAuth();
  const stats = useFetch(() => publicApi.stats(), []);
  const featured = useFetch(() => expoApi.list({ status: 'upcoming', limit: 3 }), []);
  const cats = useFetch(() => publicApi.categories(), []);
  const counts = new Map((cats.data || []).map((c) => [c.category, c.count]));

  const numbers = stats.data && [
    { label: 'Events', value: stats.data.events },
    { label: 'Upcoming', value: stats.data.upcoming },
    { label: 'Exhibitors', value: stats.data.exhibitors },
    { label: 'Attendees', value: stats.data.attendees },
    { label: 'Sessions', value: stats.data.sessions },
  ];

  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 pb-24 pt-32 text-white sm:pb-32 sm:pt-40">
        <div className="pointer-events-none absolute -right-32 top-10 h-[30rem] w-[30rem] rounded-full bg-gold/10 blur-3xl" aria-hidden="true" />
        <div className="pointer-events-none absolute -left-40 bottom-0 h-[26rem] w-[26rem] rounded-full bg-indigo-600/20 blur-3xl" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-16 px-4 sm:px-6 lg:grid-cols-[1.15fr_1fr] lg:px-8">
          <div>
            <h1 className="font-display text-5xl leading-[1.05] text-ivory sm:text-6xl lg:text-7xl">The expo floor, with your name on the guest list.</h1>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/70">
              Browse events, reserve a booth, book sessions and message the people you came to meet. Organizers, exhibitors and attendees all work from the same live floor plan.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link to="/events" className="btn btn-gold px-7 py-3 text-base">Explore events</Link>
              <Link to={user ? `/${user.role}` : '/register'} className="btn btn-outline-light px-7 py-3 text-base">{user ? 'Go to dashboard' : 'Get your pass'}</Link>
            </div>
          </div>
          <AccessPass />
        </div>
      </section>

      <section aria-label="Platform statistics" className="border-y border-gold/20 bg-navy-900">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 py-10 sm:px-6 md:grid-cols-5 lg:px-8">
          {stats.error ? <p className="col-span-full text-center text-sm text-white/60">Live numbers are unavailable right now.</p>
            : !numbers ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 opacity-20" />)
            : numbers.map((n) => (
              <div key={n.label} className="text-center md:text-left">
                <p className="font-display text-5xl tabular-nums text-gold">{n.value.toLocaleString()}</p>
                <p className="mt-1 text-sm text-white/60">{n.label}</p>
              </div>
            ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8" aria-labelledby="featured">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="featured" className="font-display text-4xl sm:text-5xl">Upcoming events</h2>
            <p className="mt-2 text-ink-muted">Registration is open.</p>
          </div>
          <Link to="/events" className="btn btn-secondary">See all events <ArrowRight size={16} aria-hidden="true" /></Link>
        </div>
        {featured.loading ? <CardGridSkeleton count={3} cols="sm:grid-cols-2 lg:grid-cols-3" />
          : featured.error || !featured.data?.data.length ? (
            <EmptyState icon={CalendarDays} title="No upcoming events yet" text="New events show up here as soon as organizers publish them." action={<Link to="/events" className="btn btn-secondary">Browse past events</Link>} />
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{featured.data.data.map((e) => <EventCard key={e._id} event={e} basePath="/events" />)}</div>
          )}
      </section>

      <section className="bg-navy-900 py-20 text-white" aria-labelledby="categories">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 id="categories" className="font-display text-4xl text-ivory sm:text-5xl">Browse by category</h2>
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            {CATEGORIES.map((c) => {
              const Icon = CATEGORY_ICONS[c];
              const n = counts.get(c) || 0;
              return (
                <Link key={c} to={`/events?category=${encodeURIComponent(c)}`} className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-4 transition-colors hover:border-gold/60 hover:bg-white/10">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40 text-gold"><Icon size={20} aria-hidden="true" /></span>
                  <span className="min-w-0"><span className="block truncate font-medium text-ivory">{c}</span><span className="text-xs text-white/50">{n} {n === 1 ? 'event' : 'events'} ahead</span></span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="mx-auto max-w-7xl scroll-mt-8 px-4 py-20 sm:px-6 lg:px-8" aria-labelledby="how">
        <h2 id="how" className="font-display text-4xl sm:text-5xl">How it works</h2>
        <ol className="mt-12 grid gap-10 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <li key={s.title} className="border-l-2 border-gold pl-6">
              <span className="font-display text-5xl text-gold-dark">{i + 1}</span>
              <h3 className="mt-3 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 leading-relaxed text-ink-muted">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      {!user && (
        <section className="px-4 pb-24 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl rounded-3xl bg-navy-950 px-6 py-16 text-center text-white ring-1 ring-gold/30 sm:px-12">
            <h2 className="font-display text-4xl text-ivory sm:text-5xl">Your seat is waiting.</h2>
            <p className="mx-auto mt-4 max-w-xl text-white/70">Create a free account as an attendee or exhibitor.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/register" className="btn btn-gold px-7 py-3">Get your pass</Link>
              <Link to="/login" className="btn btn-outline-light px-7 py-3">Log in</Link>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
