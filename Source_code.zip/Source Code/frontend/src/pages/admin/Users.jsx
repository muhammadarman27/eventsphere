import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Trash2, Users as UsersIcon } from 'lucide-react';
import { adminApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import useDebounce from '../../hooks/useDebounce';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Pagination from '../../components/Pagination';
import { ListSkeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { ROLE_LABELS } from '../../utils/constants';
import { fmtDate, initials } from '../../utils/format';

const ROLES = [{ v: '', l: 'Everyone' }, { v: 'attendee', l: 'Attendees' }, { v: 'exhibitor', l: 'Exhibitors' }, { v: 'admin', l: 'Organizers' }];

export default function Users() {
  const { user: me } = useAuth();
  const { toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const role = params.get('role') || '';
  const page = Number(params.get('page')) || 1;
  const [search, setSearch] = useState('');
  const debounced = useDebounce(search, 350);

  const update = (patch, keepPage = false) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!keepPage) next.delete('page');
    setParams(next, { replace: true });
  };
  const { data, loading, error, reload, refresh } = useFetch(() => adminApi.users({ role, search: debounced.trim(), page, limit: 10 }), [role, debounced, page]);
  useEffect(() => { if (page > 1 && data && data.data.length === 0) update({ page: String(page - 1) }, true); }, [data]);
  const users = data?.data || [];

  const remove = async (u) => {
    const ok = await confirm({
      title: `Delete ${u.name}?`,
      message: u.role === 'exhibitor' ? 'Their company profile is removed, their booths are released and their messages are deleted. This cannot be undone.' : 'Their registrations, tickets, bookmarks and messages are removed. This cannot be undone.',
      confirmLabel: 'Delete user', tone: 'danger',
    });
    if (!ok) return;
    try { await adminApi.deleteUser(u._id); toast(`${u.name} was deleted.`, 'User deleted', 'success'); refresh(); }
    catch (err) { toast(errMsg(err), 'Could not delete user', 'error'); }
  };

  return (
    <>
      <PageHeader title="Users" subtitle="Everyone who has an account on this platform." />
      <div className="card mb-5 flex flex-wrap items-center gap-3 p-3">
        <div className="relative min-w-[14rem] flex-1"><label htmlFor="u-search" className="sr-only">Search users</label><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          <input id="u-search" type="search" className="input pl-9" placeholder="Search by name or email" value={search} onChange={(e) => { setSearch(e.target.value); update({}); }} /></div>
        <div role="group" aria-label="Filter by role" className="flex flex-wrap gap-1.5">{ROLES.map((r) => <button key={r.v} onClick={() => update({ role: r.v })} aria-pressed={role === r.v} className={`btn btn-sm ${role === r.v ? 'btn-primary' : 'btn-secondary'}`}>{r.l}</button>)}</div>
      </div>

      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <ListSkeleton rows={6} /> : users.length === 0 ? (
        <EmptyState icon={UsersIcon} title="No users found" text="Try a different search or role." />
      ) : (
        <>
          <p className="mb-3 text-sm text-ink-muted" aria-live="polite">{data.pagination.total} {data.pagination.total === 1 ? 'user' : 'users'}</p>
          <ul className={`card divide-y divide-slate-100 ${loading ? 'opacity-60' : ''}`}>
            {users.map((u) => (
              <li key={u._id} className="flex items-center gap-3 p-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-brand text-xs font-semibold text-white" aria-hidden="true">{initials(u.name)}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{u.name}{u._id === me.id && <span className="ml-2 text-xs text-ink-muted">(you)</span>}</p>
                  <p className="truncate text-sm text-ink-muted">{u.email}{u.companyName ? ` · ${u.companyName}` : ''}</p>
                </div>
                <div className="hidden text-right text-xs text-ink-muted sm:block">Joined {fmtDate(u.createdAt)}</div>
                <Badge status={u.role === 'admin' ? 'booked' : u.role === 'exhibitor' ? 'upcoming' : 'available'}>{ROLE_LABELS[u.role]}</Badge>
                {u.role !== 'admin' && u._id !== me.id && <button onClick={() => remove(u)} className="btn btn-ghost btn-icon btn-sm text-rose-600 hover:bg-rose-50" aria-label={`Delete ${u.name}`}><Trash2 size={16} /></button>}
              </li>
            ))}
          </ul>
        </>
      )}
      <Pagination pagination={data?.pagination} onPage={(p) => update({ page: p === 1 ? '' : String(p) }, true)} />
    </>
  );
}
