import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CalendarDays, Eye, EyeOff, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useDebounce from '../../hooks/useDebounce';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Pagination from '../../components/Pagination';
import { ListSkeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { fmtDateRange } from '../../utils/format';

const FILTERS = [
  { value: '', label: 'All' },
  { value: 'draft', label: 'Drafts' },
  { value: 'upcoming', label: 'Upcoming' },
  { value: 'ongoing', label: 'Live now' },
  { value: 'completed', label: 'Ended' },
];

export default function Events() {
  const { toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const status = params.get('status') || '';
  const page = Number(params.get('page')) || 1;
  const q = params.get('q') || '';
  const [qInput, setQInput] = useState(q);
  const debounced = useDebounce(qInput, 350);
  const [busyId, setBusyId] = useState('');

  const update = (patch, keepPage = false) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!keepPage) next.delete('page');
    setParams(next, { replace: true });
  };
  useEffect(() => { if (debounced.trim() !== q) update({ q: debounced.trim() }); }, [debounced]);

  const { data, loading, error, reload, refresh } = useFetch(() => expoApi.list({ search: q, status, page, limit: 8, sort: 'newest' }), [q, status, page]);
  const events = data?.data || [];

  const togglePublish = async (e) => {
    const publishing = !e.published;
    const ok = await confirm({
      title: publishing ? 'Publish this event?' : 'Unpublish this event?',
      message: publishing ? 'It becomes visible to everyone, including people who are not logged in.' : 'It will be hidden from the public. Existing registrations are kept.',
      confirmLabel: publishing ? 'Publish' : 'Unpublish',
    });
    if (!ok) return;
    setBusyId(e._id);
    try {
      await expoApi.update(e._id, { published: publishing });
      toast(publishing ? `"${e.title}" is now public.` : `"${e.title}" is now a draft.`, publishing ? 'Published' : 'Unpublished', 'success');
      refresh();
    } catch (err) { toast(errMsg(err), 'Could not update event', 'error'); } finally { setBusyId(''); }
  };

  const remove = async (e) => {
    const ok = await confirm({
      title: `Delete "${e.title}"?`,
      message: `This permanently removes the event with its booths, sessions and registrations${e.registeredCount ? `. ${e.registeredCount} registered attendee(s) will be notified` : ''}. This cannot be undone.`,
      confirmLabel: 'Delete event', tone: 'danger',
    });
    if (!ok) return;
    setBusyId(e._id);
    try {
      await expoApi.remove(e._id);
      toast(`"${e.title}" was deleted.`, 'Deleted', 'success');
      if (events.length === 1 && page > 1) update({ page: String(page - 1) }, true); else refresh();
    } catch (err) { toast(errMsg(err), 'Could not delete event', 'error'); } finally { setBusyId(''); }
  };

  const actions = (e) => (
    <div className="flex items-center gap-1">
      <Link to={`/admin/events/${e._id}`} className="btn btn-ghost btn-sm" aria-label={`Open ${e.title}`}>Manage</Link>
      <Link to={`/admin/events/${e._id}/edit`} className="btn btn-ghost btn-icon btn-sm" aria-label={`Edit ${e.title}`}><Pencil size={16} /></Link>
      <button onClick={() => togglePublish(e)} disabled={busyId === e._id} className="btn btn-ghost btn-icon btn-sm" aria-label={e.published ? `Unpublish ${e.title}` : `Publish ${e.title}`}>{e.published ? <EyeOff size={16} /> : <Eye size={16} />}</button>
      <button onClick={() => remove(e)} disabled={busyId === e._id} className="btn btn-ghost btn-icon btn-sm text-rose-600 hover:bg-rose-50 hover:text-rose-700" aria-label={`Delete ${e.title}`}><Trash2 size={16} /></button>
    </div>
  );

  return (
    <>
      <PageHeader title="Events" subtitle="Create, publish and manage your expos."
        actions={<Link to="/admin/events/new" className="btn btn-primary"><Plus size={16} /> New event</Link>} />

      <div className="card mb-5 flex flex-wrap items-center gap-3 p-3">
        <div className="relative min-w-[14rem] flex-1">
          <label htmlFor="ae-search" className="sr-only">Search events</label>
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          <input id="ae-search" type="search" className="input pl-9" placeholder="Search events" value={qInput} onChange={(e) => setQInput(e.target.value)} />
        </div>
        <div role="group" aria-label="Filter by status" className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => <button key={f.value} onClick={() => update({ status: f.value })} aria-pressed={status === f.value} className={`btn btn-sm ${status === f.value ? 'btn-primary' : 'btn-secondary'}`}>{f.label}</button>)}
        </div>
        {(q || status) && <button onClick={() => { setQInput(''); setParams({}, { replace: true }); }} className="btn btn-ghost btn-sm"><X size={15} /> Clear</button>}
      </div>

      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <ListSkeleton rows={5} /> : events.length === 0 ? (
        <EmptyState icon={CalendarDays} title={q || status ? 'No events match your filters' : 'No events yet'} text={q || status ? 'Try another search or clear the filters.' : 'Create your first event. Its booth floor plan is generated automatically.'}
          action={!q && !status ? <Link to="/admin/events/new" className="btn btn-primary"><Plus size={16} /> Create event</Link> : null} />
      ) : (
        <>
          <div className={`card hidden overflow-hidden md:block ${loading ? 'opacity-60' : ''}`}>
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 bg-slate-50/70"><tr><th className="th">Event</th><th className="th">Dates</th><th className="th">Registered</th><th className="th">Status</th><th className="th"><span className="sr-only">Actions</span></th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {events.map((e) => (
                  <tr key={e._id} className="hover:bg-slate-50/60">
                    <td className="td"><Link to={`/admin/events/${e._id}`} className="font-medium hover:text-brand-dark">{e.title}</Link><p className="text-xs text-ink-muted">{e.category}, {e.location}</p></td>
                    <td className="td whitespace-nowrap">{fmtDateRange(e.startDate, e.endDate)}</td>
                    <td className="td tabular-nums">{e.registeredCount}{e.capacity ? ` / ${e.capacity}` : ''}</td>
                    <td className="td"><Badge status={e.status} /></td>
                    <td className="td">{actions(e)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <ul className={`space-y-3 md:hidden ${loading ? 'opacity-60' : ''}`}>
            {events.map((e) => (
              <li key={e._id} className="card p-4">
                <div className="flex items-start justify-between gap-3"><Link to={`/admin/events/${e._id}`} className="font-medium">{e.title}</Link><Badge status={e.status} /></div>
                <p className="mt-1 text-sm text-ink-muted">{fmtDateRange(e.startDate, e.endDate)} · {e.location}</p>
                <p className="text-sm text-ink-muted">{e.registeredCount}{e.capacity ? ` of ${e.capacity}` : ''} registered</p>
                <div className="mt-2 -ml-2">{actions(e)}</div>
              </li>
            ))}
          </ul>
        </>
      )}
      <Pagination pagination={data?.pagination} onPage={(p) => update({ page: p === 1 ? '' : String(p) }, true)} />
    </>
  );
}
