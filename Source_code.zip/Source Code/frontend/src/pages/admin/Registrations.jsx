import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Users } from 'lucide-react';
import { adminApi, expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSocketRefresh from '../../hooks/useSocketRefresh';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Pagination from '../../components/Pagination';
import { ListSkeleton } from '../../components/Skeleton';
import { fmtShortDay, timeAgo } from '../../utils/format';
import { passName } from '../../utils/passes';

const FILTERS = ['all', 'pending', 'confirmed', 'rejected'];

export default function Registrations() {
  const { socket, toast } = useSocket();
  const [params, setParams] = useSearchParams();
  const status = FILTERS.includes(params.get('status')) ? params.get('status') : 'pending';
  const expo = params.get('expo') || '';
  const page = Number(params.get('page')) || 1;
  const [busyId, setBusyId] = useState('');

  const events = useFetch(() => expoApi.list({ limit: 100, sort: 'newest' }), []);
  const { data, loading, error, reload, refresh } = useFetch(
    () => adminApi.registrations({ status: status === 'all' ? '' : status, expo, page, limit: 10 }),
    [status, expo, page]
  );
  useSocketRefresh(socket, ['notification'], refresh);

  const update = (patch) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!('page' in patch)) next.delete('page');
    setParams(next, { replace: true });
  };

  const review = async (r, decision) => {
    setBusyId(r._id);
    try {
      const res = await adminApi.reviewRegistration(r._id, decision);
      toast(decision === 'confirmed' ? `Confirmed. ${res.emailStatus === 'sent' ? 'Ticket emailed.' : 'The attendee was notified in the app.'}` : 'Registration rejected.', 'Done', 'success');
      refresh();
    } catch (err) { toast(errMsg(err), 'Could not update', 'error'); refresh(); }
    finally { setBusyId(''); }
  };

  const summary = data?.summary || { pending: 0, confirmed: 0, rejected: 0 };
  const count = (s) => (s === 'all' ? summary.pending + summary.confirmed + summary.rejected : summary[s]);
  const rows = data?.data || [];

  return (
    <>
      <PageHeader title="Registrations" subtitle="Review attendee requests. Confirming a request issues the attendee's QR ticket." />
      <div className="card mb-5 flex flex-wrap items-center gap-3 p-4">
        <div role="group" aria-label="Filter by status" className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button key={f} onClick={() => update({ status: f })} aria-pressed={status === f} className={`btn btn-sm capitalize ${status === f ? 'btn-primary' : 'btn-secondary'}`}>{f} ({count(f)})</button>
          ))}
        </div>
        <div className="ml-auto min-w-[12rem]">
          <label htmlFor="reg-expo" className="sr-only">Event</label>
          <select id="reg-expo" className="input py-1.5" value={expo} onChange={(e) => update({ expo: e.target.value })}>
            <option value="">All events</option>
            {(events.data?.data || []).map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}
          </select>
        </div>
      </div>

      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <ListSkeleton /> : rows.length === 0 ? (
        <EmptyState icon={Users} title="No registrations here" text={status === 'pending' ? 'No requests are waiting for review.' : 'Nothing matches this filter.'} />
      ) : (
        <ul className="space-y-3">
          {rows.map((r) => (
            <li key={r._id} className="card flex flex-wrap items-start gap-4 p-4">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{r.fullName}</h3><Badge status={r.status} />{r.checkedInAt && <Badge status="booked">Checked in</Badge>}</div>
                <p className="text-sm text-ink-muted">{r.expo.title}{r.day ? ` · ${fmtShortDay(r.day)}` : ''} · {passName(r.passType)}</p>
                <p className="text-sm text-ink-muted">{r.email}{r.phone ? ` · ${r.phone}` : ''}</p>
                {(r.company || r.jobTitle) && <p className="text-sm text-ink-muted">{[r.company, r.jobTitle].filter(Boolean).join(' · ')}</p>}
                <p className="mt-1 text-xs text-slate-400">Requested {timeAgo(r.registeredAt)}{r.emailStatus ? ` · ticket email: ${r.emailStatus}` : ''}</p>
              </div>
              {r.status === 'pending' && (
                <div className="flex gap-2">
                  <button className="btn btn-primary btn-sm" disabled={busyId === r._id} onClick={() => review(r, 'confirmed')}>{busyId === r._id ? 'Saving…' : 'Confirm'}</button>
                  <button className="btn btn-secondary btn-sm" disabled={busyId === r._id} onClick={() => review(r, 'rejected')}>Reject</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
      <Pagination pagination={data?.pagination} onPage={(p) => update({ page: p === 1 ? '' : String(p) })} />
    </>
  );
}
