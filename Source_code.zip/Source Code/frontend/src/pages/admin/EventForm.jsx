import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { expoApi } from '../../api/services';
import { errMsg, fieldErrors } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import EventBanner from '../../components/EventBanner';
import ErrorState from '../../components/ErrorState';
import ImageUpload from '../../components/ImageUpload';
import { SelectField, TextAreaField, TextField } from '../../components/Fields';
import { Skeleton, Spinner } from '../../components/Skeleton';
import { CATEGORIES } from '../../utils/constants';
import { toInputDate } from '../../utils/format';
import { hasErrors, isHttpUrl } from '../../utils/validate';

const blank = {
  title: '', category: 'General', theme: '', banner: '', description: '', location: '', venue: '', address: '',
  startDate: '', endDate: '', openTime: '09:00', closeTime: '18:00', capacity: '0', rows: '4', columns: '6', published: false,
};

function validate(f, editing) {
  const e = {};
  if (f.title.trim().length < 3) e.title = 'Enter a title of at least 3 characters';
  if (f.location.trim().length < 2) e.location = 'Enter the city or area';
  if (!f.startDate) e.startDate = 'Choose a start date';
  if (!f.endDate) e.endDate = 'Choose an end date';
  if (f.startDate && f.endDate && f.endDate < f.startDate) e.endDate = 'End date must be on or after the start date';
  if (f.startDate && f.startDate === f.endDate && f.closeTime <= f.openTime) e.closeTime = 'Closing time must be after opening time';
  if (f.banner.trim() && !isHttpUrl(f.banner.trim())) e.banner = 'Enter a full link starting with http:// or https://';
  if (!/^\d+$/.test(String(f.capacity)) || Number(f.capacity) > 1000000) e.capacity = 'Enter a whole number (0 means unlimited)';
  if (!editing) {
    if (!(Number(f.rows) >= 1 && Number(f.rows) <= 10)) e.rows = 'Between 1 and 10';
    if (!(Number(f.columns) >= 1 && Number(f.columns) <= 12)) e.columns = 'Between 1 and 12';
  }
  return e;
}

function Form({ initial, editing, id }) {
  const navigate = useNavigate();
  const { toast } = useSocket();
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const [save, busy] = useSubmit(async (ev) => {
    ev.preventDefault();
    const next = validate(form, editing);
    setErrors(next);
    if (hasErrors(next)) { toast('Please fix the highlighted fields.', 'Check the form', 'error'); return; }
    const body = {
      title: form.title.trim(), category: form.category, theme: form.theme.trim(), banner: form.banner.trim(),
      description: form.description.trim(), location: form.location.trim(), venue: form.venue.trim(), address: form.address.trim(),
      startDate: form.startDate, endDate: form.endDate, openTime: form.openTime, closeTime: form.closeTime,
      capacity: Number(form.capacity), published: form.published,
    };
    if (!editing) { body.rows = Number(form.rows); body.columns = Number(form.columns); }
    try {
      const saved = editing ? await expoApi.update(id, body) : await expoApi.create(body);
      toast(editing ? 'Your changes were saved.' : 'The event and its booth grid were created.', editing ? 'Event saved' : 'Event created', 'success');
      navigate(`/admin/events/${saved._id}`);
    } catch (err) {
      setErrors(fieldErrors(err));
      toast(errMsg(err), 'Could not save event', 'error');
    }
  });

  return (
    <form onSubmit={save} noValidate className="grid gap-6 lg:grid-cols-[1fr_20rem]">
      <div className="space-y-6">
        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-semibold">Basics</h2>
          <TextField label="Event title" required value={form.title} error={errors.title} onChange={set('title')} maxLength={120} />
          <div className="grid gap-4 sm:grid-cols-2">
            <SelectField label="Category" value={form.category} error={errors.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</SelectField>
            <TextField label="Theme" value={form.theme} error={errors.theme} onChange={set('theme')} maxLength={120} placeholder="e.g. AI for Everyone" />
          </div>
          <TextAreaField label="Description" rows={5} maxLength={5000} value={form.description} error={errors.description} onChange={set('description')} hint="Tell people what to expect." />
        </section>

        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-semibold">When and where</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField label="Start date" type="date" required value={form.startDate} error={errors.startDate} onChange={set('startDate')} />
            <TextField label="End date" type="date" required min={form.startDate || undefined} value={form.endDate} error={errors.endDate} onChange={set('endDate')} />
            <TextField label="Doors open" type="time" value={form.openTime} error={errors.openTime} onChange={set('openTime')} />
            <TextField label="Doors close" type="time" value={form.closeTime} error={errors.closeTime} onChange={set('closeTime')} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField label="City or area" required value={form.location} error={errors.location} onChange={set('location')} maxLength={160} />
            <TextField label="Venue" value={form.venue} error={errors.venue} onChange={set('venue')} maxLength={160} placeholder="e.g. Expo Centre" />
          </div>
          <TextField label="Address" value={form.address} error={errors.address} onChange={set('address')} maxLength={300} />
        </section>

        <section className="card space-y-4 p-5">
          <h2 className="text-lg font-semibold">Capacity and floor plan</h2>
          <TextField label="Attendee capacity" type="number" min="0" value={form.capacity} error={errors.capacity} onChange={set('capacity')} hint="Maximum registrations. Use 0 for no limit." />
          {editing ? (
            <p className="rounded-lg bg-slate-50 p-3 text-sm text-ink-muted">The floor plan ({form.rows} rows by {form.columns} columns) is fixed after creation so booth reservations stay valid.</p>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField label="Booth rows" type="number" min="1" max="10" value={form.rows} error={errors.rows} onChange={set('rows')} />
              <TextField label="Booth columns" type="number" min="1" max="12" value={form.columns} error={errors.columns} onChange={set('columns')} />
            </div>
          )}
        </section>
      </div>

      <aside className="space-y-6 lg:sticky lg:top-24 lg:self-start">
        <section className="card overflow-hidden">
          <EventBanner event={{ title: form.title || 'New event', category: form.category, banner: isHttpUrl(form.banner.trim()) ? form.banner.trim() : '' }} className="h-36" />
          <div className="space-y-3 p-4">
            <ImageUpload value={form.banner} onChange={(url) => setForm({ ...form, banner: url })} label="Upload banner" />
            <TextField label="Or paste an image link" value={form.banner} error={errors.banner} onChange={set('banner')} placeholder="https://…" hint="Optional. A generated banner is used when empty." />
          </div>
        </section>
        <section className="card space-y-4 p-5">
          <label className="flex cursor-pointer items-start gap-3">
            <input type="checkbox" className="mt-1 h-4 w-4 rounded border-slate-300 text-brand focus:ring-brand" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} />
            <span><span className="block text-sm font-medium">Publish this event</span><span className="text-xs text-ink-muted">Published events are visible to everyone. Leave unchecked to keep it as a draft.</span></span>
          </label>
          <button disabled={busy} className="btn btn-primary w-full">{busy ? <><Spinner size={16} /> Saving…</> : editing ? 'Save changes' : 'Create event'}</button>
          <button type="button" onClick={() => navigate(-1)} disabled={busy} className="btn btn-secondary w-full">Cancel</button>
        </section>
      </aside>
    </form>
  );
}

export default function EventForm() {
  const { id } = useParams();
  const editing = !!id;
  const { data, error, reload } = useFetch(() => expoApi.get(id), [id], { enabled: editing });
  const crumbs = [{ label: 'Events', to: '/admin/events' }, { label: editing ? 'Edit event' : 'New event' }];

  if (editing && error) return <><PageHeader title="Edit event" breadcrumbs={crumbs} /><ErrorState message={error} onRetry={reload} /></>;
  if (editing && !data) return <><PageHeader title="Edit event" breadcrumbs={crumbs} /><Skeleton className="h-96" /></>;

  const initial = editing
    ? {
        ...blank, title: data.title, category: data.category || 'General', theme: data.theme || '', banner: data.banner || '', description: data.description || '',
        location: data.location, venue: data.venue || '', address: data.address || '', startDate: toInputDate(data.startDate), endDate: toInputDate(data.endDate),
        openTime: data.openTime || '09:00', closeTime: data.closeTime || '18:00', capacity: String(data.capacity || 0),
        rows: String(data.floorPlan.rows), columns: String(data.floorPlan.columns), published: data.published,
      }
    : blank;

  return (
    <>
      <PageHeader title={editing ? 'Edit event' : 'New event'} subtitle={editing ? data.title : 'Fill in the details. You can publish now or save it as a draft.'} breadcrumbs={crumbs} />
      <Form initial={initial} editing={editing} id={id} />
    </>
  );
}
