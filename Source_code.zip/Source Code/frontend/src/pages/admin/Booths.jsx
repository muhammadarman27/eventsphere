import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Store } from 'lucide-react';
import { adminApi, expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSocketRefresh from '../../hooks/useSocketRefresh';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import BoothDetail from '../../components/BoothDetail';
import BoothGrid from '../../components/BoothGrid';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Modal from '../../components/Modal';
import { SelectField, TextField } from '../../components/Fields';
import { Skeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';

function AssignModal({ booth, expoId, onClose, onDone }) {
  const { toast } = useSocket();
  const [exhibitorId, setExhibitorId] = useState('');
  const apps = useFetch(() => adminApi.applications({ expo: expoId, limit: 50 }), [expoId]);
  const candidates = [...new Map((apps.data?.data || []).filter((a) => a.status !== 'rejected').map((a) => [a.exhibitorId, a])).values()];

  const [assign, busy] = useSubmit(async () => {
    if (!exhibitorId) return;
    try { const res = await adminApi.assignBooth(booth._id, exhibitorId); toast(res.message, 'Booth assigned', 'success'); onDone(); }
    catch (err) { toast(errMsg(err), 'Could not assign booth', 'error'); }
  });

  return (
    <Modal open onClose={onClose} busy={busy} title={`Assign booth ${booth.boothNumber}`} description="Only exhibitors with an active application for this event can be assigned."
      footer={<><button className="btn btn-secondary" onClick={onClose} disabled={busy}>Cancel</button><button className="btn btn-primary" onClick={assign} disabled={busy || !exhibitorId}>{busy ? 'Assigning…' : 'Assign booth'}</button></>}>
      {apps.error ? <ErrorState message={apps.error} onRetry={apps.reload} /> : (
        <SelectField label="Exhibitor" value={exhibitorId} onChange={(e) => setExhibitorId(e.target.value)}
          hint={!apps.loading && candidates.length === 0 ? 'No exhibitor has an active application for this event yet.' : 'Assigning approves their application.'}>
          <option value="">{apps.loading ? 'Loading…' : 'Choose an exhibitor'}</option>
          {candidates.map((a) => <option key={a.exhibitorId} value={a.exhibitorId}>{a.companyName} ({a.status})</option>)}
        </SelectField>
      )}
    </Modal>
  );
}

export default function Booths() {
  const { socket, toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const expos = useFetch(() => expoApi.list({ limit: 100, sort: 'newest' }), []);
  const expoId = params.get('expo') || expos.data?.data?.[0]?._id || '';
  const expo = expos.data?.data?.find((x) => x._id === expoId);

  const booths = useFetch(() => expoApi.booths(expoId), [expoId], { enabled: !!expoId });
  const [selectedId, setSelectedId] = useState(null);
  const [assigning, setAssigning] = useState(false);
  const [edit, setEdit] = useState({ price: '', size: 'small' });
  useSocketRefresh(socket, ['booths-updated'], booths.refresh);

  const list = booths.data || [];
  const selected = list.find((b) => b._id === selectedId) || null;
  useEffect(() => { if (selected) setEdit({ price: String(selected.price), size: selected.size }); }, [selected?._id, selected?.price, selected?.size]);
  useEffect(() => setSelectedId(null), [expoId]);

  const counts = list.reduce((c, b) => ({ ...c, [b.status]: (c[b.status] || 0) + 1 }), { available: 0, reserved: 0, booked: 0 });

  const [savePrice, saving] = useSubmit(async (ev) => {
    ev.preventDefault();
    if (!/^\d+$/.test(edit.price)) { toast('Enter the price as a whole number.', 'Check the price', 'error'); return; }
    try { await adminApi.updateBooth(selected._id, { price: Number(edit.price), size: edit.size }); toast(`Booth ${selected.boothNumber} was updated.`, 'Saved', 'success'); booths.refresh(); }
    catch (err) { toast(errMsg(err), 'Could not update booth', 'error'); }
  });

  const release = async () => {
    const ok = await confirm({ title: `Release booth ${selected.boothNumber}?`, message: selected.exhibitor ? `${selected.exhibitor.companyName} loses this booth and is notified. An approved application goes back to pending.` : 'The booth becomes available again.', confirmLabel: 'Release booth', tone: 'danger' });
    if (!ok) return;
    try { const res = await adminApi.releaseBooth(selected._id); toast(res.message, 'Booth released', 'success'); booths.refresh(); }
    catch (err) { toast(errMsg(err), 'Could not release booth', 'error'); booths.refresh(); }
  };

  return (
    <>
      <PageHeader title="Booths" subtitle="See the floor plan, assign booths and release them." />
      {expos.error ? <ErrorState message={expos.error} onRetry={expos.reload} /> : expos.data && expos.data.data.length === 0 ? (
        <EmptyState icon={Store} title="Create an event first" text="Every event gets its own booth floor plan." />
      ) : (
        <>
          <div className="mb-5 max-w-sm">
            <label htmlFor="b-expo" className="label">Event</label>
            <select id="b-expo" className="input" value={expoId} onChange={(e) => setParams({ expo: e.target.value }, { replace: true })}>
              {(expos.data?.data || []).map((x) => <option key={x._id} value={x._id}>{x.title}</option>)}
            </select>
          </div>

          {booths.error ? <ErrorState message={booths.error} onRetry={booths.reload} /> : !expo || (booths.loading && !booths.data) ? <Skeleton className="h-72" /> : (
            <div className="grid gap-6 lg:grid-cols-[1fr_21rem]">
              <section className="card p-5">
                <p className="mb-4 text-sm text-ink-muted">{counts.available} available, {counts.reserved} reserved, {counts.booked} booked of {list.length}</p>
                <BoothGrid booths={list} columns={expo.floorPlan.columns} selectedId={selectedId} onSelect={(b) => setSelectedId(b._id)} />
              </section>
              <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
                <BoothDetail booth={selected} showVisits>
                  {selected && selected.status === 'available' && <button className="btn btn-primary btn-sm" onClick={() => setAssigning(true)}>Assign to exhibitor</button>}
                  {selected && selected.status !== 'available' && <button className="btn btn-secondary btn-sm text-rose-600" onClick={release}>Release booth</button>}
                </BoothDetail>
                {selected && (
                  <form onSubmit={savePrice} className="card space-y-3 p-4">
                    <h3 className="text-sm font-semibold">Price and size</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <TextField label="Price ($)" type="number" min="0" value={edit.price} onChange={(e) => setEdit({ ...edit, price: e.target.value })} />
                      <SelectField label="Size" value={edit.size} onChange={(e) => setEdit({ ...edit, size: e.target.value })}><option value="small">Small</option><option value="medium">Medium</option><option value="large">Large</option></SelectField>
                    </div>
                    <button className="btn btn-secondary btn-sm" disabled={saving}>{saving ? 'Saving…' : 'Save booth'}</button>
                  </form>
                )}
              </aside>
            </div>
          )}
        </>
      )}
      {assigning && selected && <AssignModal booth={selected} expoId={expoId} onClose={() => setAssigning(false)} onDone={() => { setAssigning(false); booths.refresh(); }} />}
    </>
  );
}
