import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, ScanLine, XCircle } from 'lucide-react';
import { adminApi } from '../../api/services';
import { errMsg } from '../../api/api';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import { TextField } from '../../components/Fields';
import { fmtDateTime, fmtShortDay } from '../../utils/format';

export default function CheckIn() {
  const [params, setParams] = useSearchParams();
  const [code, setCode] = useState(params.get('token') || '');
  const [result, setResult] = useState(null);

  const [submit, busy] = useSubmit(async (value) => {
    setResult(null);
    try {
      const r = await adminApi.checkIn(value.trim());
      setResult({ ok: true, text: `Checked in: ${r.name}`, detail: `${r.event}${r.day ? ` · ${fmtShortDay(r.day)}` : ''} · ${fmtDateTime(r.checkedInAt)}` });
      setCode('');
    } catch (err) {
      setResult({ ok: false, text: errMsg(err) });
    }
    if (params.get('token')) setParams({}, { replace: true });
  });

  useEffect(() => {
    const t = params.get('token');
    if (t) submit(t);
  }, []);

  return (
    <>
      <PageHeader title="Ticket check-in" subtitle="Scan a ticket's QR code with your phone camera, or type the 8-character ticket number printed under the QR." />
      <form className="card max-w-xl space-y-4 p-5" onSubmit={(e) => { e.preventDefault(); if (code.trim()) submit(code); }}>
        <TextField label="Ticket number or QR link" required value={code} onChange={(e) => setCode(e.target.value)} placeholder="e.g. 3F9A12BC" autoComplete="off" data-autofocus />
        <button className="btn btn-primary" disabled={busy || !code.trim()}><ScanLine size={16} /> {busy ? 'Checking…' : 'Validate & check in'}</button>
      </form>
      {result && (
        <div role="status" className={`mt-4 flex max-w-xl items-start gap-3 rounded-xl p-4 ${result.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-700'}`}>
          {result.ok ? <CheckCircle2 size={22} /> : <XCircle size={22} />}
          <div><p className="font-semibold">{result.text}</p>{result.detail && <p className="text-sm">{result.detail}</p>}</div>
        </div>
      )}
    </>
  );
}
