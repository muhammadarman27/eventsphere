import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Building2, CalendarDays, ClipboardList, Clock, MessageSquare, RefreshCw, Store, Ticket, UserPlus, Users } from 'lucide-react';
import { adminApi } from '../../api/services';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSocketRefresh from '../../hooks/useSocketRefresh';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import { AreaChart, BarList, DonutChart } from '../../components/Charts';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import { Skeleton, StatsSkeleton } from '../../components/Skeleton';
import { fmtDate, isoDaysAgo, timeAgo, todayIso } from '../../utils/format';

const PRESETS = [{ days: 7, label: '7 days' }, { days: 30, label: '30 days' }, { days: 90, label: '90 days' }];
const ACTIVITY_ICONS = { application: ClipboardList, registration: Ticket, signup: UserPlus };

function Panel({ title, subtitle, children, className = '', action }) {
  return (
    <section className={`card p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div><h2 className="text-base font-semibold">{title}</h2>{subtitle && <p className="text-sm text-ink-muted">{subtitle}</p>}</div>
        {action}
      </div>
      {children}
    </section>
  );
}

export default function Dashboard() {
  const { socket } = useSocket();
  const [preset, setPreset] = useState(30);
  const [custom, setCustom] = useState({ from: '', to: '' });
  const useCustom = preset === 0 && custom.from && custom.to;
  const from = useCustom ? custom.from : isoDaysAgo((preset || 30) - 1);
  const to = useCustom ? custom.to : todayIso();

  const { data, loading, error, reload, refresh } = useFetch(() => adminApi.analytics({ from, to }), [from, to]);
  const [refreshing, setRefreshing] = useState(false);
  const [updatedAt, setUpdatedAt] = useState(null);
  useEffect(() => { if (data) setUpdatedAt(new Date()); }, [data]);

  useSocketRefresh(socket, ['notification', 'booths-updated'], refresh);
  useEffect(() => {
    const t = setInterval(() => { if (document.visibilityState === 'visible') refresh(); }, 60000);
    return () => clearInterval(t);
  }, [refresh]);

  const manualRefresh = async () => { setRefreshing(true); await refresh(); setRefreshing(false); };

  const range = (
    <div className="flex flex-wrap items-end gap-2">
      <div role="group" aria-label="Date range" className="flex gap-1.5">
        {PRESETS.map((p) => <button key={p.days} onClick={() => setPreset(p.days)} aria-pressed={preset === p.days} className={`btn btn-sm ${preset === p.days ? 'btn-primary' : 'btn-secondary'}`}>{p.label}</button>)}
        <button onClick={() => setPreset(0)} aria-pressed={preset === 0} className={`btn btn-sm ${preset === 0 ? 'btn-primary' : 'btn-secondary'}`}>Custom</button>
      </div>
      {preset === 0 && (
        <>
          <div><label htmlFor="d-from" className="sr-only">From</label><input id="d-from" type="date" className="input py-1.5" value={custom.from} max={custom.to || todayIso()} onChange={(e) => setCustom({ ...custom, from: e.target.value })} /></div>
          <div><label htmlFor="d-to" className="sr-only">To</label><input id="d-to" type="date" className="input py-1.5" value={custom.to} min={custom.from} max={todayIso()} onChange={(e) => setCustom({ ...custom, to: e.target.value })} /></div>
        </>
      )}
      <button onClick={manualRefresh} disabled={refreshing || loading} className="btn btn-secondary btn-sm" aria-label="Refresh data"><RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} /> Refresh</button>
    </div>
  );

  const header = <PageHeader title="Dashboard" subtitle={updatedAt ? `Live numbers from your database. Updated ${timeAgo(updatedAt)}.` : 'Live numbers from your database.'} actions={range} />;

  if (error) return <>{header}<ErrorState message={error} onRetry={reload} /></>;
  if (!data) return <>{header}<StatsSkeleton /><div className="mt-6 grid gap-6 lg:grid-cols-3"><Skeleton className="h-72 lg:col-span-2" /><Skeleton className="h-72" /></div></>;

  const { totals, booths, applications, sessionStats, registrationsSeries, signupsSeries, eventsByCategory, sessionPopularity, boothTraffic, recentActivity } = data;
  const regTotal = registrationsSeries.reduce((s, d) => s + d.value, 0);
  const signupTotal = signupsSeries.reduce((s, d) => s + d.value, 0);

  return (
    <>
      {header}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Registered attendees" value={totals.attendees} icon={Users} tone="violet" hint={`${totals.registrations} event registrations`} to="/admin/users?role=attendee" />
        <StatCard label="Events" value={totals.expos} icon={CalendarDays} tone="indigo" hint={`${totals.upcomingExpos} upcoming, ${totals.liveExpos} live, ${totals.draftExpos} draft`} to="/admin/events" />
        <StatCard label="Exhibitors" value={totals.exhibitors} icon={Building2} tone="sky" hint={`${applications.approved} approved applications`} to="/admin/users?role=exhibitor" />
        <StatCard label="Pending applications" value={totals.pendingApplications} icon={ClipboardList} tone={totals.pendingApplications ? 'amber' : 'emerald'} hint={totals.pendingApplications ? 'Waiting for your review' : 'Nothing waiting'} to="/admin/applications?status=pending" />
        <StatCard label="Booths available" value={booths.available} icon={Store} tone="emerald" hint={`${booths.total} booths in total`} to="/admin/booths" />
        <StatCard label="Booths reserved" value={booths.reserved} icon={Store} tone="amber" hint="Waiting for approval" to="/admin/booths" />
        <StatCard label="Booths booked" value={booths.booked} icon={Store} tone="indigo" hint={booths.total ? `${Math.round((booths.booked / booths.total) * 100)}% of all booths` : 'No booths yet'} to="/admin/booths" />
        <StatCard label="Session tickets" value={sessionStats.tickets} icon={Ticket} tone="violet" hint={`${sessionStats.fillRate}% of ${sessionStats.seats} seats, ${sessionStats.bookmarks} bookmarks`} to="/admin/sessions" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Panel title="Event registrations" subtitle={`${regTotal} in the selected period`} className="lg:col-span-2">
          {regTotal === 0 ? <EmptyState icon={Ticket} title="No registrations in this period" text="Try a longer date range." /> : <AreaChart data={registrationsSeries} label="Event registrations per day" unit="registrations" />}
        </Panel>
        <Panel title="Booth status" subtitle="All events">
          {booths.total === 0 ? <EmptyState icon={Store} title="No booths yet" text="Booths are created with each event." /> : (
            <DonutChart centerLabel="Booths" segments={[
              { label: 'Available', value: booths.available, color: '#CBD5E1' },
              { label: 'Reserved', value: booths.reserved, color: '#F59E0B' },
              { label: 'Booked', value: booths.booked, color: '#6D5BFF' },
            ]} />
          )}
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Panel title="New sign-ups" subtitle={`${signupTotal} new accounts in the period`}>
          {signupTotal === 0 ? <p className="py-8 text-center text-sm text-ink-muted">No new accounts in this period.</p> : <AreaChart data={signupsSeries} color="#4F46E5" height={140} label="New accounts per day" unit="accounts" />}
        </Panel>
        <Panel title="Applications" subtitle="By decision">
          {applications.pending + applications.approved + applications.rejected === 0 ? <p className="py-8 text-center text-sm text-ink-muted">No applications yet.</p> : (
            <DonutChart centerLabel="Applications" segments={[
              { label: 'Pending', value: applications.pending, color: '#F59E0B' },
              { label: 'Approved', value: applications.approved, color: '#10B981' },
              { label: 'Rejected', value: applications.rejected, color: '#F43F5E' },
            ]} />
          )}
        </Panel>
        <Panel title="Events by category" subtitle="Published events">
          {eventsByCategory.length === 0 ? <p className="py-8 text-center text-sm text-ink-muted">No published events yet.</p> : <BarList items={eventsByCategory.map((c) => ({ label: c.category, value: c.count, sub: c.count }))} />}
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel title="Session popularity" subtitle="Tickets booked plus bookmarks">
          {sessionPopularity.length === 0 ? <EmptyState icon={Clock} title="No sessions yet" text="Create sessions in the Schedule page." action={<Link to="/admin/sessions" className="btn btn-secondary btn-sm">Open schedule</Link>} /> : (
            <BarList items={sessionPopularity.map((s) => ({ label: s.title, value: s.tickets + s.bookmarks, sub: `${s.tickets}/${s.capacity} tickets, ${s.bookmarks} bookmarks` }))} />
          )}
        </Panel>
        <Panel title="Booth traffic" subtitle="Attendees who opened an exhibitor's details (once per day each)">
          {boothTraffic.length === 0 ? <EmptyState icon={Store} title="No booth visits yet" text="Visits appear when attendees view exhibitors." /> : (
            <BarList color="from-sky-500 to-indigo-500" items={boothTraffic.map((b) => ({ label: `${b.boothNumber} ${b.company}`, value: b.visits, sub: `${b.visits} visits` }))} />
          )}
        </Panel>
      </div>

      <Panel title="Recent activity" subtitle={`${totals.messages} messages sent in total`} className="mt-6" action={<MessageSquare size={18} className="text-slate-300" aria-hidden="true" />}>
        {recentActivity.length === 0 ? <p className="py-6 text-center text-sm text-ink-muted">Nothing has happened yet.</p> : (
          <ul className="divide-y divide-slate-100">
            {recentActivity.map((a, i) => {
              const Icon = ACTIVITY_ICONS[a.type] || Clock;
              return (
                <li key={i} className="flex items-center gap-3 py-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-soft text-brand-dark"><Icon size={16} aria-hidden="true" /></span>
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{a.title}</span><span className="block truncate text-xs text-ink-muted">{a.detail}</span></span>
                  <span className="shrink-0 text-xs text-slate-400" title={fmtDate(a.at)}>{timeAgo(a.at)}</span>
                </li>
              );
            })}
          </ul>
        )}
      </Panel>
    </>
  );
}
