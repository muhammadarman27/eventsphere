import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ClipboardList, Search } from 'lucide-react';
import { adminApi, expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useDebounce from '../../hooks/useDebounce';
import useFetch from '../../hooks/useFetch';
import useSocketRefresh from '../../hooks/useSocketRefresh';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Modal from '../../components/Modal';
import Pagination from '../../components/Pagination';
import { SelectField, TextAreaField } from '../../components/Fields';
import { ListSkeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { fmtDate } from '../../utils/format';

const TABS = [{ v: 'pending', l: 'Pending' }, { v: 'approved', l: 'Approved' }, { v: 'rejected', l: 'Rejected' }, { v: '', l: 'All' }];

function ReviewModal({ row, onClose, onDone }) {
  const { toast } = useSocket();
  const [boothId, setBoothId] = useState(row.boothId || '');
  const [note, setNote] = useState('');
  const booths = useFetch(() => expoApi.booths(row.expoId), [row.expoId]);
  const options = (booths.data || []).filter((b) => b.status === 'available' || b._id === row.boothId);

  const [decide, busy] = useSubmit(async (status) => {
    if (status === 'approved' && !boothId) { toast('Choose a booth before approving.', 'Booth needed', 'error'); return; }
    try {
      await adminApi.review(row.exhibitorId, row.applicationId, { status, boothId: boothId || undefined, reviewNote: note.trim() });
      toast(`${row.companyName} was ${status}.`, `Application ${status}`, 'success');
      onDone();
    } catch (err) { toast(errMsg(err), 'Could not update application', 'error'); booths.refresh(); }
  });

  return (
    <Modal open onClose={onClose} busy={busy} title={`Review ${row.companyName}`} description={`Application for ${row.expoTitle}`}
      footer={<>
        <button className="btn btn-secondary" onClick={onClose} disabled={busy}>Cancel</button>
        {row.status !== 'rejected' && <button className="btn btn-secondary text-rose-600" onClick={() => decide('rejected')} disabled={busy}>Reject</button>}
        <button className="btn btn-primary" onClick={() => decide('approved')} disabled={busy}>{busy ? 'Saving…' : 'Approve'}</button>
      </>}>
      <div className="space-y-4">
        {row.note && <div className="rounded-lg bg-slate-50 p-3 text-sm"><p className="mb-1 text-xs font-medium text-ink-muted">Message from the exhibitor</p>{row.note}</div>}
        <SelectField label="Booth" required value={boothId} onChange={(e) => setBoothId(e.target.value)} hint={row.boothId ? 'The exhibitor reserved this booth. You can choose another.' : 'The exhibitor has not reserved a booth. Choose one for them.'}>
          <option value="">{booths.loading ? 'Loading booths…' : 'Choose a booth'}</option>
          {options.map((b) => <option key={b._id} value={b._id}>{b.boothNumber} ({b.size}, ${b.price}){b._id === row.boothId ? ' (requested)' : ''}</option>)}
        </SelectField>
        <TextAreaField label="Note to the exhibitor (optional)" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
    </Modal>
  );
}

export default function Applications() {
  const { toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const status = params.has('status') ? params.get('status') : 'pending';
  const expo = params.get('expo') || '';
  const page = Number(params.get('page')) || 1;
  const [search, setSearch] = useState('');
  const debounced = useDebounce(search, 350);
  const [reviewing, setReviewing] = useState(null);

  const update = (patch, keepPage = false) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v === null ? next.delete(k) : next.set(k, v)));
    if (!keepPage) next.delete('page');
    setParams(next, { replace: true });
  };

  const expos = useFetch(() => expoApi.list({ limit: 100, sort: 'newest' }), []);
  const { data, loading, error, reload, refresh } = useFetch(
    () => adminApi.applications({ status, expo, search: debounced.trim(), page, limit: 8 }),
    [status, expo, debounced, page]
  );
  useEffect(() => { if (page > 1 && data && data.data.length === 0) update({ page: String(page - 1) }, true); }, [data]);
  useSocketRefresh(useSocket().socket, ['notification', 'booths-updated'], refresh);

  const rows = data?.data || [];
  const counts = data?.counts;

  const revoke = async (row) => {
    const ok = await confirm({ title: `Revoke ${row.companyName}?`, message: `Their booth ${row.boothNumber || ''} is released and they are told the application was rejected.`, confirmLabel: 'Revoke', tone: 'danger' });
    if (!ok) return;
    try { await adminApi.review(row.exhibitorId, row.applicationId, { status: 'rejected' }); toast(`${row.companyName} was revoked.`, 'Application updated', 'success'); refresh(); }
    catch (err) { toast(errMsg(err), 'Could not revoke', 'error'); }
  };

  const rowActions = (r) => (
    <div className="flex gap-2">
      {r.status !== 'approved' && <button onClick={() => setReviewing(r)} className="btn btn-primary btn-sm">{r.status === 'rejected' ? 'Reconsider' : 'Review'}</button>}
      {r.status === 'approved' && <button onClick={() => revoke(r)} className="btn btn-secondary btn-sm">Revoke</button>}
    </div>
  );

  return (
    <>
      <PageHeader title="Exhibitor applications" subtitle="Approve exhibitors and confirm their booth." />

      <div className="card mb-5 space-y-3 p-3">
        <div className="grid gap-3 md:grid-cols-[1fr_16rem]">
          <div className="relative">
            <label htmlFor="ap-search" className="sr-only">Search applications</label>
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
            <input id="ap-search" type="search" className="input pl-9" placeholder="Search company or event" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div>
            <label htmlFor="ap-expo" className="sr-only">Filter by event</label>
            <select id="ap-expo" className="input" value={expo} onChange={(e) => update({ expo: e.target.value || null })}>
              <option value="">All events</option>
              {(expos.data?.data || []).map((x) => <option key={x._id} value={x._id}>{x.title}</option>)}
            </select>
          </div>
        </div>
        <div role="group" aria-label="Filter by status" className="flex flex-wrap gap-1.5">
          {TABS.map((t) => (
            <button key={t.v} onClick={() => update({ status: t.v })} aria-pressed={status === t.v} className={`btn btn-sm ${status === t.v ? 'btn-primary' : 'btn-secondary'}`}>
              {t.l}{counts ? <span className="ml-1 opacity-75">({t.v ? counts[t.v] : counts.all})</span> : null}
            </button>
          ))}
        </div>
      </div>

      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <ListSkeleton rows={5} /> : rows.length === 0 ? (
        <EmptyState icon={ClipboardList} title="No applications here" text={status === 'pending' ? 'You are all caught up. New applications appear here and in your notifications.' : 'No applications match these filters.'} />
      ) : (
        <>
          <div className={`card hidden overflow-hidden md:block ${loading ? 'opacity-60' : ''}`}>
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 bg-slate-50/70"><tr><th className="th">Company</th><th className="th">Event</th><th className="th">Applied</th><th className="th">Booth</th><th className="th">Status</th><th className="th"><span className="sr-only">Actions</span></th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((r) => (
                  <tr key={r.applicationId}>
                    <td className="td"><p className="font-medium">{r.companyName}</p><p className="text-xs text-ink-muted">{r.category}</p></td>
                    <td className="td">{r.expoTitle}</td>
                    <td className="td whitespace-nowrap text-ink-muted">{fmtDate(r.appliedAt)}</td>
                    <td className="td">{r.boothNumber ? <Badge status={r.status === 'approved' ? 'booked' : 'reserved'}>{r.boothNumber}</Badge> : <span className="text-ink-muted">None</span>}</td>
                    <td className="td"><Badge status={r.status} /></td>
                    <td className="td">{rowActions(r)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <ul className={`space-y-3 md:hidden ${loading ? 'opacity-60' : ''}`}>
            {rows.map((r) => (
              <li key={r.applicationId} className="card p-4">
                <div className="flex items-start justify-between gap-3"><div><p className="font-medium">{r.companyName}</p><p className="text-xs text-ink-muted">{r.category}</p></div><Badge status={r.status} /></div>
                <p className="mt-2 text-sm text-ink-muted">{r.expoTitle} · applied {fmtDate(r.appliedAt)}</p>
                <p className="text-sm text-ink-muted">Booth: {r.boothNumber || 'none yet'}</p>
                <div className="mt-3">{rowActions(r)}</div>
              </li>
            ))}
          </ul>
        </>
      )}
      <Pagination pagination={data?.pagination} onPage={(p) => update({ page: p === 1 ? null : String(p) }, true)} />
      {reviewing && <ReviewModal row={reviewing} onClose={() => setReviewing(null)} onDone={() => { setReviewing(null); refresh(); }} />}
    </>
  );
}
