import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { CalendarCheck, ExternalLink, Eye, EyeOff, Pencil, Store, Ticket, Trash2, Users } from 'lucide-react';
import { expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import EventBanner from '../../components/EventBanner';
import Pagination from '../../components/Pagination';
import StatCard from '../../components/StatCard';
import { Skeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { fmtDateRange, fmtDateTime } from '../../utils/format';

function Registrations({ id }) {
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch(() => expoApi.registrations(id, { page, limit: 8 }), [id, page]);
  return (
    <section className="card">
      <div className="border-b border-slate-100 px-5 py-4"><h2 className="text-base font-semibold">Registered attendees</h2></div>
      {error ? <div className="p-5"><ErrorState message={error} onRetry={reload} /></div> : loading && !data ? <Skeleton className="m-5 h-32" /> : !data.data.length ? (
        <div className="p-5"><EmptyState icon={Users} title="No registrations yet" text="Attendees who register for this event are listed here." /></div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50/70"><tr><th className="th">Name</th><th className="th">Email</th><th className="th">Registered</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {data.data.map((r) => <tr key={r._id}><td className="td font-medium">{r.user.name}</td><td className="td text-ink-muted">{r.user.email}</td><td className="td whitespace-nowrap text-ink-muted">{fmtDateTime(r.registeredAt)}</td></tr>)}
              </tbody>
            </table>
          </div>
          <div className="px-5 pb-4"><Pagination pagination={data.pagination} onPage={setPage} /></div>
        </>
      )}
    </section>
  );
}

export default function EventAdmin() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useSocket();
  const confirm = useConfirm();
  const { data: e, error, reload, refresh } = useFetch(() => expoApi.get(id), [id]);
  const crumbs = [{ label: 'Events', to: '/admin/events' }, { label: e ? e.title : 'Event' }];

  if (error) return <><PageHeader title="Event" breadcrumbs={crumbs} /><ErrorState message={error} onRetry={reload} /></>;
  if (!e) return <><PageHeader title="Event" breadcrumbs={crumbs} /><Skeleton className="h-72" /></>;

  const togglePublish = async () => {
    const publishing = !e.published;
    if (!(await confirm({ title: publishing ? 'Publish this event?' : 'Unpublish this event?', message: publishing ? 'It becomes visible to everyone.' : 'It will be hidden from the public.', confirmLabel: publishing ? 'Publish' : 'Unpublish' }))) return;
    try { await expoApi.update(id, { published: publishing }); toast(publishing ? 'The event is now public.' : 'The event is now a draft.', publishing ? 'Published' : 'Unpublished', 'success'); refresh(); }
    catch (err) { toast(errMsg(err), 'Could not update event', 'error'); }
  };
  const complete = async () => {
    if (!(await confirm({ title: 'Mark as completed?', message: 'The event will be shown as ended and registration will close.', confirmLabel: 'Mark completed' }))) return;
    try { await expoApi.update(id, { status: 'completed' }); toast('The event is marked as completed.', 'Updated', 'success'); refresh(); }
    catch (err) { toast(errMsg(err), 'Could not update event', 'error'); }
  };
  const remove = async () => {
    if (!(await confirm({ title: `Delete "${e.title}"?`, message: 'This permanently removes the event with its booths, sessions and registrations. This cannot be undone.', confirmLabel: 'Delete event', tone: 'danger' }))) return;
    try { await expoApi.remove(id); toast('The event was deleted.', 'Deleted', 'success'); navigate('/admin/events', { replace: true }); }
    catch (err) { toast(errMsg(err), 'Could not delete event', 'error'); }
  };

  return (
    <>
      <PageHeader title={e.title} breadcrumbs={crumbs} subtitle={`${e.category}, ${e.venue ? `${e.venue}, ` : ''}${e.location}`}
        actions={
          <>
            <Link to={`/admin/events/${id}/edit`} className="btn btn-secondary btn-sm"><Pencil size={15} /> Edit</Link>
            <button onClick={togglePublish} className="btn btn-secondary btn-sm">{e.published ? <><EyeOff size={15} /> Unpublish</> : <><Eye size={15} /> Publish</>}</button>
            {e.status !== 'completed' && e.published && <button onClick={complete} className="btn btn-secondary btn-sm"><CalendarCheck size={15} /> Mark completed</button>}
            <button onClick={remove} className="btn btn-secondary btn-sm text-rose-600"><Trash2 size={15} /> Delete</button>
          </>
        } />

      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard label="Registered" value={e.registeredCount} icon={Users} hint={e.capacity ? `of ${e.capacity} places` : 'No capacity limit'} />
            <StatCard label="Sessions" value={e.sessionCount} icon={Ticket} tone="indigo" to={`/admin/sessions?expo=${id}`} hint="Open schedule" />
            <StatCard label="Exhibitors" value={e.exhibitorCount} icon={Store} tone="sky" to={`/admin/applications?expo=${id}`} hint="Open applications" />
            <StatCard label="Booths free" value={`${e.booths.available}/${e.booths.total}`} icon={Store} tone="emerald" to={`/admin/booths?expo=${id}`} hint={`${e.booths.reserved} reserved, ${e.booths.booked} booked`} />
          </div>
          <Registrations id={id} />
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="card overflow-hidden">
            <EventBanner event={e} className="h-32" />
            <div className="space-y-3 p-4 text-sm">
              <div className="flex items-center justify-between"><span className="text-ink-muted">Status</span><Badge status={e.status} /></div>
              <div className="flex items-start justify-between gap-3"><span className="text-ink-muted">Dates</span><span className="text-right font-medium">{fmtDateRange(e.startDate, e.endDate)}</span></div>
              <div className="flex items-center justify-between"><span className="text-ink-muted">Hours</span><span className="font-medium">{e.openTime} to {e.closeTime}</span></div>
              <div className="flex items-center justify-between"><span className="text-ink-muted">Page views</span><span className="font-medium">{e.views}</span></div>
              {e.published && <a href={`/events/${id}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm w-full"><ExternalLink size={15} /> View public page</a>}
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
