import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Bookmark, Clock, MapPin, Pencil, Plus, Search, Ticket, Trash2 } from 'lucide-react';
import { adminApi, expoApi } from '../../api/services';
import { errMsg, fieldErrors } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import Modal from '../../components/Modal';
import { TextAreaField, TextField } from '../../components/Fields';
import { Skeleton } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { dayKey, fmtDay, fmtTime, sessionPhase, toInputDateTime } from '../../utils/format';
import { hasErrors } from '../../utils/validate';

const empty = { title: '', speakerName: '', speakerBio: '', location: '', startTime: '', endTime: '', capacity: '100', description: '' };

function SessionForm({ expoId, session, onClose, onDone }) {
  const { toast } = useSocket();
  const [form, setForm] = useState(session ? {
    title: session.title, speakerName: session.speaker.name, speakerBio: session.speaker.bio || '', location: session.location,
    startTime: toInputDateTime(session.startTime), endTime: toInputDateTime(session.endTime), capacity: String(session.capacity), description: session.description || '',
  } : empty);
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const [save, busy] = useSubmit(async (ev) => {
    ev.preventDefault();
    const next = {
      title: form.title.trim().length >= 3 ? '' : 'Enter a title of at least 3 characters',
      speakerName: form.speakerName.trim().length >= 2 ? '' : 'Enter the speaker name',
      location: form.location.trim() ? '' : 'Enter the room or hall',
      startTime: form.startTime ? '' : 'Choose a start time',
      endTime: !form.endTime ? 'Choose an end time' : form.startTime && new Date(form.endTime) <= new Date(form.startTime) ? 'End time must be after the start time' : '',
      capacity: /^\d+$/.test(form.capacity) && Number(form.capacity) >= 1 ? '' : 'Enter at least 1 seat',
    };
    setErrors(next);
    if (hasErrors(next)) return;
    const body = {
      expo: expoId, title: form.title.trim(), speakerName: form.speakerName.trim(), speakerBio: form.speakerBio.trim(), location: form.location.trim(),
      startTime: new Date(form.startTime).toISOString(), endTime: new Date(form.endTime).toISOString(), capacity: Number(form.capacity), description: form.description.trim(),
    };
    try {
      if (session) await adminApi.updateSession(session._id, body); else await adminApi.createSession(body);
      toast(session ? 'Session updated. Attendees who booked or bookmarked it were notified.' : 'Session added to the schedule.', 'Saved', 'success');
      onDone();
    } catch (err) { setErrors(fieldErrors(err)); toast(errMsg(err), 'Could not save session', 'error'); }
  });

  return (
    <Modal open onClose={onClose} busy={busy} size="lg" title={session ? 'Edit session' : 'New session'}
      footer={<><button type="button" className="btn btn-secondary" onClick={onClose} disabled={busy}>Cancel</button><button form="session-form" className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : session ? 'Save changes' : 'Add session'}</button></>}>
      <form id="session-form" onSubmit={save} noValidate className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2"><TextField label="Title" required value={form.title} error={errors.title} onChange={set('title')} maxLength={140} /></div>
        <TextField label="Speaker" required value={form.speakerName} error={errors.speakerName} onChange={set('speakerName')} />
        <TextField label="Speaker role" value={form.speakerBio} error={errors.speakerBio} onChange={set('speakerBio')} placeholder="e.g. Security engineer" />
        <TextField label="Starts" type="datetime-local" required value={form.startTime} error={errors.startTime} onChange={set('startTime')} />
        <TextField label="Ends" type="datetime-local" required min={form.startTime || undefined} value={form.endTime} error={errors.endTime} onChange={set('endTime')} />
        <TextField label="Room or hall" required value={form.location} error={errors.location} onChange={set('location')} />
        <TextField label="Seats" type="number" min="1" value={form.capacity} error={errors.capacity} onChange={set('capacity')} hint={session ? `${session.attendeeCount} already booked.` : undefined} />
        <div className="sm:col-span-2"><TextAreaField label="Description" rows={3} maxLength={3000} value={form.description} error={errors.description} onChange={set('description')} /></div>
      </form>
    </Modal>
  );
}

export default function Sessions() {
  const { socket, toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const expos = useFetch(() => expoApi.list({ limit: 100, sort: 'newest' }), []);
  const expoId = params.get('expo') || expos.data?.data?.[0]?._id || '';
  const sessions = useFetch(() => expoApi.sessions(expoId), [expoId], { enabled: !!expoId });
  const [form, setForm] = useState(null);
  const [search, setSearch] = useState('');
  const [when, setWhen] = useState('all');

  useEffect(() => {
    if (!socket) return undefined;
    const h = () => sessions.refresh();
    socket.on('schedule-updated', h);
    return () => socket.off('schedule-updated', h);
  }, [socket, expoId]);

  const groups = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = (sessions.data || []).filter((s) => {
      if (when === 'upcoming' && sessionPhase(s) === 'ended') return false;
      if (when === 'past' && sessionPhase(s) !== 'ended') return false;
      return !q || `${s.title} ${s.speaker.name} ${s.location}`.toLowerCase().includes(q);
    });
    const map = new Map();
    filtered.forEach((s) => { const k = dayKey(s.startTime); map.set(k, [...(map.get(k) || []), s]); });
    return [...map.entries()];
  }, [sessions.data, search, when]);

  const remove = async (s) => {
    const ok = await confirm({ title: `Delete "${s.title}"?`, message: `${s.attendeeCount} ticket holder(s) and anyone who bookmarked it will be notified.`, confirmLabel: 'Delete session', tone: 'danger' });
    if (!ok) return;
    try { await adminApi.deleteSession(s._id); toast('The session was deleted.', 'Deleted', 'success'); sessions.refresh(); }
    catch (err) { toast(errMsg(err), 'Could not delete session', 'error'); }
  };

  return (
    <>
      <PageHeader title="Schedule" subtitle="Changes reach attendees who booked or bookmarked a session right away."
        actions={<button onClick={() => setForm('new')} disabled={!expoId} className="btn btn-primary"><Plus size={16} /> New session</button>} />

      {expos.error ? <ErrorState message={expos.error} onRetry={expos.reload} /> : expos.data && expos.data.data.length === 0 ? (
        <EmptyState icon={Clock} title="Create an event first" text="Sessions belong to an event." />
      ) : (
        <>
          <div className="card mb-5 grid gap-3 p-3 md:grid-cols-[16rem_1fr_auto]">
            <div><label htmlFor="s-expo" className="sr-only">Event</label>
              <select id="s-expo" className="input" value={expoId} onChange={(e) => setParams({ expo: e.target.value }, { replace: true })}>{(expos.data?.data || []).map((x) => <option key={x._id} value={x._id}>{x.title}</option>)}</select></div>
            <div className="relative"><label htmlFor="s-search" className="sr-only">Search sessions</label><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
              <input id="s-search" type="search" className="input pl-9" placeholder="Search title, speaker or room" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
            <div role="group" aria-label="Show sessions" className="flex gap-1.5">{[['all', 'All'], ['upcoming', 'Upcoming'], ['past', 'Past']].map(([v, l]) => <button key={v} onClick={() => setWhen(v)} aria-pressed={when === v} className={`btn btn-sm ${when === v ? 'btn-primary' : 'btn-secondary'}`}>{l}</button>)}</div>
          </div>

          {sessions.error ? <ErrorState message={sessions.error} onRetry={sessions.reload} /> : sessions.loading && !sessions.data ? <Skeleton className="h-48" /> : groups.length === 0 ? (
            <EmptyState icon={Clock} title={search || when !== 'all' ? 'No sessions match' : 'No sessions yet'} text={search || when !== 'all' ? 'Change the search or filter.' : 'Add the first session for this event.'}
              action={!search && when === 'all' ? <button onClick={() => setForm('new')} className="btn btn-primary"><Plus size={16} /> Add session</button> : null} />
          ) : (
            <div className="space-y-8">
              {groups.map(([day, list]) => (
                <section key={day} aria-label={fmtDay(list[0].startTime)}>
                  <h2 className="mb-3 text-sm font-semibold text-ink-muted">{fmtDay(list[0].startTime)}</h2>
                  <ul className="space-y-3">
                    {list.map((s) => {
                      const phase = sessionPhase(s);
                      return (
                        <li key={s._id} className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                          <div className="shrink-0 sm:w-24"><p className="font-semibold tabular-nums">{fmtTime(s.startTime)}</p><p className="text-xs text-ink-muted">to {fmtTime(s.endTime)}</p></div>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{s.title}</h3>{phase !== 'upcoming' && <Badge status={phase} />}</div>
                            <p className="text-sm text-ink-muted">{s.speaker.name}{s.speaker.bio ? `, ${s.speaker.bio}` : ''}</p>
                            <p className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-muted">
                              <span className="flex items-center gap-1"><MapPin size={12} /> {s.location}</span>
                              <span className="flex items-center gap-1"><Ticket size={12} /> {s.attendeeCount}/{s.capacity} booked</span>
                              <span className="flex items-center gap-1"><Bookmark size={12} /> {s.bookmarkCount} bookmarks</span>
                            </p>
                          </div>
                          <div className="flex gap-1">
                            <button onClick={() => setForm(s)} className="btn btn-secondary btn-icon btn-sm" aria-label={`Edit ${s.title}`}><Pencil size={16} /></button>
                            <button onClick={() => remove(s)} className="btn btn-secondary btn-icon btn-sm text-rose-600" aria-label={`Delete ${s.title}`}><Trash2 size={16} /></button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </section>
              ))}
            </div>
          )}
        </>
      )}
      {form && <SessionForm expoId={expoId} session={form === 'new' ? null : form} onClose={() => setForm(null)} onDone={() => { setForm(null); sessions.refresh(); }} />}
    </>
  );
}
