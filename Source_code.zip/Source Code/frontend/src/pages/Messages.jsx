import Messaging from '../components/Messaging';
import PageHeader from '../components/PageHeader';

export default function Messages() {
  return (
    <>
      <PageHeader title="Messages" subtitle="Private conversations. Only you and the other person can read them." />
      <Messaging />
    </>
  );
}
