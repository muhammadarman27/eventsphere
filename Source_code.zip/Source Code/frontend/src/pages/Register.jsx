import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import AuthShell from '../components/AuthShell';
import { TextField } from '../components/Fields';
import { Spinner } from '../components/Skeleton';
import { useAuth } from '../context/AuthContext';
import useSubmit from '../hooks/useSubmit';
import { errMsg, fieldErrors } from '../api/api';
import { hasErrors, isEmail, passwordError } from '../utils/validate';

const roles = [
  { value: 'attendee', label: 'Attendee', text: 'Browse expos, book sessions, message exhibitors' },
  { value: 'exhibitor', label: 'Exhibitor', text: 'Apply for booths and show your products' },
];

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'attendee', companyName: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const [submit, busy] = useSubmit(async (e) => {
    e.preventDefault();
    setFormError('');
    const next = {
      name: form.name.trim().length >= 2 ? '' : 'Enter your full name',
      email: isEmail(form.email.trim()) ? '' : 'Enter a valid email address',
      password: passwordError(form.password),
      companyName: form.role === 'exhibitor' && !form.companyName.trim() ? 'Enter your company name' : '',
    };
    setErrors(next);
    if (hasErrors(next)) return;
    try {
      const created = await register({ ...form, name: form.name.trim(), email: form.email.trim() });
      navigate(`/${created.role}`, { replace: true });
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errMsg(err));
    }
  });

  if (user) return <Navigate to={`/${user.role}`} replace />;

  return (
    <AuthShell title="Create your account" subtitle="Pick the role that matches how you will use EventSphere.">
      <form onSubmit={submit} className="space-y-4" noValidate>
        {formError && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{formError}</p>}

        <fieldset>
          <legend className="label">I am joining as</legend>
          <div className="grid gap-2">
            {roles.map((r) => (
              <button type="button" key={r.value} aria-pressed={form.role === r.value} onClick={() => setForm({ ...form, role: r.value })}
                className={`rounded-lg border p-3 text-left transition-colors ${form.role === r.value ? 'border-brand bg-brand-soft ring-2 ring-brand/20' : 'border-slate-300 bg-white hover:border-brand/50'}`}>
                <span className="block text-sm font-semibold">{r.label}</span>
                <span className="block text-xs text-ink-muted">{r.text}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <TextField label="Full name" autoComplete="name" required value={form.name} error={errors.name} onChange={set('name')} />
        {form.role === 'exhibitor' && <TextField label="Company name" required value={form.companyName} error={errors.companyName} onChange={set('companyName')} />}
        <TextField label="Email" type="email" autoComplete="email" required value={form.email} error={errors.email} onChange={set('email')} />
        <TextField label="Password" type="password" autoComplete="new-password" required hint="At least 8 characters, with a letter and a number." value={form.password} error={errors.password} onChange={set('password')} />

        <button disabled={busy} className="btn btn-primary w-full">{busy ? <><Spinner size={16} /> Creating account…</> : 'Create account'}</button>
        <p className="text-sm">Already have an account? <Link to="/login" className="link">Log in</Link></p>
      </form>
    </AuthShell>
  );
}
