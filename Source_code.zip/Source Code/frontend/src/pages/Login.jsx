import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import AuthShell from '../components/AuthShell';
import { TextField } from '../components/Fields';
import { Spinner } from '../components/Skeleton';
import { useAuth } from '../context/AuthContext';
import useSubmit from '../hooks/useSubmit';
import { errMsg } from '../api/api';
import { isEmail } from '../utils/validate';

const destination = (from, role) => {
  const path = from?.pathname || '';
  const allowed = path.startsWith(`/${role}`) || path.startsWith('/events');
  return allowed ? `${path}${from.search || ''}` : `/${role}`;
};

export default function Login() {
  const { user, login, sessionExpired } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');

  const [submit, busy] = useSubmit(async (e) => {
    e.preventDefault();
    setFormError('');
    const next = {
      email: isEmail(form.email.trim()) ? '' : 'Enter a valid email address',
      password: form.password ? '' : 'Enter your password',
    };
    setErrors(next);
    if (next.email || next.password) return;
    try {
      const loggedIn = await login(form.email.trim(), form.password);
      navigate(destination(location.state?.from, loggedIn.role), { replace: true });
    } catch (err) {
      setFormError(errMsg(err));
    }
  });

  if (user) return <Navigate to={destination(location.state?.from, user.role)} replace />;

  const notice = sessionExpired ? 'Your session expired. Please log in again.' : location.state?.notice;

  return (
    <AuthShell title="Welcome back" subtitle="Log in to manage or explore your expos." notice={notice}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {formError && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{formError}</p>}
        <TextField label="Email" type="email" autoComplete="email" value={form.email} error={errors.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <TextField label="Password" type="password" autoComplete="current-password" value={form.password} error={errors.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <button disabled={busy} className="btn btn-primary w-full">{busy ? <><Spinner size={16} /> Logging in…</> : 'Log in'}</button>
        <div className="flex justify-between text-sm">
          <Link to="/forgot-password" className="link">Forgot password?</Link>
          <Link to="/register" className="link">Create an account</Link>
        </div>
      </form>
    </AuthShell>
  );
}
