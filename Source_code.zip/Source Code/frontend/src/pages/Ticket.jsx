import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Printer } from 'lucide-react';
import { ticketApi } from '../api/services';
import { useAuth } from '../context/AuthContext';
import useFetch from '../hooks/useFetch';
import EventBanner from '../components/EventBanner';
import ErrorState from '../components/ErrorState';
import { Skeleton } from '../components/Skeleton';
import { LogoMark } from '../components/Logo';
import { directionsUrl, passName } from '../utils/passes';
import { fmtDateRange, fmtShortDay } from '../utils/format';

export default function Ticket() {
  const { id } = useParams();
  const { user } = useAuth();
  const { data, error, reload } = useFetch(() => ticketApi.get(id), [id]);
  const [qr, setQr] = useState('');

  useEffect(() => {
    if (!data) return undefined;
    let active = true;
    const url = new URL('/admin/check-in', window.location.origin);
    url.searchParams.set('token', data.registration.ticketToken);
    import('qrcode')
      .then((m) => (m.default || m).toDataURL(url.href, { width: 260, margin: 2 }))
      .then((img) => { if (active) setQr(img); })
      .catch(() => { if (active) setQr(''); });
    return () => { active = false; };
  }, [data]);

  const back = user?.role === 'admin' ? '/admin/registrations' : '/attendee/agenda';

  if (error) {
    return (
      <div className="mx-auto max-w-lg px-4 py-10">
        <ErrorState message={error} onRetry={reload} />
        <p className="mt-4 text-center text-sm"><Link to={back} className="link">Back to {user?.role === 'admin' ? 'registrations' : 'my agenda'}</Link></p>
      </div>
    );
  }
  if (!data) return <div className="mx-auto max-w-lg px-4 py-10"><Skeleton className="h-96 w-full rounded-2xl" /></div>;

  const { registration: r, expo: e } = data;
  return (
    <div className="min-h-screen bg-slate-100 px-4 py-8 print:bg-white print:p-0">
      <div className="mx-auto mb-4 flex max-w-md items-center justify-between print:hidden">
        <Link to={back} className="link text-sm">← Back</Link>
        <button className="btn btn-primary btn-sm" onClick={() => window.print()} disabled={!qr}><Printer size={15} /> Print / Save PDF</button>
      </div>

      <article className="mx-auto max-w-md overflow-hidden rounded-2xl bg-white shadow-lift print:max-w-none print:shadow-none">
        <EventBanner event={e} rounded={false} className="h-40" />
        <div className="space-y-3 p-6 text-center">
          <p className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wide text-brand-dark"><LogoMark size={18} /> EventSphere entry ticket</p>
          <h1 className="text-2xl font-semibold">{e.title}</h1>
          <p className="text-sm text-ink-muted">
            {r.day ? <strong className="text-ink">{fmtShortDay(r.day)}</strong> : fmtDateRange(e.startDate, e.endDate)} · doors {e.openTime} to {e.closeTime}
          </p>
          <p className="text-sm text-ink-muted">{[e.venue, e.location].filter(Boolean).join(', ')}{e.address ? ` · ${e.address}` : ''}</p>
          <a className="link inline-block text-sm print:hidden" href={directionsUrl([e.venue, e.address || e.location].filter(Boolean).join(', '))} target="_blank" rel="noreferrer">Get directions ↗</a>

          <div className="mx-auto flex h-[260px] w-[260px] items-center justify-center">
            {qr ? <img src={qr} alt="Entry QR code" width="260" height="260" /> : <Skeleton className="h-[260px] w-[260px]" />}
          </div>

          <div>
            <p className="text-xs text-ink-muted">Ticket number</p>
            <p className="font-mono text-2xl font-bold tracking-widest">{String(r._id).slice(-8).toUpperCase()}</p>
          </div>
          <p className="text-sm text-ink-muted">{passName(r.passType)}</p>
          <h2 className="text-lg font-semibold">{r.fullName}</h2>
          <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${r.checkedInAt ? 'bg-slate-100 text-slate-600' : 'bg-emerald-50 text-emerald-700'}`}>
            {r.checkedInAt ? 'Checked in' : 'Confirmed admission'}
          </span>
          <p className="pt-2 text-xs text-ink-muted">Keep this ticket with you and show the QR code at the entrance. Valid only on the day shown.</p>
        </div>
      </article>
    </div>
  );
}
