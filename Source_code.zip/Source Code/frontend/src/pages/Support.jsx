import { useState } from 'react';
import { LifeBuoy, Send } from 'lucide-react';
import { feedbackApi } from '../api/services';
import { errMsg } from '../api/api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useFetch from '../hooks/useFetch';
import useSubmit from '../hooks/useSubmit';
import PageHeader from '../components/PageHeader';
import Badge from '../components/Badge';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import Modal from '../components/Modal';
import { ListSkeleton } from '../components/Skeleton';
import { SelectField, TextAreaField, TextField } from '../components/Fields';
import { timeAgo } from '../utils/format';

const STATUS_BADGE = { open: 'pending', 'in-progress': 'booked', resolved: 'approved' };

export default function Support() {
  const { user } = useAuth();
  const { toast } = useSocket();
  const isAdmin = user.role === 'admin';
  const list = useFetch(() => feedbackApi.list(), []);
  const [form, setForm] = useState({ subject: '', message: '' });
  const [reply, setReply] = useState(null);
  const [replyForm, setReplyForm] = useState({ status: 'in-progress', response: '' });

  const [send, sending] = useSubmit(async (e) => {
    e.preventDefault();
    try {
      await feedbackApi.create(form);
      setForm({ subject: '', message: '' });
      toast('Thanks. We will get back to you.', 'Feedback sent', 'success');
      list.refresh();
    } catch (err) { toast(errMsg(err), 'Could not send', 'error'); }
  });

  const [respond, responding] = useSubmit(async () => {
    try {
      await feedbackApi.respond(reply._id, replyForm);
      toast('The user was notified.', 'Response saved', 'success');
      setReply(null);
      list.refresh();
    } catch (err) { toast(errMsg(err), 'Could not save', 'error'); }
  });

  const open = (f) => { setReply(f); setReplyForm({ status: f.status === 'open' ? 'in-progress' : f.status, response: f.response || '' }); };
  const items = list.data || [];

  return (
    <>
      <PageHeader title="Help & feedback" subtitle={isAdmin ? 'Requests from attendees and exhibitors.' : 'Share an idea, report an issue, or follow up on a request.'} />
      <div className={`grid gap-6 ${isAdmin ? '' : 'lg:grid-cols-[22rem_1fr]'}`}>
        {!isAdmin && (
          <form onSubmit={send} className="card h-fit space-y-4 p-5">
            <h2 className="text-lg font-semibold">Send feedback</h2>
            <TextField label="Subject" required maxLength={160} value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} />
            <TextAreaField label="How can we help?" required rows={5} maxLength={5000} value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} />
            <button className="btn btn-primary w-full" disabled={sending}><Send size={16} /> {sending ? 'Sending…' : 'Submit'}</button>
          </form>
        )}
        <section aria-label="Requests">
          <h2 className="mb-3 text-lg font-semibold">{isAdmin ? 'All requests' : 'Your requests'}</h2>
          {list.error ? <ErrorState message={list.error} onRetry={list.reload} /> : list.loading && !list.data ? <ListSkeleton rows={3} /> : items.length === 0 ? (
            <EmptyState icon={LifeBuoy} title="No requests yet" text={isAdmin ? 'Support requests will appear here.' : 'Your feedback helps make EventSphere better.'} />
          ) : (
            <ul className="space-y-3">
              {items.map((f) => (
                <li key={f._id} className="card p-4">
                  <div className="flex flex-wrap items-center gap-2"><Badge status={STATUS_BADGE[f.status]}>{f.status}</Badge><h3 className="font-semibold">{f.subject}</h3></div>
                  <p className="mt-1 text-xs text-slate-400">{isAdmin && f.user ? `${f.user.name} (${f.user.role}) · ` : ''}{timeAgo(f.createdAt)}</p>
                  <p className="mt-2 whitespace-pre-line text-sm text-ink-muted">{f.message}</p>
                  {f.response && <div className="mt-3 rounded-lg bg-brand-soft p-3 text-sm text-brand-dark"><strong>Response:</strong> {f.response}</div>}
                  {isAdmin && <button className="link mt-3 text-sm" onClick={() => open(f)}>Respond</button>}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <Modal open={!!reply} onClose={() => setReply(null)} busy={responding} title="Respond to request" description={reply?.subject}
        footer={<><button className="btn btn-secondary" onClick={() => setReply(null)} disabled={responding}>Cancel</button><button className="btn btn-primary" onClick={respond} disabled={responding}>{responding ? 'Saving…' : 'Save response'}</button></>}>
        <div className="space-y-4">
          <SelectField label="Status" value={replyForm.status} onChange={(e) => setReplyForm((f) => ({ ...f, status: e.target.value }))}>
            <option value="open">Open</option><option value="in-progress">In progress</option><option value="resolved">Resolved</option>
          </SelectField>
          <TextAreaField label="Response" rows={5} maxLength={5000} value={replyForm.response} onChange={(e) => setReplyForm((f) => ({ ...f, response: e.target.value }))} />
        </div>
      </Modal>
    </>
  );
}
