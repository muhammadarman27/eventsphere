import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import AuthShell from '../components/AuthShell';
import { TextField } from '../components/Fields';
import { Spinner } from '../components/Skeleton';
import useSubmit from '../hooks/useSubmit';
import { authApi } from '../api/services';
import { errMsg } from '../api/api';
import { isEmail, passwordError } from '../utils/validate';

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  const [submit, busy] = useSubmit(async (e) => {
    e.preventDefault();
    if (!isEmail(email.trim())) return setError('Enter a valid email address');
    setError('');
    try {
      setResult(await authApi.forgotPassword(email.trim()));
    } catch (err) {
      setError(errMsg(err));
    }
  });

  return (
    <AuthShell title="Reset your password" subtitle="Enter your email and we will send you a reset link.">
      {result ? (
        <div className="card space-y-3 p-5 text-sm" role="status">
          <p className="font-medium">Check your inbox</p>
          <p className="text-ink-muted">{result.message} The link works for 15 minutes.</p>
          {result.resetToken && (
            <div className="rounded-lg bg-amber-50 p-3 text-amber-900">
              <p className="mb-2">Development mode: no email service is connected, so here is your link.</p>
              <Link to={`/reset-password/${result.resetToken}`} className="btn btn-primary btn-sm">Choose a new password</Link>
            </div>
          )}
          <Link to="/login" className="link block">Back to log in</Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4" noValidate>
          <TextField label="Email" type="email" autoComplete="email" value={email} error={error} onChange={(e) => setEmail(e.target.value)} />
          <button disabled={busy} className="btn btn-primary w-full">{busy ? <><Spinner size={16} /> Sending…</> : 'Send reset link'}</button>
          <Link to="/login" className="link block text-sm">Back to log in</Link>
        </form>
      )}
    </AuthShell>
  );
}

export function ResetPassword() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({ password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');

  const [submit, busy] = useSubmit(async (e) => {
    e.preventDefault();
    setFormError('');
    const next = { password: passwordError(form.password), confirm: form.confirm === form.password ? '' : 'Passwords do not match' };
    setErrors(next);
    if (next.password || next.confirm) return;
    try {
      await authApi.resetPassword(token, form.password);
      navigate('/login', { replace: true, state: { notice: 'Password updated. Log in with your new password.' } });
    } catch (err) {
      setFormError(errMsg(err));
    }
  });

  return (
    <AuthShell title="Choose a new password">
      <form onSubmit={submit} className="space-y-4" noValidate>
        {formError && (
          <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">
            {formError} <Link to="/forgot-password" className="link">Request a new link</Link>
          </p>
        )}
        <TextField label="New password" type="password" autoComplete="new-password" hint="At least 8 characters, with a letter and a number." value={form.password} error={errors.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <TextField label="Confirm new password" type="password" autoComplete="new-password" value={form.confirm} error={errors.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} />
        <button disabled={busy} className="btn btn-primary w-full">{busy ? <><Spinner size={16} /> Saving…</> : 'Save password'}</button>
      </form>
    </AuthShell>
  );
}
