import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Store } from 'lucide-react';
import { exhibitorApi, expoApi } from '../../api/services';
import { errMsg } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSocketRefresh from '../../hooks/useSocketRefresh';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import BoothDetail from '../../components/BoothDetail';
import BoothGrid from '../../components/BoothGrid';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import { Skeleton, Spinner } from '../../components/Skeleton';
import { useConfirm } from '../../components/ConfirmProvider';
import { fmtDateRange } from '../../utils/format';

const STATUS_TEXT = {
  pending: 'Waiting for the organizer. You can reserve a preferred booth meanwhile; the organizer confirms it when approving.',
  approved: 'Approved. Your booth is confirmed.',
  rejected: 'This application was rejected.',
};

export default function Booths() {
  const { socket, toast } = useSocket();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const me = useFetch(() => exhibitorApi.me(), []);
  const apps = (me.data?.applications || []).filter((a) => a.expo);
  const expoId = params.get('expo') || apps[0]?.expo._id || '';
  const app = apps.find((a) => a.expo._id === expoId);

  const expo = useFetch(() => expoApi.get(expoId), [expoId], { enabled: !!expoId });
  const booths = useFetch(() => expoApi.booths(expoId), [expoId], { enabled: !!expoId });
  const [selectedId, setSelectedId] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => setSelectedId(null), [expoId]);
  const refreshBooths = booths.refresh;
  const refreshMe = me.refresh;
  useSocketRefresh(socket, ['booths-updated', 'notification'], () => { refreshBooths(); refreshMe(); });

  const list = booths.data || [];
  const selected = list.find((b) => b._id === selectedId) || null;
  const mine = (b) => !!b && !!b.exhibitor && b.exhibitor._id === me.data?._id;
  const myBooth = app?.booth;

  const act = async (request, success) => {
    setBusy(true);
    try { const res = await request(); toast(res.message || success, 'Done', 'success'); await Promise.all([booths.refresh(), me.refresh()]); }
    catch (err) { toast(errMsg(err), 'Could not complete that', 'error'); booths.refresh(); me.refresh(); }
    finally { setBusy(false); }
  };

  const reserve = () => act(() => exhibitorApi.reserve(selected._id));
  const release = async () => {
    if (await confirm({ title: `Release booth ${selected.boothNumber}?`, message: 'Someone else may take it. You can reserve another booth afterwards.', confirmLabel: 'Release booth' })) act(() => exhibitorApi.release(selected._id));
  };
  const withdraw = async () => {
    if (await confirm({ title: 'Withdraw your application?', message: 'Your reserved booth is released and the organizer will no longer see the application.', confirmLabel: 'Withdraw', tone: 'danger' })) act(() => exhibitorApi.withdraw(app._id), 'Application withdrawn');
  };

  const canPick = app?.status === 'pending' && expo.data?.status !== 'completed';

  return (
    <>
      <PageHeader title="Booths" subtitle="Pick your spot on the floor plan and follow your application." />
      {me.error ? <ErrorState message={me.error} onRetry={me.reload} /> : me.loading && !me.data ? <Skeleton className="h-72" /> : apps.length === 0 ? (
        <EmptyState icon={Store} title="Apply to an event first" text="Once you apply, you can choose a booth here." action={<Link to="/exhibitor/events" className="btn btn-primary">Browse events</Link>} />
      ) : (
        <>
          <div className="mb-5 grid gap-4 sm:grid-cols-[18rem_1fr] sm:items-end">
            <div><label htmlFor="xb-expo" className="label">Event</label>
              <select id="xb-expo" className="input" value={expoId} onChange={(e) => setParams({ expo: e.target.value }, { replace: true })}>{apps.map((a) => <option key={a._id} value={a.expo._id}>{a.expo.title}</option>)}</select></div>
            {app && (
              <div className="card flex flex-wrap items-center gap-3 p-3 text-sm">
                <Badge status={app.status} /><span className="min-w-0 flex-1 text-ink-muted">{STATUS_TEXT[app.status]}{app.reviewNote ? ` Note: ${app.reviewNote}` : ''}</span>
                {app.status === 'pending' && <button onClick={withdraw} disabled={busy} className="btn btn-secondary btn-sm">Withdraw</button>}
              </div>
            )}
          </div>

          {booths.error ? <ErrorState message={booths.error} onRetry={booths.reload} /> : !expo.data || (booths.loading && !booths.data) ? <Skeleton className="h-72" /> : (
            <div className="grid gap-6 lg:grid-cols-[1fr_21rem]">
              <section className="card p-5">
                <p className="mb-4 text-sm text-ink-muted">{expo.data.title} · {fmtDateRange(expo.data.startDate, expo.data.endDate)}</p>
                <BoothGrid booths={list} columns={expo.data.floorPlan.columns} selectedId={selectedId} onSelect={(b) => setSelectedId(b._id)} myExhibitorId={me.data?._id} />
              </section>
              <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
                {myBooth && <div className="rounded-xl bg-gradient-to-br from-indigo-600 to-brand p-4 text-white"><p className="text-sm text-white/80">{app.status === 'approved' ? 'Your confirmed booth' : 'Your reserved booth'}</p><p className="text-2xl font-semibold">{myBooth.boothNumber}</p></div>}
                <BoothDetail booth={selected} mine={mine(selected)}>
                  {selected && selected.status === 'available' && canPick && (
                    <button className="btn btn-primary btn-sm" onClick={reserve} disabled={busy}>{busy ? <Spinner size={15} /> : null}{myBooth ? 'Move my reservation here' : 'Reserve this booth'}</button>
                  )}
                  {selected && selected.status === 'available' && !canPick && <p className="text-sm text-ink-muted">{app?.status === 'approved' ? 'Contact the organizer to change an approved booth.' : 'Booths cannot be reserved for this application.'}</p>}
                  {selected && mine(selected) && selected.status === 'reserved' && <button className="btn btn-secondary btn-sm" onClick={release} disabled={busy}>Release booth</button>}
                  {selected && !mine(selected) && selected.status !== 'available' && <p className="text-sm text-ink-muted">This booth is not available.</p>}
                </BoothDetail>
              </aside>
            </div>
          )}
        </>
      )}
    </>
  );
}
