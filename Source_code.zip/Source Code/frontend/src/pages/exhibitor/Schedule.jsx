import { useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Clock } from 'lucide-react';
import { exhibitorApi } from '../../api/services';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import SessionCard from '../../components/SessionCard';
import { ListSkeleton } from '../../components/Skeleton';
import { dayKey, fmtDay } from '../../utils/format';

export default function Schedule() {
  const { socket } = useSocket();
  const { data, loading, error, reload, refresh } = useFetch(() => exhibitorApi.schedule(), []);
  useEffect(() => {
    if (!socket) return undefined;
    socket.on('schedule-updated', refresh);
    return () => socket.off('schedule-updated', refresh);
  }, [socket, refresh]);

  const groups = useMemo(() => {
    const map = new Map();
    (data || []).forEach((s) => { const k = dayKey(s.startTime); map.set(k, [...(map.get(k) || []), s]); });
    return [...map.entries()];
  }, [data]);

  return (
    <>
      <PageHeader title="Schedule" subtitle="Upcoming sessions at the events where you are an approved exhibitor." />
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <ListSkeleton /> : groups.length === 0 ? (
        <EmptyState icon={Clock} title="No upcoming sessions" text="Sessions appear here once an organizer approves you and schedules talks." action={<Link to="/exhibitor/events" className="btn btn-secondary">Browse events</Link>} />
      ) : groups.map(([day, list]) => (
        <section key={day} className="mb-8" aria-label={fmtDay(list[0].startTime)}>
          <h2 className="mb-3 text-sm font-semibold text-ink-muted">{fmtDay(list[0].startTime)}</h2>
          <div className="space-y-3">{list.map((s) => <SessionCard key={s._id} session={s} />)}</div>
        </section>
      ))}
    </>
  );
}
