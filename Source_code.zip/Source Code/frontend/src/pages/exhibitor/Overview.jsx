import { Link } from 'react-router-dom';
import { CalendarDays, Eye, MessageSquare, Store, Ticket } from 'lucide-react';
import { exhibitorApi } from '../../api/services';
import { useAuth } from '../../context/AuthContext';
import useFetch from '../../hooks/useFetch';
import PageHeader from '../../components/PageHeader';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import ErrorState from '../../components/ErrorState';
import StatCard from '../../components/StatCard';
import { Skeleton, StatsSkeleton } from '../../components/Skeleton';
import { fmtDate, fmtDateRange } from '../../utils/format';

export default function Overview() {
  const { user } = useAuth();
  const { data, error, reload } = useFetch(() => exhibitorApi.overview(), []);
  const head = <PageHeader title={`Welcome, ${user.name.split(' ')[0]}`} subtitle="Your applications, booths and visitor interest at a glance." actions={<Link to="/exhibitor/events" className="btn btn-primary"><CalendarDays size={16} /> Find events</Link>} />;
  if (error) return <>{head}<ErrorState message={error} onRetry={reload} /></>;
  if (!data) return <>{head}<StatsSkeleton /><Skeleton className="mt-6 h-48" /></>;

  const { counts, booths, applications, company } = data;
  const confirmed = booths.filter((b) => b.status === 'booked').length;

  return (
    <>
      {head}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Applications" value={applications.length} icon={CalendarDays} tone="violet" hint={`${counts.pending} pending, ${counts.approved} approved, ${counts.rejected} rejected`} to="/exhibitor/booths" />
        <StatCard label="Booths" value={confirmed} icon={Store} tone="indigo" hint={`${booths.length - confirmed} reserved, waiting for approval`} to="/exhibitor/booths" />
        <StatCard label="Booth visits" value={data.visits} icon={Eye} tone="emerald" hint="Attendees who opened your details" />
        <StatCard label="Unread messages" value={data.unreadMessages} icon={MessageSquare} tone={data.unreadMessages ? 'amber' : 'sky'} to="/exhibitor/messages" hint={`${data.upcomingSessions} upcoming sessions`} />
      </div>

      {company.completeness < 100 && (
        <div className="card mt-6 flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="min-w-0 flex-1"><p className="font-medium">Your company profile is {company.completeness}% complete</p>
            <div className="mt-2 h-2 max-w-md rounded-full bg-slate-100"><div className="h-2 rounded-full bg-gradient-to-r from-indigo-500 to-brand" style={{ width: `${company.completeness}%` }} /></div>
            <p className="mt-1 text-sm text-ink-muted">Add a logo, website, products and staff so attendees can find you.</p></div>
          <Link to="/exhibitor/profile" className="btn btn-secondary">Complete profile</Link>
        </div>
      )}

      <section className="mt-6">
        <h2 className="mb-3 text-lg font-semibold">Your applications</h2>
        {applications.length === 0 ? (
          <EmptyState icon={Ticket} title="You have not applied to any event" text="Browse upcoming events and apply to exhibit." action={<Link to="/exhibitor/events" className="btn btn-primary">Browse events</Link>} />
        ) : (
          <ul className="space-y-3">
            {applications.map((a) => (
              <li key={a._id} className="card flex flex-wrap items-center gap-4 p-4">
                <div className="min-w-0 flex-1">
                  <Link to={`/exhibitor/events/${a.expo._id}`} className="font-medium hover:text-brand-dark">{a.expo.title}</Link>
                  <p className="text-sm text-ink-muted">{fmtDateRange(a.expo.startDate, a.expo.endDate)} · applied {fmtDate(a.appliedAt)}</p>
                  {a.reviewNote && <p className="mt-1 text-sm text-ink-muted">Organizer: {a.reviewNote}</p>}
                </div>
                {a.booth ? <Badge status={a.status === 'approved' ? 'booked' : 'reserved'}>Booth {a.booth.boothNumber}</Badge> : null}
                <Badge status={a.status} />
                <Link to={`/exhibitor/booths?expo=${a.expo._id}`} className="btn btn-secondary btn-sm">{a.status === 'pending' && !a.booth ? 'Choose booth' : 'Open'}</Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
