import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { exhibitorApi } from '../../api/services';
import { errMsg, fieldErrors } from '../../api/api';
import { useSocket } from '../../context/SocketContext';
import useFetch from '../../hooks/useFetch';
import useSubmit from '../../hooks/useSubmit';
import PageHeader from '../../components/PageHeader';
import ErrorState from '../../components/ErrorState';
import ImageUpload from '../../components/ImageUpload';
import { SelectField, TextAreaField, TextField } from '../../components/Fields';
import { Skeleton, Spinner } from '../../components/Skeleton';
import { CATEGORIES } from '../../utils/constants';
import { hasErrors, isEmail, isHttpUrl } from '../../utils/validate';

function ProfileForm({ profile, onSaved }) {
  const { toast } = useSocket();
  const [form, setForm] = useState({
    companyName: profile.companyName, logo: profile.logo || '', category: profile.category || 'General', website: profile.website || '', description: profile.description || '',
    products: profile.products.map((p) => ({ name: p.name, description: p.description || '', image: p.image || '' })),
    staff: profile.staff.map((s) => ({ name: s.name, email: s.email || '', position: s.position || '' })),
  });
  const [errors, setErrors] = useState({});
  const [logoBroken, setLogoBroken] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const setItem = (list, i, key, value) => setForm({ ...form, [list]: form[list].map((x, idx) => (idx === i ? { ...x, [key]: value } : x)) });
  const addItem = (list, blank) => form[list].length < 20 && setForm({ ...form, [list]: [...form[list], blank] });
  const removeItem = (list, i) => setForm({ ...form, [list]: form[list].filter((_, idx) => idx !== i) });

  const [save, busy] = useSubmit(async (ev) => {
    ev.preventDefault();
    const next = {
      companyName: form.companyName.trim().length >= 2 ? '' : 'Enter your company name',
      logo: form.logo.trim() && !isHttpUrl(form.logo.trim()) ? 'Enter a full link starting with http:// or https://' : '',
      website: form.website.trim() && !isHttpUrl(form.website.trim()) ? 'Enter a full link starting with http:// or https://' : '',
      products: form.products.some((p) => !p.name.trim()) ? 'Every product needs a name (or remove the empty row)' : form.products.some((p) => p.image.trim() && !isHttpUrl(p.image.trim())) ? 'Product image links must start with http:// or https://' : '',
      staff: form.staff.some((s) => !s.name.trim()) ? 'Every person needs a name (or remove the empty row)' : form.staff.some((s) => s.email.trim() && !isEmail(s.email.trim())) ? 'One of the staff emails is not valid' : '',
    };
    setErrors(next);
    if (hasErrors(next)) { toast('Please fix the highlighted fields.', 'Check the form', 'error'); return; }
    try {
      const saved = await exhibitorApi.update({
        ...form, companyName: form.companyName.trim(), logo: form.logo.trim(), website: form.website.trim(), description: form.description.trim(),
        products: form.products.map((p) => ({ ...p, name: p.name.trim(), image: p.image.trim() })), staff: form.staff.map((s) => ({ ...s, name: s.name.trim(), email: s.email.trim() })),
      });
      toast('Attendees now see your updated profile.', 'Profile saved', 'success');
      onSaved(saved);
    } catch (err) { setErrors(fieldErrors(err)); toast(errMsg(err), 'Could not save profile', 'error'); }
  });

  return (
    <form onSubmit={save} noValidate className="max-w-3xl space-y-6">
      <section className="card space-y-4 p-5">
        <h2 className="text-lg font-semibold">Company</h2>
        <div className="flex items-start gap-4">
          {form.logo && isHttpUrl(form.logo.trim()) && !logoBroken
            ? <img src={form.logo.trim()} alt="Logo preview" className="h-16 w-16 rounded-lg border border-slate-200 object-cover" onError={() => setLogoBroken(true)} />
            : <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-brand text-2xl font-semibold text-white" aria-hidden="true">{(form.companyName || '?')[0]}</div>}
          <div className="flex-1 space-y-3"><ImageUpload value={form.logo} onChange={(url) => { setLogoBroken(false); setForm({ ...form, logo: url }); }} label="Upload logo" /><TextField label="Or paste a logo link" value={form.logo} error={errors.logo} onChange={(e) => { setLogoBroken(false); set('logo')(e); }} placeholder="https://…/logo.png" hint="Link to an image. Leave empty to use your initial." /></div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <TextField label="Company name" required value={form.companyName} error={errors.companyName} onChange={set('companyName')} maxLength={100} />
          <SelectField label="Category" value={form.category} error={errors.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</SelectField>
        </div>
        <TextField label="Website" type="url" value={form.website} error={errors.website} onChange={set('website')} placeholder="https://example.com" />
        <TextAreaField label="Business description" rows={4} maxLength={2000} value={form.description} error={errors.description} onChange={set('description')} hint="What does your company do? This appears on your exhibitor card." />
      </section>

      {[['products', 'Products and services', { name: '', description: '', image: '' }, 'Add product'], ['staff', 'Booth staff', { name: '', email: '', position: '' }, 'Add person']].map(([key, title, blank, addLabel]) => (
        <section key={key} className="card space-y-4 p-5">
          <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">{title}</h2><button type="button" onClick={() => addItem(key, blank)} className="btn btn-secondary btn-sm"><Plus size={15} /> {addLabel}</button></div>
          {errors[key] && <p role="alert" className="text-sm font-medium text-rose-600">{errors[key]}</p>}
          {form[key].length === 0 && <p className="text-sm text-ink-muted">Nothing added yet.</p>}
          {form[key].map((item, i) => (
            <div key={i} className="grid gap-3 rounded-lg border border-slate-200 p-3 sm:grid-cols-[1fr_1fr_auto]">
              {key === 'products' ? (
                <>
                  <TextField label="Name" value={item.name} onChange={(e) => setItem(key, i, 'name', e.target.value)} maxLength={100} />
                  <TextField label="Short description" value={item.description} onChange={(e) => setItem(key, i, 'description', e.target.value)} maxLength={300} />
                </>
              ) : (
                <>
                  <TextField label="Name" value={item.name} onChange={(e) => setItem(key, i, 'name', e.target.value)} maxLength={100} />
                  <TextField label="Email" type="email" value={item.email} onChange={(e) => setItem(key, i, 'email', e.target.value)} />
                </>
              )}
              <button type="button" onClick={() => removeItem(key, i)} className="btn btn-ghost btn-icon self-end text-rose-600 hover:bg-rose-50" aria-label={`Remove ${key === 'products' ? 'product' : 'person'} ${i + 1}`}><Trash2 size={16} /></button>
              {key === 'products' && <div className="sm:col-span-3"><TextField label="Image link (optional)" value={item.image} onChange={(e) => setItem(key, i, 'image', e.target.value)} placeholder="https://…" /></div>}
              {key === 'staff' && <div className="sm:col-span-3"><TextField label="Position" value={item.position} onChange={(e) => setItem(key, i, 'position', e.target.value)} maxLength={100} /></div>}
            </div>
          ))}
        </section>
      ))}

      <button disabled={busy} className="btn btn-primary">{busy ? <><Spinner size={16} /> Saving…</> : 'Save profile'}</button>
    </form>
  );
}

export default function Profile() {
  const { data, error, reload, setData } = useFetch(() => exhibitorApi.me(), []);
  return (
    <>
      <PageHeader title="Company profile" subtitle="This is what attendees see when they browse exhibitors." />
      {error ? <ErrorState message={error} onRetry={reload} /> : !data ? <Skeleton className="h-96 max-w-3xl" /> : <ProfileForm profile={data} onSaved={setData} />}
    </>
  );
}
