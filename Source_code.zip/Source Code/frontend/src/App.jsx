import { Suspense, lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import DashboardLayout from './components/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute';
import PublicLayout from './components/PublicLayout';
import { FullPageLoader } from './components/Skeleton';
import PageHeader from './components/PageHeader';

const EventsExplorer = lazy(() => import('./components/EventsExplorer'));
const EventDetail = lazy(() => import('./components/EventDetail'));
const Landing = lazy(() => import('./pages/Landing'));
const PublicEvents = lazy(() => import('./pages/PublicEvents').then((m) => ({ default: m.PublicEventList })));
const PublicEventDetail = lazy(() => import('./pages/PublicEvents').then((m) => ({ default: m.PublicEventDetail })));
const Login = lazy(() => import('./pages/Login'));
const Register = lazy(() => import('./pages/Register'));
const ForgotPassword = lazy(() => import('./pages/PasswordReset').then((m) => ({ default: m.ForgotPassword })));
const ResetPassword = lazy(() => import('./pages/PasswordReset').then((m) => ({ default: m.ResetPassword })));
const NotFound = lazy(() => import('./pages/NotFound'));
const Account = lazy(() => import('./pages/Account'));
const Messages = lazy(() => import('./pages/Messages'));
const Support = lazy(() => import('./pages/Support'));
const Ticket = lazy(() => import('./pages/Ticket'));

const AdminDashboard = lazy(() => import('./pages/admin/Dashboard'));
const AdminEvents = lazy(() => import('./pages/admin/Events'));
const AdminEventForm = lazy(() => import('./pages/admin/EventForm'));
const AdminEventDetail = lazy(() => import('./pages/admin/EventAdmin'));
const AdminApplications = lazy(() => import('./pages/admin/Applications'));
const AdminBooths = lazy(() => import('./pages/admin/Booths'));
const AdminSessions = lazy(() => import('./pages/admin/Sessions'));
const AdminUsers = lazy(() => import('./pages/admin/Users'));
const AdminRegistrations = lazy(() => import('./pages/admin/Registrations'));
const AdminCheckIn = lazy(() => import('./pages/admin/CheckIn'));

const ExhibitorOverview = lazy(() => import('./pages/exhibitor/Overview'));
const ExhibitorProfile = lazy(() => import('./pages/exhibitor/Profile'));
const ExhibitorBooths = lazy(() => import('./pages/exhibitor/Booths'));
const ExhibitorSchedule = lazy(() => import('./pages/exhibitor/Schedule'));

const AttendeeOverview = lazy(() => import('./pages/attendee/Overview'));
const AttendeeExhibitors = lazy(() => import('./pages/attendee/Exhibitors'));
const AttendeeAgenda = lazy(() => import('./pages/attendee/Agenda'));

const guard = (role) => (
  <ProtectedRoute roles={[role]}>
    <DashboardLayout role={role} />
  </ProtectedRoute>
);

const EventsPage = ({ basePath, title, subtitle }) => (
  <>
    <PageHeader title={title} subtitle={subtitle} />
    <EventsExplorer basePath={basePath} />
  </>
);

export default function App() {
  return (
    <Suspense fallback={<FullPageLoader />}>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<Landing />} />
          <Route path="events" element={<PublicEvents />} />
          <Route path="events/:id" element={<PublicEventDetail />} />
        </Route>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />

        <Route path="/tickets/:id" element={<ProtectedRoute roles={['attendee', 'admin']}><Ticket /></ProtectedRoute>} />

        <Route path="/admin" element={guard('admin')}>
          <Route index element={<AdminDashboard />} />
          <Route path="events" element={<AdminEvents />} />
          <Route path="events/new" element={<AdminEventForm />} />
          <Route path="events/:id" element={<AdminEventDetail />} />
          <Route path="events/:id/edit" element={<AdminEventForm />} />
          <Route path="applications" element={<AdminApplications />} />
          <Route path="booths" element={<AdminBooths />} />
          <Route path="sessions" element={<AdminSessions />} />
          <Route path="registrations" element={<AdminRegistrations />} />
          <Route path="check-in" element={<AdminCheckIn />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="messages" element={<Messages />} />
          <Route path="support" element={<Support />} />
          <Route path="account" element={<Account />} />
        </Route>

        <Route path="/exhibitor" element={guard('exhibitor')}>
          <Route index element={<ExhibitorOverview />} />
          <Route path="events" element={<EventsPage basePath="/exhibitor/events" title="Events" subtitle="Find an expo to exhibit at." />} />
          <Route path="events/:id" element={<EventDetail basePath="/exhibitor/events" rootTo="/exhibitor/events" />} />
          <Route path="booths" element={<ExhibitorBooths />} />
          <Route path="profile" element={<ExhibitorProfile />} />
          <Route path="schedule" element={<ExhibitorSchedule />} />
          <Route path="messages" element={<Messages />} />
          <Route path="support" element={<Support />} />
          <Route path="account" element={<Account />} />
        </Route>

        <Route path="/attendee" element={guard('attendee')}>
          <Route index element={<AttendeeOverview />} />
          <Route path="events" element={<EventsPage basePath="/attendee/events" title="Discover events" subtitle="Search, filter and register for expos." />} />
          <Route path="events/:id" element={<EventDetail basePath="/attendee/events" rootTo="/attendee/events" />} />
          <Route path="exhibitors" element={<AttendeeExhibitors />} />
          <Route path="agenda" element={<AttendeeAgenda />} />
          <Route path="messages" element={<Messages />} />
          <Route path="support" element={<Support />} />
          <Route path="account" element={<Account />} />
        </Route>

        <Route path="/home" element={<Navigate to="/" replace />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
