export const CATEGORIES = [
  'General',
  'Technology',
  'Healthcare',
  'Education',
  'Food & Beverage',
  'Manufacturing',
  'Fashion',
  'Finance',
];

export const ROLE_LABELS = { admin: 'Organizer', exhibitor: 'Exhibitor', attendee: 'Attendee' };
export const roleHome = (role) => `/${role}`;
export const CONTACT_EMAIL = import.meta.env.VITE_CONTACT_EMAIL || 'hello@eventsphere.example';
