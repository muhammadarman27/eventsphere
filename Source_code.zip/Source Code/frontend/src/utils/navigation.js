import {
  Bookmark, Building2, CalendarDays, ClipboardList, Clock, LayoutDashboard, LifeBuoy, MessageSquare, ScanLine, Store, UserCheck, Users,
} from 'lucide-react';

export const NAV = {
  admin: [
    { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
    { to: '/admin/events', label: 'Events', icon: CalendarDays },
    { to: '/admin/applications', label: 'Exhibitors', icon: ClipboardList },
    { to: '/admin/booths', label: 'Booths', icon: Store },
    { to: '/admin/sessions', label: 'Schedule', icon: Clock },
    { to: '/admin/registrations', label: 'Registrations', icon: UserCheck },
    { to: '/admin/check-in', label: 'Check-in', icon: ScanLine },
    { to: '/admin/users', label: 'Users', icon: Users },
    { to: '/admin/messages', label: 'Messages', icon: MessageSquare, badge: 'messages' },
    { to: '/admin/support', label: 'Help & feedback', icon: LifeBuoy },
  ],
  exhibitor: [
    { to: '/exhibitor', label: 'Overview', icon: LayoutDashboard, end: true },
    { to: '/exhibitor/events', label: 'Events', icon: CalendarDays },
    { to: '/exhibitor/booths', label: 'Booths', icon: Store },
    { to: '/exhibitor/profile', label: 'Company profile', icon: Building2 },
    { to: '/exhibitor/schedule', label: 'Schedule', icon: Clock },
    { to: '/exhibitor/messages', label: 'Messages', icon: MessageSquare, badge: 'messages' },
    { to: '/exhibitor/support', label: 'Help & feedback', icon: LifeBuoy },
  ],
  attendee: [
    { to: '/attendee', label: 'Overview', icon: LayoutDashboard, end: true },
    { to: '/attendee/events', label: 'Discover events', icon: CalendarDays },
    { to: '/attendee/exhibitors', label: 'Exhibitors', icon: Store },
    { to: '/attendee/agenda', label: 'My agenda', icon: Bookmark },
    { to: '/attendee/messages', label: 'Messages', icon: MessageSquare, badge: 'messages' },
    { to: '/attendee/support', label: 'Help & feedback', icon: LifeBuoy },
  ],
};

export const titleFor = (role, pathname) => {
  if (pathname.endsWith('/account')) return 'Account';
  const match = [...(NAV[role] || [])]
    .filter((i) => (i.end ? pathname === i.to : pathname === i.to || pathname.startsWith(`${i.to}/`)))
    .sort((a, b) => b.to.length - a.to.length)[0];
  return match ? match.label : 'Dashboard';
};
