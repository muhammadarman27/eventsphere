const DAY = 24 * 60 * 60 * 1000;

export const fmtDate = (iso) =>
  new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });

export const fmtDateRange = (start, end) => {
  const s = new Date(start);
  const e = new Date(end);
  if (s.toISOString().slice(0, 10) === e.toISOString().slice(0, 10)) return fmtDate(start);
  const sameMonth = s.getUTCMonth() === e.getUTCMonth() && s.getUTCFullYear() === e.getUTCFullYear();
  return sameMonth
    ? `${s.getUTCDate()} to ${fmtDate(end)}`
    : `${fmtDate(start)} to ${fmtDate(end)}`;
};

export const fmtDateTime = (iso) =>
  new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export const fmtTime = (iso) => new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

export const fmtDay = (iso) =>
  new Date(iso).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

export const dayKey = (iso) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const fmtShortDay = (yyyyMmDd) =>
  new Date(`${yyyyMmDd}T00:00:00Z`).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' });

export const timeAgo = (iso) => {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'Just now';
  if (min < 60) return `${min} min ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} h ago`;
  const days = Math.floor(hr / 24);
  if (days < 7) return `${days} d ago`;
  return fmtDate(iso);
};

export const toInputDate = (iso) => (iso ? new Date(iso).toISOString().slice(0, 10) : '');
export const toInputDateTime = (iso) => {
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

export const sessionPhase = (session, now = Date.now()) => {
  const start = new Date(session.startTime).getTime();
  const end = new Date(session.endTime).getTime();
  if (end <= now) return 'ended';
  if (start <= now) return 'live';
  if (start - now <= 60 * 60 * 1000) return 'soon';
  return 'upcoming';
};

export const initials = (name = '') =>
  name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?';

export const fmtMoney = (n) => `$${Number(n || 0).toLocaleString('en-US')}`;
export const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
export const isoDaysAgo = (days) => new Date(Date.now() - days * DAY).toISOString().slice(0, 10);
export const todayIso = () => new Date().toISOString().slice(0, 10);
