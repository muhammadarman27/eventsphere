export const PASS_TYPES = [
  { id: 'trade', name: 'Trade & Corporate Visitor', description: 'Business professionals, enterprise executives, software engineers and IT buyers.' },
  { id: 'conference', name: 'Conference & Workshop Delegate', description: 'Technical workshops, panel discussions and keynote conversations.' },
  { id: 'media', name: 'Media & Tech Influencer', description: 'Press, content creators, journalists and media delegations.' },
];

export const passName = (id) => PASS_TYPES.find((p) => p.id === id)?.name || 'Visitor pass';

export function eventDays(event) {
  const start = new Date(event.startDate).toISOString().slice(0, 10);
  const end = new Date(event.endDate).toISOString().slice(0, 10);
  const days = [];
  for (let d = new Date(`${start}T12:00:00Z`); d.toISOString().slice(0, 10) <= end && days.length < 366; d.setUTCDate(d.getUTCDate() + 1)) {
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
}

export const directionsUrl = (place) => `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(place)}`;
