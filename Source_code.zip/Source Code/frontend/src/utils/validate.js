export const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v || '');
export const isHttpUrl = (v) => {
  try {
    const u = new URL(v);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
};

export const passwordError = (pw) => {
  if (!pw || pw.length < 8) return 'Use at least 8 characters';
  if (pw.length > 128) return 'Use 128 characters or fewer';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Include at least one letter and one number';
  return '';
};

export const hasErrors = (errors) => Object.values(errors).some(Boolean);
