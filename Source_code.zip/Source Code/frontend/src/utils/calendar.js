const esc = (v) => String(v || '').replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,');
const stamp = (v) => new Date(v).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');

export function calendarText(sessions) {
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//EventSphere//Agenda//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH'];
  for (const s of sessions) {
    lines.push(
      'BEGIN:VEVENT',
      `UID:${esc(s._id)}@eventsphere`,
      `DTSTAMP:${stamp(new Date())}`,
      `DTSTART:${stamp(s.startTime)}`,
      `DTEND:${stamp(s.endTime)}`,
      `SUMMARY:${esc(s.title)}`,
      `LOCATION:${esc([s.location, s.expo?.title].filter(Boolean).join(' · '))}`,
      `DESCRIPTION:${esc(s.speaker?.name ? `Speaker: ${s.speaker.name}` : s.description)}`,
      'END:VEVENT'
    );
  }
  lines.push('END:VCALENDAR');
  return `${lines.join('\r\n')}\r\n`;
}

export function downloadCalendar(sessions, name = 'eventsphere-agenda') {
  const url = URL.createObjectURL(new Blob([calendarText(sessions)], { type: 'text/calendar;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `${name}.ics`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
