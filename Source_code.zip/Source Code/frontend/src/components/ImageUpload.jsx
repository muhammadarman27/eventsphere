import { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { errMsg } from '../api/api';
import { uploadApi } from '../api/services';
import { useSocket } from '../context/SocketContext';
import { Spinner } from './Skeleton';

const MAX_BYTES = 5 * 1024 * 1024;

export default function ImageUpload({ value, onChange, label = 'Upload image' }) {
  const { toast } = useSocket();
  const [busy, setBusy] = useState(false);

  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || busy) return;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { toast('Choose a JPG, PNG or WebP image.', 'Wrong file type', 'error'); return; }
    if (file.size > MAX_BYTES) { toast('Images must be 5 MB or smaller.', 'File too large', 'error'); return; }

    setBusy(true);
    try {
      const sig = await uploadApi.sign();
      const body = new FormData();
      body.append('file', file);
      body.append('api_key', sig.apiKey);
      body.append('timestamp', sig.timestamp);
      body.append('folder', sig.folder);
      body.append('signature', sig.signature);
      const res = await fetch(`https://api.cloudinary.com/v1_1/${sig.cloudName}/image/upload`, { method: 'POST', body });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error?.message || 'Upload failed');
      onChange(data.secure_url);
      toast('The image was uploaded. Remember to save the form.', 'Image uploaded', 'success');
    } catch (err) {
      toast(err.response ? errMsg(err) : err.message, 'Upload failed', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className={`btn btn-secondary btn-sm cursor-pointer focus-within:outline focus-within:outline-2 focus-within:outline-brand ${busy ? 'pointer-events-none opacity-60' : ''}`}>
        {busy ? <Spinner size={15} /> : <Upload size={15} aria-hidden="true" />}
        {busy ? 'Uploading…' : label}
        <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={pick} disabled={busy} />
      </label>
      {value && !busy && (
        <button type="button" onClick={() => onChange('')} className="btn btn-ghost btn-sm text-rose-600"><X size={14} /> Remove image</button>
      )}
    </div>
  );
}
