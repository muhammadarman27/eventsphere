import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { CalendarDays, Clock, Layers, MapPin, QrCode, Settings2, Store, Ticket, Users } from 'lucide-react';
import { attendeeApi, exhibitorApi, expoApi } from '../api/services';
import { errMsg } from '../api/api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useAgenda from '../hooks/useAgenda';
import useFetch from '../hooks/useFetch';
import useSocketRefresh from '../hooks/useSocketRefresh';
import useSubmit from '../hooks/useSubmit';
import { fmtDateRange, fmtShortDay, plural } from '../utils/format';
import { directionsUrl, passName } from '../utils/passes';
import RegisterModal from './RegisterModal';
import Badge from './Badge';
import BoothDetail from './BoothDetail';
import BoothGrid from './BoothGrid';
import EmptyState from './EmptyState';
import ErrorState from './ErrorState';
import EventBanner from './EventBanner';
import ExhibitorCard from './ExhibitorCard';
import Modal from './Modal';
import { Breadcrumbs } from './PageHeader';
import SessionCard from './SessionCard';
import { TextAreaField } from './Fields';
import { useConfirm } from './ConfirmProvider';
import { Skeleton, Spinner } from './Skeleton';

const TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'sessions', label: 'Sessions' },
  { key: 'exhibitors', label: 'Exhibitors' },
  { key: 'floor', label: 'Floor plan' },
];

function InfoRow({ icon: Icon, label, children }) {
  return (
    <div className="flex gap-3">
      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-soft text-brand-dark"><Icon size={16} aria-hidden="true" /></span>
      <div className="min-w-0"><dt className="text-xs text-ink-muted">{label}</dt><dd className="text-sm font-medium">{children}</dd></div>
    </div>
  );
}

export default function EventDetail({ basePath, rootLabel = 'Events', rootTo, wrap = false }) {
  const { id } = useParams();
  const { user } = useAuth();
  const { socket, toast } = useSocket();
  const confirm = useConfirm();
  const navigate = useNavigate();
  const location = useLocation();
  const [params, setParams] = useSearchParams();
  const tab = TABS.some((t) => t.key === params.get('tab')) ? params.get('tab') : 'overview';
  const role = user?.role;

  const event = useFetch(() => expoApi.get(id), [id]);
  const sessions = useFetch(() => expoApi.sessions(id), [id]);
  const exhibitors = useFetch(() => expoApi.exhibitors(id, { limit: 50 }), [id], { enabled: tab === 'exhibitors' });
  const booths = useFetch(() => expoApi.booths(id), [id], { enabled: tab === 'floor' });
  const myProfile = useFetch(() => exhibitorApi.me(), [id], { enabled: role === 'exhibitor' });
  const agenda = useAgenda();

  const [selectedBooth, setSelectedBooth] = useState(null);
  const [applyOpen, setApplyOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [note, setNote] = useState('');
  const [busyId, setBusyId] = useState('');

  const refreshSessions = sessions.refresh;
  const refreshBooths = booths.refresh;
  const refreshEvent = event.refresh;
  useSocketRefresh(socket, ['schedule-updated', 'booths-updated'], () => { refreshSessions(); refreshEvent(); if (tab === 'floor') refreshBooths(); });

  const e = event.data;
  const crumbs = [{ label: 'Home', to: '/' }, { label: rootLabel, to: rootTo || basePath }, { label: e ? e.title : 'Event' }];

  const registered = !!(event.data && event.data.isRegistered);
  const afterRegister = async () => {
    setRegisterOpen(false);
    toast('The organizer will confirm your request. You will be notified when your ticket is ready.', 'Registration sent', 'success');
    await Promise.all([event.refresh(), agenda.reload()]);
  };

  const unregister = async () => {
    const ok = await confirm({ title: 'Cancel your registration?', message: 'Your pass and any session tickets you hold for this event will be cancelled.', confirmLabel: 'Cancel registration', cancelLabel: 'Keep it', tone: 'danger' });
    if (!ok) return;
    try {
      const res = await attendeeApi.unregister(id);
      toast(res.ticketsCancelled ? `Registration and ${plural(res.ticketsCancelled, 'ticket')} cancelled.` : 'Registration cancelled.', 'Done', 'success');
      await Promise.all([event.refresh(), sessions.refresh(), agenda.reload()]);
    } catch (err) { toast(errMsg(err), 'Could not cancel', 'error'); }
  };

  const [apply, applying] = useSubmit(async () => {
    try {
      await exhibitorApi.apply(id, note.trim());
      toast('The organizer will review your application.', 'Application sent', 'success');
      setApplyOpen(false); setNote('');
      myProfile.refresh();
    } catch (err) { toast(errMsg(err), 'Could not apply', 'error'); }
  });

  const sessionAction = (sid, request, message) => async () => {
    setBusyId(sid);
    try {
      await request();
      await Promise.all([sessions.refresh(), agenda.reload()]);
      toast(message, 'Done', 'success');
    } catch (err) { toast(errMsg(err), 'Action failed', 'error'); sessions.refresh(); }
    finally { setBusyId(''); }
  };

  const openChat = (ex) => navigate(`/${role}/messages`, { state: { partner: { _id: ex.user, name: ex.companyName, role: 'exhibitor', companyName: ex.companyName } } });
  const countVisit = (ex) => { if (role === 'attendee') attendeeApi.visit(ex._id).catch(() => {}); };

  const wrapIf = (node) => (wrap ? <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">{node}</div> : node);

  if (event.error) return wrapIf(<><Breadcrumbs items={crumbs.slice(0, 2)} /><ErrorState message={event.error} onRetry={event.reload} /></>);
  if (!e) {
    return wrapIf(
      <>
        <Skeleton className="mb-4 h-5 w-64" />
        <Skeleton className="h-56 w-full rounded-xl sm:h-72" />
        <div className="mt-6 grid gap-6 lg:grid-cols-3"><Skeleton className="h-64 lg:col-span-2" /><Skeleton className="h-64" /></div>
      </>
    );
  }

  const regStatus = e.registration?.status || (registered ? 'confirmed' : '');
  const confirmed = registered && regStatus === 'confirmed';
  const ended = e.status === 'completed';
  const full = e.spotsLeft === 0 && !registered;
  const myApp = myProfile.data?.applications?.find((a) => a.expo?._id === id);
  const fill = e.capacity > 0 ? Math.min(100, Math.round((e.registeredCount / e.capacity) * 100)) : 0;
  const sessionList = sessions.data || [];

  const action = () => {
    if (ended) return <p className="rounded-lg bg-slate-50 p-3 text-center text-sm text-ink-muted">This event has ended.</p>;
    if (!user) return (
      <>
        <Link to="/login" state={{ from: location }} className="btn btn-primary w-full">Log in to register</Link>
        <p className="mt-2 text-center text-xs text-ink-muted">No account? <Link to="/register" className="link">Create one</Link></p>
      </>
    );
    if (role === 'attendee') {
      if (!registered) {
        return <button onClick={() => setRegisterOpen(true)} disabled={full} className="btn btn-primary w-full">{full ? 'Event is full' : 'Register for this event'}</button>;
      }
      const tone = regStatus === 'confirmed' ? 'bg-emerald-50 text-emerald-700' : regStatus === 'pending' ? 'bg-amber-50 text-amber-800' : 'bg-rose-50 text-rose-700';
      const text = regStatus === 'confirmed' ? 'You are registered' : regStatus === 'pending' ? 'Waiting for organizer approval' : 'Your request was not approved';
      return (
        <div className="space-y-2">
          <p className={`rounded-lg p-3 text-center text-sm font-medium ${tone}`}>{text}</p>
          {e.registration?.day && <p className="text-center text-xs text-ink-muted">{fmtShortDay(e.registration.day)} · {passName(e.registration.passType)}</p>}
          {confirmed && <Link to={`/tickets/${e.registration._id}`} className="btn btn-primary w-full"><QrCode size={16} /> View QR ticket</Link>}
          <button onClick={unregister} className="btn btn-secondary w-full">{regStatus === 'rejected' ? 'Remove request' : 'Cancel registration'}</button>
        </div>
      );
    }
    if (role === 'exhibitor') return myApp ? (
      <div className="space-y-2">
        <div className="flex items-center justify-between rounded-lg bg-slate-50 p-3 text-sm"><span>Your application</span><Badge status={myApp.status} /></div>
        <Link to={`/exhibitor/booths?expo=${id}`} className="btn btn-primary w-full"><Store size={16} /> {myApp.status === 'rejected' ? 'View details' : 'Manage booth'}</Link>
      </div>
    ) : (
      <button onClick={() => setApplyOpen(true)} disabled={myProfile.loading} className="btn btn-primary w-full">Apply to exhibit</button>
    );
    if (role === 'admin') return (
      <div className="space-y-2">
        <Link to={`/admin/events/${id}`} className="btn btn-primary w-full"><Settings2 size={16} /> Manage event</Link>
        <Link to={`/admin/events/${id}/edit`} className="btn btn-secondary w-full">Edit details</Link>
      </div>
    );
    return null;
  };

  return wrapIf(
    <>
      <Breadcrumbs items={crumbs} />
      <div className="relative overflow-hidden rounded-2xl">
        <EventBanner event={e} rounded={false} className="h-52 sm:h-72" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-navy-950/20 to-transparent" aria-hidden="true" />
        <div className="absolute inset-x-0 bottom-0 p-5 text-white sm:p-8">
          <div className="mb-2 flex flex-wrap gap-2"><Badge status="available" className="bg-white/90">{e.category}</Badge><Badge status={e.status} className="bg-white/90" />{!e.published && <Badge status="draft">Draft: only organizers see this</Badge>}</div>
          <h1 className="text-2xl font-semibold sm:text-4xl">{e.title}</h1>
          {e.theme && <p className="mt-1 text-white/80">{e.theme}</p>}
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_20rem]">
        <div className="min-w-0">
          <div role="tablist" aria-label="Event sections" className="mb-5 flex gap-1 overflow-x-auto border-b border-slate-200">
            {TABS.map((t) => (
              <button key={t.key} role="tab" aria-selected={tab === t.key} onClick={() => setParams(t.key === 'overview' ? {} : { tab: t.key }, { replace: true })}
                className={`-mb-px whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${tab === t.key ? 'border-brand text-brand-dark' : 'border-transparent text-ink-muted hover:text-ink'}`}>
                {t.label}{t.key === 'sessions' && sessionList.length ? ` (${sessionList.length})` : ''}
              </button>
            ))}
          </div>

          {tab === 'overview' && (
            <section className="card p-5 sm:p-6">
              <h2 className="text-lg font-semibold">About this event</h2>
              <p className="mt-3 whitespace-pre-line text-ink-muted">{e.description || 'The organizer has not added a description yet.'}</p>
              <dl className="mt-6 grid gap-4 border-t border-slate-100 pt-5 sm:grid-cols-3">
                <div><dt className="text-sm text-ink-muted">Sessions</dt><dd className="text-2xl font-semibold">{e.sessionCount}</dd></div>
                <div><dt className="text-sm text-ink-muted">Exhibitors</dt><dd className="text-2xl font-semibold">{e.exhibitorCount}</dd></div>
                <div><dt className="text-sm text-ink-muted">Booths free</dt><dd className="text-2xl font-semibold">{e.booths.available}<span className="text-base font-normal text-ink-muted"> of {e.booths.total}</span></dd></div>
              </dl>
            </section>
          )}

          {tab === 'sessions' && (
            sessions.error ? <ErrorState message={sessions.error} onRetry={sessions.reload} /> :
            sessions.loading && !sessions.data ? <Skeleton className="h-40" /> :
            sessionList.length === 0 ? <EmptyState icon={Clock} title="No sessions scheduled yet" text="Talks and workshops appear here as soon as the organizer adds them." /> : (
              <div className="space-y-3">
                {role === 'attendee' && !confirmed && !ended && <p className="rounded-lg bg-brand-soft p-3 text-sm text-brand-dark">{registered ? 'Session tickets open once the organizer confirms your registration.' : 'Register for this event to book session tickets.'} You can bookmark sessions at any time.</p>}
                {!user && <p className="rounded-lg bg-brand-soft p-3 text-sm text-brand-dark"><Link to="/login" state={{ from: location }} className="link">Log in</Link> to book sessions and build your agenda.</p>}
                {sessionList.map((s) => (
                  <SessionCard key={s._id} session={s}
                    {...(role === 'attendee' ? {
                      bookmarked: agenda.bookmarkedIds.has(s._id), booked: agenda.bookedIds.has(s._id), busy: busyId === s._id,
                      lockedReason: confirmed ? '' : registered ? 'Awaiting confirmation' : 'Register to book',
                      onBookmark: sessionAction(s._id, () => attendeeApi.bookmark(s._id), 'Your agenda was updated.'),
                      onBook: sessionAction(s._id, () => attendeeApi.book(s._id), 'Ticket booked.'),
                      onCancel: sessionAction(s._id, () => attendeeApi.cancelBooking(s._id), 'Ticket cancelled.'),
                    } : {})} />
                ))}
              </div>
            )
          )}

          {tab === 'exhibitors' && (
            exhibitors.error ? <ErrorState message={exhibitors.error} onRetry={exhibitors.reload} /> :
            exhibitors.loading && !exhibitors.data ? <Skeleton className="h-40" /> :
            !exhibitors.data?.data.length ? <EmptyState icon={Store} title="No exhibitors yet" text="Approved exhibitors show up here, with their booth numbers." /> : (
              <div className="grid gap-4 sm:grid-cols-2">
                {exhibitors.data.data.map((ex) => <ExhibitorCard key={ex._id} ex={ex} onOpen={countVisit} onMessage={user ? openChat : undefined} />)}
              </div>
            )
          )}

          {tab === 'floor' && (
            booths.error ? <ErrorState message={booths.error} onRetry={booths.reload} /> :
            booths.loading && !booths.data ? <Skeleton className="h-48" /> : (
              <section className="card p-5">
                <BoothGrid booths={booths.data || []} columns={e.floorPlan.columns} selectedId={selectedBooth?._id} onSelect={setSelectedBooth}
                  myExhibitorId={role === 'exhibitor' ? myProfile.data?._id : undefined} />
                <div className="mt-4"><BoothDetail booth={(booths.data || []).find((b) => b._id === selectedBooth?._id)} /></div>
              </section>
            )
          )}
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="card p-5">
            <dl className="space-y-4">
              <InfoRow icon={CalendarDays} label="Dates">{fmtDateRange(e.startDate, e.endDate)}</InfoRow>
              <InfoRow icon={Clock} label="Daily hours">{e.openTime} to {e.closeTime}</InfoRow>
              <InfoRow icon={MapPin} label="Venue">{e.venue || e.location}{e.venue && <span className="block font-normal text-ink-muted">{e.location}</span>}{e.address && <span className="block font-normal text-ink-muted">{e.address}</span>}<a href={directionsUrl([e.venue, e.address || e.location].filter(Boolean).join(', '))} target="_blank" rel="noreferrer" className="link mt-1 inline-block text-xs">Get directions ↗</a></InfoRow>
              <InfoRow icon={Users} label="Registrations">
                {e.registeredCount}{e.capacity > 0 ? ` of ${e.capacity}` : ' registered'}
                {e.capacity > 0 && <span className="mt-1.5 block h-1.5 rounded-full bg-slate-100"><span className="block h-1.5 rounded-full bg-gradient-to-r from-indigo-500 to-brand" style={{ width: `${fill}%` }} /></span>}
              </InfoRow>
              <InfoRow icon={Layers} label="Floor plan">{e.floorPlan.rows} rows by {e.floorPlan.columns} columns</InfoRow>
            </dl>
            <div className="mt-5 border-t border-slate-100 pt-5">{action()}</div>
          </div>
          {role === 'attendee' && registered && <Link to="/attendee/agenda" className="card flex items-center gap-3 p-4 text-sm font-medium transition-shadow hover:shadow-lift"><Ticket size={18} className="text-brand" /> Open my agenda</Link>}
        </aside>
      </div>

      {role === 'attendee' && <RegisterModal open={registerOpen} onClose={() => setRegisterOpen(false)} event={e} onDone={afterRegister} />}

      <Modal open={applyOpen} onClose={() => setApplyOpen(false)} busy={applying} title="Apply to exhibit" description={`Send your application for ${e.title}. You can pick a preferred booth afterwards.`}
        footer={<><button className="btn btn-secondary" onClick={() => setApplyOpen(false)} disabled={applying}>Cancel</button><button className="btn btn-primary" onClick={apply} disabled={applying}>{applying ? 'Sending…' : 'Send application'}</button></>}>
        <TextAreaField label="Message to the organizer (optional)" rows={4} maxLength={1000} value={note} onChange={(ev) => setNote(ev.target.value)} hint="Tell them what you will show and what you need." />
      </Modal>
    </>
  );
}
