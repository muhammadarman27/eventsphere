import { fmtMoney } from '../utils/format';

export default function BoothGrid({ booths, columns, selectedId, onSelect, myExhibitorId }) {
  const kind = (b) => {
    if (myExhibitorId && b.exhibitor && b.exhibitor._id === myExhibitorId) return 'mine';
    return b.status;
  };
  const styles = {
    available: 'border-slate-300 bg-white hover:border-brand hover:bg-brand-soft/60',
    reserved: 'border-amber-300 bg-amber-50 text-amber-900 hover:border-amber-500',
    booked: 'border-navy-700 bg-navy-800 text-white hover:border-brand-light',
    mine: 'border-brand bg-gradient-to-br from-indigo-600 to-brand text-white',
  };
  const legend = [
    { label: 'Available', cls: 'border-slate-300 bg-white' },
    { label: 'Reserved', cls: 'border-amber-300 bg-amber-50' },
    { label: 'Booked', cls: 'border-navy-700 bg-navy-800' },
  ];
  if (myExhibitorId) legend.push({ label: 'Yours', cls: 'border-brand bg-brand' });

  return (
    <div>
      <div className="overflow-x-auto pb-2">
        <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${columns}, minmax(4.25rem, 1fr))`, minWidth: `${columns * 4.75}rem` }}>
          {booths.map((b) => {
            const selected = b._id === selectedId;
            const k = kind(b);
            const Tag = onSelect ? 'button' : 'div';
            return (
              <Tag
                key={b._id}
                type={onSelect ? 'button' : undefined}
                onClick={onSelect ? () => onSelect(b) : undefined}
                aria-pressed={onSelect ? selected : undefined}
                aria-label={`Booth ${b.boothNumber}, ${k === 'mine' ? 'yours' : b.status}, ${b.size}, ${fmtMoney(b.price)}${b.exhibitor ? `, ${b.exhibitor.companyName}` : ''}`}
                className={`flex min-h-[4.25rem] flex-col justify-between rounded-lg border p-2 text-left text-xs transition-all ${styles[k]} ${
                  selected ? 'ring-2 ring-brand ring-offset-2' : ''
                } ${b.size === 'large' ? 'border-b-2' : ''}`}
              >
                <span className="text-sm font-semibold">{b.boothNumber}</span>
                <span className="truncate opacity-80">{b.exhibitor ? b.exhibitor.companyName : b.size === 'large' ? 'Large' : 'Free'}</span>
              </Tag>
            );
          })}
        </div>
      </div>
      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-ink-muted">
        {legend.map((l) => (
          <li key={l.label} className="flex items-center gap-1.5">
            <span className={`inline-block h-3 w-3 rounded border ${l.cls}`} aria-hidden="true" />
            {l.label}
          </li>
        ))}
      </ul>
    </div>
  );
}
