import Logo from './Logo';

const highlighted = new Set([1, 4, 8, 13, 16, 19, 22]);
const booked = new Set([0, 3, 9, 10, 14, 18, 20]);

export default function AuthShell({ title, subtitle, children, notice }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-navy-900 p-12 text-white lg:flex">
        <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-brand/30 blur-3xl" aria-hidden="true" />
        <Logo />
        <div className="relative">
          <div className="grid max-w-md grid-cols-6 gap-2" aria-hidden="true">
            {Array.from({ length: 24 }).map((_, i) => (
              <div
                key={i}
                className={`flex aspect-[4/3] items-end rounded-md p-1 text-[10px] ${
                  highlighted.has(i) ? 'bg-gradient-to-br from-indigo-500 to-brand text-white' : booked.has(i) ? 'bg-white/15' : 'border border-white/15 text-white/45'
                }`}
              >
                {String.fromCharCode(65 + Math.floor(i / 6))}{(i % 6) + 1}
              </div>
            ))}
          </div>
          <p className="mt-10 max-w-md text-4xl font-semibold leading-tight">Every booth, session and conversation of your expo in one place.</p>
        </div>
        <p className="relative text-sm text-white/60">Organizers, exhibitors and attendees share one live floor plan.</p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden"><Logo light={false} /></div>
          <h1 className="text-3xl font-semibold">{title}</h1>
          {subtitle && <p className="mt-2 text-ink-muted">{subtitle}</p>}
          {notice && <p role="status" className="mt-4 rounded-lg bg-brand-soft p-3 text-sm text-brand-dark">{notice}</p>}
          <div className="mt-8">{children}</div>
        </div>
      </div>
    </div>
  );
}
