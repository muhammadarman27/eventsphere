import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarDays, Heart, Search, X } from 'lucide-react';
import { expoApi } from '../api/services';
import useDebounce from '../hooks/useDebounce';
import useFetch from '../hooks/useFetch';
import useSavedExpos from '../hooks/useSavedExpos';
import { CATEGORIES } from '../utils/constants';
import EventCard from './EventCard';
import EmptyState from './EmptyState';
import ErrorState from './ErrorState';
import Pagination from './Pagination';
import { CardGridSkeleton } from './Skeleton';

const STATUSES = [
  { value: '', label: 'All' },
  { value: 'upcoming', label: 'Upcoming' },
  { value: 'ongoing', label: 'Live now' },
  { value: 'completed', label: 'Past' },
];
const SORTS = [
  { value: 'date_asc', label: 'Soonest first' },
  { value: 'date_desc', label: 'Latest first' },
  { value: 'popular', label: 'Most popular' },
  { value: 'newest', label: 'Recently added' },
];

export default function EventsExplorer({ basePath }) {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const category = params.get('category') || '';
  const status = params.get('status') || '';
  const from = params.get('from') || '';
  const to = params.get('to') || '';
  const sort = params.get('sort') || 'date_asc';
  const page = Number(params.get('page')) || 1;
  const onlySaved = params.get('saved') === '1';
  const savedExpos = useSavedExpos();

  const update = (patch, { keepPage = false, replace = true } = {}) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!keepPage) next.delete('page');
    setParams(next, { replace });
  };

  const [qInput, setQInput] = useState(q);
  const debouncedQ = useDebounce(qInput, 350);
  useEffect(() => { if (debouncedQ.trim() !== q) update({ q: debouncedQ.trim() }); }, [debouncedQ]);
  useEffect(() => { setQInput(q); }, [q]);

  const { data, loading, error, reload } = useFetch(
    () => expoApi.list({ search: q, category, status, from, to, sort, page: onlySaved ? 1 : page, limit: onlySaved ? 100 : 9 }),
    [q, category, status, from, to, sort, page, onlySaved]
  );

  const active = q || category || status || from || to || onlySaved;
  const clear = () => { setQInput(''); setParams({}, { replace: true }); };
  const events = onlySaved ? (data?.data || []).filter((e) => savedExpos.has(e._id)) : data?.data || [];

  return (
    <div>
      <div className="card mb-6 space-y-4 p-4">
        <div className="grid gap-3 md:grid-cols-[1fr_12rem_11rem]">
          <div className="relative">
            <label htmlFor="ev-search" className="sr-only">Search events</label>
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
            <input id="ev-search" type="search" className="input pl-9" placeholder="Search by name, theme or place" value={qInput} onChange={(e) => setQInput(e.target.value)} />
          </div>
          <div>
            <label htmlFor="ev-cat" className="sr-only">Category</label>
            <select id="ev-cat" className="input" value={category} onChange={(e) => update({ category: e.target.value })}>
              <option value="">All categories</option>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="ev-sort" className="sr-only">Sort by</label>
            <select id="ev-sort" className="input" value={sort} onChange={(e) => update({ sort: e.target.value === 'date_asc' ? '' : e.target.value })}>
              {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-end gap-x-6 gap-y-3">
          <div role="group" aria-label="Event timing" className="flex flex-wrap gap-1.5">
            {STATUSES.map((s) => (
              <button key={s.value} onClick={() => update({ status: s.value })} aria-pressed={status === s.value}
                className={`btn btn-sm ${status === s.value ? 'btn-primary' : 'btn-secondary'}`}>{s.label}</button>
            ))}
          </div>
          <div className="flex items-end gap-2">
            <div><label htmlFor="ev-from" className="mb-1 block text-xs text-ink-muted">From</label><input id="ev-from" type="date" className="input py-1.5" value={from} max={to || undefined} onChange={(e) => update({ from: e.target.value })} /></div>
            <div><label htmlFor="ev-to" className="mb-1 block text-xs text-ink-muted">To</label><input id="ev-to" type="date" className="input py-1.5" value={to} min={from || undefined} onChange={(e) => update({ to: e.target.value })} /></div>
          </div>
          <button onClick={() => update({ saved: onlySaved ? '' : '1' })} aria-pressed={onlySaved} className={`btn btn-sm ${onlySaved ? 'btn-primary' : 'btn-secondary'}`}><Heart size={14} aria-hidden="true" /> Saved ({savedExpos.ids.length})</button>
          {active && <button onClick={clear} className="btn btn-ghost btn-sm"><X size={15} /> Clear filters</button>}
        </div>
      </div>

      <p className="mb-4 text-sm text-ink-muted" aria-live="polite">
        {loading && !data ? 'Loading events…' : data ? `${onlySaved ? events.length : data.pagination.total} ${(onlySaved ? events.length : data.pagination.total) === 1 ? 'event' : 'events'} found` : ''}
      </p>

      {error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : loading && !data ? (
        <CardGridSkeleton />
      ) : events.length === 0 ? (
        <EmptyState icon={CalendarDays} title="No events match your search" text={active ? 'Try different keywords or clear the filters.' : 'No events have been published yet. Check back soon.'}
          action={active ? <button onClick={clear} className="btn btn-secondary">Clear filters</button> : null} />
      ) : (
        <div className={`grid gap-5 sm:grid-cols-2 xl:grid-cols-3 ${loading ? 'opacity-60 transition-opacity' : ''}`}>
          {events.map((e) => <EventCard key={e._id} event={e} basePath={basePath} />)}
        </div>
      )}

      {!onlySaved && <Pagination pagination={data?.pagination} onPage={(p) => { update({ page: p === 1 ? '' : String(p) }, { keepPage: true, replace: false }); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />}
    </div>
  );
}
