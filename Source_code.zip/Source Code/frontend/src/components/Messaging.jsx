import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { ArrowLeft, MessageSquarePlus, Search, Send } from 'lucide-react';
import { errMsg } from '../api/api';
import { messageApi } from '../api/services';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useDebounce from '../hooks/useDebounce';
import useFetch from '../hooks/useFetch';
import { fmtDateTime, initials, timeAgo } from '../utils/format';
import Badge from './Badge';
import Modal from './Modal';
import ErrorState from './ErrorState';
import { Spinner } from './Skeleton';

const partnerLabel = (p) => (p.companyName ? `${p.companyName} (${p.name})` : p.name);

function Avatar({ name, size = 'h-10 w-10' }) {
  return <span className={`flex ${size} shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-brand text-xs font-semibold text-white`} aria-hidden="true">{initials(name)}</span>;
}

function NewChatModal({ open, onClose, onPick }) {
  const [q, setQ] = useState('');
  const debounced = useDebounce(q, 300);
  const { data, loading, error, reload } = useFetch(() => messageApi.contacts(debounced), [debounced], { enabled: open });

  return (
    <Modal open={open} onClose={onClose} title="Start a chat" description="Choose who you would like to message.">
      <div className="relative mb-3">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        <input data-autofocus aria-label="Search people" className="input pl-9" placeholder="Search by name or company" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading ? (
        <div className="flex justify-center py-8 text-brand"><Spinner /></div>
      ) : !data?.length ? (
        <p className="py-6 text-center text-sm text-ink-muted">No one found. Try a different name.</p>
      ) : (
        <ul className="divide-y divide-slate-100">
          {data.map((c) => (
            <li key={c._id}>
              <button onClick={() => onPick(c)} className="flex w-full items-center gap-3 rounded-lg px-2 py-3 text-left hover:bg-slate-50">
                <Avatar name={c.companyName || c.name} />
                <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{partnerLabel(c)}</span><span className="text-xs capitalize text-ink-muted">{c.role}</span></span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}

export default function Messaging() {
  const { user } = useAuth();
  const { socket, toast, refreshUnreadMessages } = useSocket();
  const location = useLocation();

  const conversations = useFetch(() => messageApi.conversations(), []);
  const [active, setActive] = useState(null);
  const [thread, setThread] = useState([]);
  const [threadState, setThreadState] = useState({ loading: false, error: '' });
  const [text, setText] = useState('');
  const [type, setType] = useState('message');
  const [slot, setSlot] = useState('');
  const [sending, setSending] = useState(false);
  const [picker, setPicker] = useState(false);

  const listRef = useRef(null);
  const activeRef = useRef(null);
  activeRef.current = active;
  const reloadConversations = conversations.refresh;

  const openThread = useCallback(async (partner) => {
    setActive(partner);
    setThread([]);
    setThreadState({ loading: true, error: '' });
    try {
      const messages = await messageApi.thread(partner._id);
      if (activeRef.current?._id !== partner._id) return;
      setThread(messages);
      setThreadState({ loading: false, error: '' });
      refreshUnreadMessages();
      reloadConversations();
    } catch (e) {
      if (activeRef.current?._id === partner._id) setThreadState({ loading: false, error: errMsg(e) });
    }
  }, [refreshUnreadMessages, reloadConversations]);

  const startPartner = location.state?.partner;
  useEffect(() => { if (startPartner) openThread(startPartner); }, [startPartner?._id]);

  useEffect(() => {
    if (!socket) return undefined;
    const onMessage = (m) => {
      reloadConversations();
      if (activeRef.current && m.sender === activeRef.current._id) {
        setThread((list) => (list.some((x) => x._id === m._id) ? list : [...list, m]));
        messageApi.markRead(m.sender).then(refreshUnreadMessages).catch(() => {});
      }
    };
    socket.on('message', onMessage);
    return () => socket.off('message', onMessage);
  }, [socket, reloadConversations, refreshUnreadMessages]);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [thread, threadState.loading]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim() || !active || sending) return;
    const body = { receiver: active._id, content: text.trim(), type };
    if (type === 'appointment') {
      if (!slot || new Date(slot) <= new Date()) {
        toast('Pick a date and time in the future for the appointment.', 'Check the time', 'error');
        return;
      }
      body.appointmentSlot = new Date(slot).toISOString();
    }
    setSending(true);
    try {
      const sent = await messageApi.send(body);
      setThread((list) => [...list, sent]);
      setText(''); setType('message'); setSlot('');
      reloadConversations();
    } catch (err) {
      toast(errMsg(err), 'Message not sent', 'error');
    } finally {
      setSending(false);
    }
  };

  const canRequest = user.role === 'attendee' && active?.role === 'exhibitor';
  const list = conversations.data || [];

  return (
    <div className="card grid h-[calc(100vh-13rem)] min-h-[30rem] overflow-hidden md:grid-cols-[19rem_1fr]">
      <div className={`min-h-0 flex-col border-slate-200 md:flex md:border-r ${active ? 'hidden' : 'flex'}`}>
        <div className="flex items-center justify-between border-b border-slate-100 p-3">
          <h2 className="px-1 text-sm font-semibold">Conversations</h2>
          <button className="btn btn-secondary btn-sm" onClick={() => setPicker(true)}><MessageSquarePlus size={15} /> New chat</button>
        </div>
        <ul className="min-h-0 flex-1 overflow-y-auto">
          {conversations.loading && <li className="flex justify-center py-10 text-brand"><Spinner /></li>}
          {conversations.error && <li className="p-4"><ErrorState message={conversations.error} onRetry={conversations.reload} /></li>}
          {!conversations.loading && !conversations.error && list.length === 0 && (
            <li className="p-6 text-center text-sm text-ink-muted">No conversations yet. Use “New chat” to say hello.</li>
          )}
          {list.map((c) => (
            <li key={c.partner._id}>
              <button onClick={() => openThread(c.partner)} className={`flex w-full items-center gap-3 border-b border-slate-100 px-3 py-3 text-left hover:bg-slate-50 ${active?._id === c.partner._id ? 'bg-brand-soft/50' : ''}`}>
                <Avatar name={c.partner.companyName || c.partner.name} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-medium">{c.partner.companyName || c.partner.name}</span>
                    <span className="shrink-0 text-[11px] text-slate-400">{timeAgo(c.lastAt)}</span>
                  </span>
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate text-xs text-ink-muted">{c.lastMessage}</span>
                    {c.unread > 0 && <span className="rounded-full bg-brand px-1.5 text-[11px] font-semibold text-white" aria-label={`${c.unread} unread`}>{c.unread}</span>}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div className={`min-h-0 flex-col md:flex ${active ? 'flex' : 'hidden'}`}>
        {!active ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 p-6 text-center text-sm text-ink-muted">
            <MessageSquarePlus size={28} className="text-brand" aria-hidden="true" />
            Select a conversation or start a new chat.
          </div>
        ) : (
          <>
            <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3">
              <button className="btn btn-ghost btn-icon -ml-2 md:hidden" onClick={() => setActive(null)} aria-label="Back to conversations"><ArrowLeft size={18} /></button>
              <Avatar name={active.companyName || active.name} size="h-9 w-9" />
              <div className="min-w-0"><p className="truncate font-medium">{partnerLabel(active)}</p><p className="text-xs capitalize text-ink-muted">{active.role}</p></div>
            </div>

            <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto bg-slate-50/50 p-4" aria-live="polite">
              {threadState.loading && <div className="flex justify-center py-10 text-brand"><Spinner /></div>}
              {threadState.error && <ErrorState message={threadState.error} onRetry={() => openThread(active)} />}
              {!threadState.loading && !threadState.error && thread.length === 0 && <p className="py-10 text-center text-sm text-ink-muted">No messages yet. Say hello.</p>}
              {thread.map((m) => {
                const mine = m.sender === user.id;
                return (
                  <div key={m._id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm sm:max-w-[75%] ${mine ? 'rounded-br-md bg-gradient-to-br from-indigo-600 to-brand text-white' : 'rounded-bl-md border border-slate-200 bg-white'}`}>
                      <span className="sr-only">{mine ? 'You' : active.name}: </span>
                      {m.type && m.type !== 'message' && <div className="mb-1"><Badge status="pending">{m.type}</Badge></div>}
                      <p className="whitespace-pre-wrap break-words">{m.content}</p>
                      {m.appointmentSlot && <p className="mt-1 text-xs opacity-85">Requested time: {fmtDateTime(m.appointmentSlot)}</p>}
                      <p className={`mt-1 text-[11px] ${mine ? 'text-white/70' : 'text-slate-400'}`}>{fmtDateTime(m.createdAt)}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <form onSubmit={send} className="space-y-2 border-t border-slate-100 p-3">
              {canRequest && (
                <div className="flex flex-wrap items-center gap-2">
                  <select aria-label="Message type" className="input w-auto" value={type} onChange={(e) => setType(e.target.value)}>
                    <option value="message">Message</option>
                    <option value="inquiry">Product inquiry</option>
                    <option value="appointment">Appointment request</option>
                  </select>
                  {type === 'appointment' && <input type="datetime-local" aria-label="Appointment time" className="input w-auto" value={slot} onChange={(e) => setSlot(e.target.value)} />}
                </div>
              )}
              <div className="flex gap-2">
                <input aria-label="Write a message" className="input" placeholder="Write a message" maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} />
                <button className="btn btn-primary btn-icon" disabled={sending || !text.trim()} aria-label="Send message">{sending ? <Spinner size={16} /> : <Send size={16} />}</button>
              </div>
            </form>
          </>
        )}
      </div>

      <NewChatModal open={picker} onClose={() => setPicker(false)} onPick={(c) => { setPicker(false); openThread(c); }} />
    </div>
  );
}
