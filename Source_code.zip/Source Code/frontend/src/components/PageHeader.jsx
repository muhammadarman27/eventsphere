import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export function Breadcrumbs({ items = [], dark = false }) {
  if (!items.length) return null;
  return (
    <nav aria-label="Breadcrumb" className="mb-2">
      <ol className={`flex flex-wrap items-center gap-1 text-sm ${dark ? 'text-white/70' : 'text-ink-muted'}`}>
        {items.map((item, i) => (
          <li key={item.label} className="flex items-center gap-1">
            {i > 0 && <ChevronRight size={14} aria-hidden="true" />}
            {item.to ? (
              <Link to={item.to} className={`${dark ? 'hover:text-white' : 'hover:text-brand-dark'} hover:underline`}>{item.label}</Link>
            ) : (
              <span aria-current="page" className={`max-w-[16rem] truncate ${dark ? 'text-white' : 'font-medium text-ink'}`}>{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export default function PageHeader({ title, subtitle, actions, breadcrumbs }) {
  return (
    <header className="mb-6">
      <Breadcrumbs items={breadcrumbs} />
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold md:text-[1.75rem]">{title}</h1>
          {subtitle && <p className="mt-1 max-w-2xl text-sm text-ink-muted md:text-base">{subtitle}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </header>
  );
}
