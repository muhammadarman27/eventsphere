export default function EmptyState({ icon: Icon, title, text, action }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-white/60 px-6 py-12 text-center">
      {Icon && (
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-soft text-brand-dark">
          <Icon size={22} aria-hidden="true" />
        </div>
      )}
      <p className="text-base font-semibold">{title}</p>
      {text && <p className="mx-auto mt-1 max-w-sm text-sm text-ink-muted">{text}</p>}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}
