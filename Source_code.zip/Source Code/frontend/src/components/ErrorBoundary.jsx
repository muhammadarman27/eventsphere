import { Component } from 'react';

export default class ErrorBoundary extends Component {
  state = { failed: false };

  static getDerivedStateFromError() { return { failed: true }; }

  componentDidCatch(error) { console.error('UI error:', error); }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
        <h1 className="text-2xl font-semibold">Something went wrong</h1>
        <p className="mt-2 max-w-md text-ink-muted">This page hit an unexpected problem. Your data is safe. Reload to try again.</p>
        <button className="btn btn-primary mt-6" onClick={() => window.location.reload()}>Reload page</button>
      </div>
    );
  }
}
