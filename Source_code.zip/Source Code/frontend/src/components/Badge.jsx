const styles = {
  approved: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  confirmed: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  booked: 'bg-indigo-50 text-indigo-700 ring-indigo-200',
  registered: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  ongoing: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  live: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  pending: 'bg-amber-50 text-amber-800 ring-amber-200',
  reserved: 'bg-amber-50 text-amber-800 ring-amber-200',
  soon: 'bg-amber-50 text-amber-800 ring-amber-200',
  rejected: 'bg-rose-50 text-rose-700 ring-rose-200',
  full: 'bg-rose-50 text-rose-700 ring-rose-200',
  upcoming: 'bg-violet-50 text-violet-700 ring-violet-200',
  draft: 'bg-slate-100 text-slate-700 ring-slate-300',
  completed: 'bg-slate-100 text-slate-600 ring-slate-200',
  ended: 'bg-slate-100 text-slate-600 ring-slate-200',
  available: 'bg-slate-50 text-slate-700 ring-slate-200',
  info: 'bg-sky-50 text-sky-700 ring-sky-200',
};
const labels = { ongoing: 'Live now', live: 'Live now', soon: 'Starting soon', completed: 'Ended' };

export default function Badge({ status = 'available', children, className = '' }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ring-1 ring-inset ${styles[status] || styles.available} ${className}`}>
      {children || labels[status] || status}
    </span>
  );
}
