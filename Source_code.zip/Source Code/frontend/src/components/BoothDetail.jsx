import Badge from './Badge';
import { fmtMoney } from '../utils/format';

export default function BoothDetail({ booth, mine = false, showVisits = false, children }) {
  if (!booth) {
    return <p className="rounded-lg bg-slate-50 p-4 text-sm text-ink-muted">Select a booth on the floor plan to see its details.</p>;
  }
  return (
    <div className="rounded-xl border border-brand/20 bg-brand-soft/40 p-4" aria-live="polite">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-lg font-semibold">Booth {booth.boothNumber}</h3>
        <Badge status={mine ? 'booked' : booth.status}>{mine ? 'Yours' : booth.status}</Badge>
      </div>
      <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
        <div><dt className="text-ink-muted">Size</dt><dd className="font-medium capitalize">{booth.size}</dd></div>
        <div><dt className="text-ink-muted">Price</dt><dd className="font-medium">{fmtMoney(booth.price)}</dd></div>
        <div><dt className="text-ink-muted">Position</dt><dd className="font-medium">Row {booth.row + 1}, column {booth.column + 1}</dd></div>
        {booth.exhibitor && (
          <div className="col-span-2 sm:col-span-3"><dt className="text-ink-muted">Exhibitor</dt>
            <dd className="font-medium">{booth.exhibitor.companyName}{booth.exhibitor.category ? <span className="ml-2 text-ink-muted">({booth.exhibitor.category})</span> : null}</dd></div>
        )}
        {showVisits && <div><dt className="text-ink-muted">Visits</dt><dd className="font-medium">{booth.visitorCount || 0}</dd></div>}
      </dl>
      {children && <div className="mt-4 flex flex-wrap gap-2">{children}</div>}
    </div>
  );
}
