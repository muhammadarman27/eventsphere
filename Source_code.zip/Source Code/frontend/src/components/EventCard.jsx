import { Link } from 'react-router-dom';
import { CalendarDays, Heart, MapPin, Users } from 'lucide-react';
import useSavedExpos from '../hooks/useSavedExpos';
import Badge from './Badge';
import EventBanner from './EventBanner';
import { fmtDateRange } from '../utils/format';

function availability(event) {
  if (event.isRegistered) return { status: 'registered', text: 'Registered' };
  if (event.status === 'completed') return { status: 'ended', text: 'Ended' };
  if (event.spotsLeft === 0) return { status: 'full', text: 'Full' };
  if (event.spotsLeft !== null && event.spotsLeft !== undefined) return { status: 'available', text: `${event.spotsLeft} spots left` };
  return { status: 'available', text: 'Open registration' };
}

export default function EventCard({ event, basePath }) {
  const avail = availability(event);
  const saved = useSavedExpos();
  const isSaved = saved.has(event._id);
  return (
    <article className="card group relative flex flex-col overflow-hidden transition-shadow hover:shadow-lift">
      <div className="relative">
        <EventBanner event={event} className="h-36 transition-transform duration-300 group-hover:scale-[1.02]" />
        <div className="absolute left-3 top-3 flex gap-1.5">
          <span className="rounded-full bg-white/95 px-2.5 py-0.5 text-xs font-medium text-ink shadow-sm">{event.category}</span>
        </div>
        <div className="absolute right-3 top-3"><Badge status={event.status} className="bg-white/95 shadow-sm" /></div>
        <button type="button" onClick={() => saved.toggle(event._id)} aria-pressed={isSaved} aria-label={isSaved ? `Remove ${event.title} from saved events` : `Save ${event.title} for later`}
          className="absolute bottom-3 right-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/95 shadow-sm transition-colors hover:bg-white">
          <Heart size={16} className={isSaved ? 'fill-rose-500 text-rose-500' : 'text-slate-500'} aria-hidden="true" />
        </button>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="text-base font-semibold leading-snug">
          <Link to={`${basePath}/${event._id}`} className="after:absolute after:inset-0 focus-visible:outline-none">
            {event.title}
          </Link>
        </h3>
        {event.theme && <p className="mt-0.5 line-clamp-1 text-sm text-ink-muted">{event.theme}</p>}
        <ul className="mt-3 space-y-1.5 text-sm text-ink-muted">
          <li className="flex items-center gap-2"><CalendarDays size={15} aria-hidden="true" />{fmtDateRange(event.startDate, event.endDate)}</li>
          <li className="flex items-center gap-2"><MapPin size={15} aria-hidden="true" /><span className="truncate">{event.venue ? `${event.venue}, ${event.location}` : event.location}</span></li>
        </ul>
        <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
          <span className="flex items-center gap-1.5 text-sm"><Users size={15} className="text-slate-400" aria-hidden="true" /><Badge status={avail.status}>{avail.text}</Badge></span>
          <span className="text-sm font-medium text-brand-dark">View details</span>
        </div>
      </div>
    </article>
  );
}
