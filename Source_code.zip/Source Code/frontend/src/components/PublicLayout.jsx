import { Suspense, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { Mail, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CONTACT_EMAIL } from '../utils/constants';
import Logo from './Logo';
import ErrorBoundary from './ErrorBoundary';
import { Spinner } from './Skeleton';

function Navbar({ transparent }) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname, location.hash]);

  const link = ({ isActive }) => `rounded-lg px-3 py-2 text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-white/70 hover:text-white'}`;
  return (
    <header className={`${transparent ? 'absolute inset-x-0 top-0' : 'bg-navy-900'} z-30`}>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          <NavLink to="/events" className={link}>Explore events</NavLink>
          <a href="/#how-it-works" className="rounded-lg px-3 py-2 text-sm font-medium text-white/70 hover:text-white">How it works</a>
          <a href="#contact" className="rounded-lg px-3 py-2 text-sm font-medium text-white/70 hover:text-white">Contact</a>
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <Link to={`/${user.role}`} className="btn btn-light btn-sm">Go to dashboard</Link>
          ) : (
            <>
              <Link to="/login" className="btn btn-sm text-white hover:bg-white/10">Log in</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Get started</Link>
            </>
          )}
        </div>
        <button className="btn btn-icon text-white hover:bg-white/10 md:hidden" onClick={() => setOpen((o) => !o)} aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 bg-navy-900 px-4 pb-4 md:hidden">
          <nav className="flex flex-col py-2" aria-label="Mobile">
            <Link to="/events" className="rounded-lg px-3 py-3 text-white/90 hover:bg-white/5">Explore events</Link>
            <a href="/#how-it-works" className="rounded-lg px-3 py-3 text-white/90 hover:bg-white/5">How it works</a>
            <a href="#contact" className="rounded-lg px-3 py-3 text-white/90 hover:bg-white/5">Contact</a>
          </nav>
          <div className="flex gap-2">
            {user ? (
              <Link to={`/${user.role}`} className="btn btn-light flex-1">Go to dashboard</Link>
            ) : (
              <>
                <Link to="/login" className="btn btn-outline-light flex-1">Log in</Link>
                <Link to="/register" className="btn btn-primary flex-1">Get started</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer id="contact" className="bg-navy-950 text-white/70">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed">One place for organizers, exhibitors and attendees to run and enjoy expos: events, booths, sessions and conversations.</p>
          <a href={`mailto:${CONTACT_EMAIL}`} className="mt-4 inline-flex items-center gap-2 text-sm text-white hover:underline"><Mail size={16} /> {CONTACT_EMAIL}</a>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold text-white">Explore</h2>
          <ul className="space-y-2 text-sm">
            <li><Link to="/events" className="hover:text-white">All events</Link></li>
            <li><Link to="/events?status=upcoming" className="hover:text-white">Upcoming events</Link></li>
            <li><Link to="/events?status=completed" className="hover:text-white">Past events</Link></li>
            <li><a href="/#how-it-works" className="hover:text-white">How it works</a></li>
          </ul>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold text-white">Account</h2>
          <ul className="space-y-2 text-sm">
            <li><Link to="/login" className="hover:text-white">Log in</Link></li>
            <li><Link to="/register" className="hover:text-white">Create an account</Link></li>
            <li><Link to="/forgot-password" className="hover:text-white">Reset password</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 px-4 py-5 text-center text-xs sm:px-6">
        © {new Date().getFullYear()} EventSphere. All rights reserved.
      </div>
    </footer>
  );
}

export default function PublicLayout() {
  const location = useLocation();
  const isLanding = location.pathname === '/';
  useEffect(() => { if (!location.hash) window.scrollTo(0, 0); }, [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar transparent={isLanding} />
      <main className="flex-1">
        <ErrorBoundary key={location.pathname}>
          <Suspense fallback={<div className="flex justify-center py-32 text-brand"><Spinner size={26} /></div>}>
            <Outlet />
          </Suspense>
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
}
