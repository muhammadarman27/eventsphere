import { AlertTriangle, RefreshCw } from 'lucide-react';

export default function ErrorState({ message, onRetry }) {
  return (
    <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-6 py-10 text-center">
      <div className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-rose-100 text-rose-600">
        <AlertTriangle size={22} aria-hidden="true" />
      </div>
      <p className="font-semibold text-rose-900">We could not load this</p>
      <p className="mx-auto mt-1 max-w-md text-sm text-rose-800">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn btn-secondary mt-4">
          <RefreshCw size={16} /> Try again
        </button>
      )}
    </div>
  );
}
