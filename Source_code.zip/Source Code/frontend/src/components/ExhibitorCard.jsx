import { useState } from 'react';
import { ExternalLink, MessageSquare } from 'lucide-react';
import Badge from './Badge';

export default function ExhibitorCard({ ex, onMessage, onOpen }) {
  const [open, setOpen] = useState(false);
  const toggle = () => {
    if (!open && onOpen) onOpen(ex);
    setOpen((o) => !o);
  };

  return (
    <article className="card flex flex-col p-5">
      <div className="flex items-start gap-3">
        {ex.logo ? (
          <img src={ex.logo} alt={`${ex.companyName} logo`} loading="lazy" className="h-12 w-12 shrink-0 rounded-lg border border-slate-200 object-cover"
            onError={(e) => { e.currentTarget.style.display = 'none'; }} />
        ) : (
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-brand text-lg font-semibold text-white" aria-hidden="true">{ex.companyName[0]}</div>
        )}
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold">{ex.companyName}</h3>
          <div className="mt-1 flex flex-wrap gap-1.5">
            <Badge status="available">{ex.category}</Badge>
            {ex.boothNumber && <Badge status="booked">Booth {ex.boothNumber}</Badge>}
          </div>
        </div>
      </div>

      <p className="mt-3 line-clamp-3 text-sm text-ink-muted">{ex.description || 'This exhibitor has not added a description yet.'}</p>

      {open && (
        <div className="mt-3 rounded-lg bg-slate-50 p-3 text-sm">
          <p className="mb-1 font-medium">Products</p>
          {ex.products.length === 0 ? <p className="text-ink-muted">No products listed.</p> : (
            <ul className="space-y-1">
              {ex.products.map((p) => <li key={p._id || p.name}><strong>{p.name}</strong>{p.description ? `: ${p.description}` : ''}</li>)}
            </ul>
          )}
          {ex.website && (
            <a href={ex.website} target="_blank" rel="noopener noreferrer" className="link mt-2 inline-flex items-center gap-1 break-all">
              {ex.website.replace(/^https?:\/\//, '')} <ExternalLink size={13} aria-hidden="true" />
            </a>
          )}
        </div>
      )}

      <div className="mt-auto flex gap-2 pt-4">
        <button onClick={toggle} aria-expanded={open} className="btn btn-secondary btn-sm">{open ? 'Hide details' : 'View details'}</button>
        {onMessage && ex.user && <button onClick={() => onMessage(ex)} className="btn btn-primary btn-sm"><MessageSquare size={15} /> Message</button>}
      </div>
    </article>
  );
}
