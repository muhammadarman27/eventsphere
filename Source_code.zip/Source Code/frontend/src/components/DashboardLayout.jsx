import { Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { ChevronDown, Globe, LogOut, Menu, User, WifiOff, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useDismiss from '../hooks/useDismiss';
import { NAV, titleFor } from '../utils/navigation';
import { ROLE_LABELS } from '../utils/constants';
import { initials } from '../utils/format';
import Logo from './Logo';
import NotificationBell from './NotificationBell';
import ErrorBoundary from './ErrorBoundary';
import { Spinner } from './Skeleton';

function ProfileMenu() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const close = useCallback(() => setOpen(false), []);
  useDismiss(ref, open, close);

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} aria-haspopup="true" aria-expanded={open} className="flex items-center gap-2 rounded-lg p-1 pr-2 hover:bg-slate-100">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-brand text-xs font-semibold text-white">{initials(user.name)}</span>
        <span className="hidden max-w-[9rem] truncate text-sm font-medium sm:block">{user.name}</span>
        <ChevronDown size={16} className="text-slate-400" aria-hidden="true" />
      </button>
      {open && (
        <div className="absolute right-0 z-40 mt-2 w-64 animate-pop overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lift">
          <div className="border-b border-slate-100 px-4 py-3">
            <p className="truncate text-sm font-semibold">{user.name}</p>
            <p className="truncate text-xs text-ink-muted">{user.email}</p>
            <p className="mt-1 text-xs font-medium text-brand-dark">{ROLE_LABELS[user.role]}</p>
          </div>
          <div className="p-1.5">
            <button onClick={() => { close(); navigate(`/${user.role}/account`); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-50"><User size={16} /> Account and password</button>
            <Link to="/events" onClick={close} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-50"><Globe size={16} /> Public site</Link>
            <button onClick={() => { close(); logout(); navigate('/'); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose-600 hover:bg-rose-50"><LogOut size={16} /> Log out</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function DashboardLayout({ role }) {
  const { user } = useAuth();
  const { unreadMessages, connected } = useSocket();
  const location = useLocation();
  const [drawer, setDrawer] = useState(false);
  const items = NAV[role];

  useEffect(() => { setDrawer(false); window.scrollTo(0, 0); }, [location.pathname]);
  useEffect(() => { document.title = `${titleFor(role, location.pathname)} | EventSphere`; }, [role, location.pathname]);
  useEffect(() => {
    if (!drawer) return undefined;
    const onKey = (e) => e.key === 'Escape' && setDrawer(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [drawer]);

  return (
    <div className="min-h-screen lg:flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[80] focus:rounded-lg focus:bg-white focus:px-3 focus:py-2 focus:shadow-lift">Skip to content</a>

      {drawer && <div className="fixed inset-0 z-40 bg-navy-950/60 lg:hidden" onClick={() => setDrawer(false)} aria-hidden="true" />}

      <aside
        id="sidebar"
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-navy-900 text-white transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:w-64 lg:shrink-0 lg:translate-x-0 ${
          drawer ? 'translate-x-0' : '-translate-x-full max-lg:invisible'
        }`}
        aria-label="Main navigation"
      >
        <div className="flex items-center justify-between px-5 py-5">
          <Logo to={`/${role}`} />
          <button onClick={() => setDrawer(false)} className="btn btn-icon text-white/70 hover:bg-white/10 lg:hidden" aria-label="Close menu"><X size={20} /></button>
        </div>
        <p className="px-5 pb-2 text-xs font-medium text-white/50">{ROLE_LABELS[role]} workspace</p>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-4">
          {items.map(({ to, label, icon: Icon, end, badge }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors ${
                  isActive ? 'bg-white/10 font-medium text-white' : 'text-white/65 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && <span className="absolute inset-y-2 left-0 w-1 rounded-r bg-brand-light" aria-hidden="true" />}
                  <Icon size={18} aria-hidden="true" />
                  <span className="flex-1">{label}</span>
                  {badge === 'messages' && unreadMessages > 0 && (
                    <span className="rounded-full bg-brand px-2 py-0.5 text-[11px] font-semibold" aria-label={`${unreadMessages} unread messages`}>{unreadMessages > 99 ? '99+' : unreadMessages}</span>
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-white/10 p-4">
          <div className="flex items-center gap-2 text-xs text-white/55">
            <span className={`h-2 w-2 rounded-full ${connected ? 'bg-emerald-400' : 'bg-amber-400'}`} aria-hidden="true" />
            {connected ? 'Live updates on' : 'Reconnecting…'}
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-slate-200/80 bg-white/85 px-4 backdrop-blur md:px-8">
          <button onClick={() => setDrawer(true)} className="btn btn-ghost btn-icon -ml-2 lg:hidden" aria-label="Open menu" aria-controls="sidebar" aria-expanded={drawer}><Menu size={20} /></button>
          <h2 className="min-w-0 flex-1 truncate text-base font-semibold">{titleFor(role, location.pathname)}</h2>
          {!connected && (
            <span className="hidden items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-800 sm:flex" role="status"><WifiOff size={13} /> Reconnecting</span>
          )}
          <NotificationBell />
          {user && <ProfileMenu />}
        </header>

        <main id="main" className="min-w-0 flex-1 px-4 py-6 md:px-8 md:py-8">
          <div className="mx-auto max-w-6xl">
            <ErrorBoundary key={location.pathname}>
              <Suspense fallback={<div className="flex justify-center py-24 text-brand"><Spinner size={26} /></div>}>
                <Outlet />
              </Suspense>
            </ErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  );
}
