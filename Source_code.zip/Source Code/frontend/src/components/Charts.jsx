import { useId } from 'react';
import { fmtShortDay } from '../utils/format';

export function AreaChart({ data, color = '#7C4DFF', height = 180, label = 'Chart', unit = '' }) {
  const rawId = useId();
  const id = `g${rawId.replace(/[^a-zA-Z0-9]/g, '')}`;
  const W = 600;
  const H = 160;
  const PAD = 8;
  const max = Math.max(1, ...data.map((d) => d.value));
  const total = data.reduce((s, d) => s + d.value, 0);
  const pts = data.map((d, i) => [data.length > 1 ? (i / (data.length - 1)) * W : W / 2, H - PAD - (d.value / max) * (H - PAD * 2)]);
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const mid = data[Math.floor(data.length / 2)];

  return (
    <figure>
      <div className="relative">
        <span className="absolute left-0 top-0 text-[11px] tabular-nums text-slate-400">{max}</span>
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label={`${label}: ${total} ${unit} in total`} className="w-full" style={{ height }}>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.28" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((f) => (
            <line key={f} x1="0" x2={W} y1={H * f} y2={H * f} stroke="#CBD5E1" strokeOpacity="0.5" strokeDasharray="4 4" vectorEffect="non-scaling-stroke" />
          ))}
          {data.length > 0 && <path d={`${line} L${W},${H} L0,${H} Z`} fill={`url(#${id})`} />}
          <path d={line} fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
        </svg>
      </div>
      {data.length > 0 && (
        <figcaption className="mt-1 flex justify-between text-xs text-ink-muted">
          <span>{fmtShortDay(data[0].date)}</span>
          {data.length > 2 && <span>{fmtShortDay(mid.date)}</span>}
          <span>{fmtShortDay(data[data.length - 1].date)}</span>
        </figcaption>
      )}
    </figure>
  );
}

export function DonutChart({ segments, centerLabel = 'Total' }) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  const R = 42;
  const C = 2 * Math.PI * R;
  let offset = 0;
  const summary = segments.map((s) => `${s.label} ${s.value}`).join(', ');

  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row">
      <div className="relative h-36 w-36 shrink-0">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90" role="img" aria-label={`${centerLabel}: ${summary}`}>
          <circle cx="50" cy="50" r={R} fill="none" stroke="#EEF0F6" strokeWidth="12" />
          {total > 0 && segments.map((s) => {
            const len = (s.value / total) * C;
            const el = (
              <circle key={s.label} cx="50" cy="50" r={R} fill="none" stroke={s.color} strokeWidth="12"
                strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} />
            );
            offset += len;
            return el;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-semibold tabular-nums">{total}</span>
          <span className="text-xs text-ink-muted">{centerLabel}</span>
        </div>
      </div>
      <ul className="w-full space-y-2 text-sm">
        {segments.map((s) => (
          <li key={s.label} className="flex items-center justify-between gap-3">
            <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.color }} aria-hidden="true" />{s.label}</span>
            <span className="font-medium tabular-nums">{s.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function BarList({ items, color = 'from-indigo-500 to-brand' }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <ul className="space-y-4">
      {items.map((item) => (
        <li key={item.label}>
          <div className="mb-1.5 flex justify-between gap-3 text-sm">
            <span className="truncate font-medium">{item.label}</span>
            <span className="shrink-0 text-ink-muted">{item.sub}</span>
          </div>
          <div className="h-2 rounded-full bg-slate-100" role="img" aria-label={`${item.label}: ${item.value}`}>
            <div className={`h-2 rounded-full bg-gradient-to-r ${color}`} style={{ width: `${Math.max((item.value / max) * 100, item.value ? 4 : 0)}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
