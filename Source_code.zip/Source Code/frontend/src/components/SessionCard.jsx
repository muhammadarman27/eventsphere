import { Bookmark, Clock, Lock, MapPin, Ticket } from 'lucide-react';
import Badge from './Badge';
import { fmtDate, fmtTime, sessionPhase } from '../utils/format';

export default function SessionCard({ session, bookmarked, booked, onBookmark, onBook, onCancel, busy = false, lockedReason = '' }) {
  const seatsLeft = session.capacity - (session.attendeeCount ?? 0);
  const full = seatsLeft <= 0 && !booked;
  const phase = sessionPhase(session);
  const ended = phase === 'ended';
  const hasActions = onBookmark || onBook;

  return (
    <div className={`card flex flex-col gap-4 p-4 sm:flex-row sm:items-center ${ended ? 'opacity-70' : ''}`}>
      <div className="shrink-0 sm:w-28">
        <p className="text-lg font-semibold tabular-nums">{fmtTime(session.startTime)}</p>
        <p className="text-xs text-ink-muted">{fmtDate(session.startTime)}</p>
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="font-semibold">{session.title}</h3>
          {phase !== 'upcoming' && <Badge status={phase} />}
          {booked && <Badge status="booked">Ticket booked</Badge>}
        </div>
        <p className="text-sm text-ink-muted">{session.speaker?.name}{session.speaker?.bio ? `, ${session.speaker.bio}` : ''}</p>
        <p className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-muted">
          <span className="flex items-center gap-1"><MapPin size={12} aria-hidden="true" /> {session.location}</span>
          <span className="flex items-center gap-1"><Clock size={12} aria-hidden="true" /> {fmtTime(session.startTime)} to {fmtTime(session.endTime)}</span>
          <span className="flex items-center gap-1"><Ticket size={12} aria-hidden="true" /> {full ? 'Full' : `${Math.max(seatsLeft, 0)} seats left`}</span>
          {session.expo?.title && <span>{session.expo.title}</span>}
        </p>
      </div>

      {hasActions && !ended && (
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {onBookmark && (
            <button onClick={onBookmark} disabled={busy} aria-pressed={bookmarked} aria-label={bookmarked ? `Remove bookmark from ${session.title}` : `Bookmark ${session.title}`}
              className={`btn btn-secondary btn-icon ${bookmarked ? 'border-brand text-brand' : ''}`}>
              <Bookmark size={16} className={bookmarked ? 'fill-current' : ''} />
            </button>
          )}
          {booked ? (
            <button onClick={onCancel} disabled={busy} className="btn btn-secondary">Cancel ticket</button>
          ) : lockedReason ? (
            <span className="flex items-center gap-1.5 text-xs text-ink-muted"><Lock size={13} /> {lockedReason}</span>
          ) : (
            <button onClick={onBook} disabled={full || busy} className="btn btn-primary">{full ? 'Full' : 'Book ticket'}</button>
          )}
        </div>
      )}
    </div>
  );
}
