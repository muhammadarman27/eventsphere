import { useEffect, useState } from 'react';
import { attendeeApi } from '../api/services';
import { errMsg, fieldErrors } from '../api/api';
import { useAuth } from '../context/AuthContext';
import useSubmit from '../hooks/useSubmit';
import { eventDays, PASS_TYPES } from '../utils/passes';
import { fmtShortDay } from '../utils/format';
import Modal from './Modal';
import { TextField } from './Fields';

const blank = (user) => ({ fullName: user?.name || '', email: user?.email || '', phone: '', company: '', jobTitle: '', marketingConsent: false });

export default function RegisterModal({ open, onClose, event, onDone }) {
  const { user } = useAuth();
  const days = eventDays(event);
  const [day, setDay] = useState(days[0]);
  const [passType, setPassType] = useState(PASS_TYPES[0].id);
  const [form, setForm] = useState(() => blank(user));
  const [error, setError] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => { if (open) { setDay(eventDays(event)[0]); setPassType(PASS_TYPES[0].id); setForm(blank(user)); setError(''); setErrors({}); } }, [open]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const [submit, busy] = useSubmit(async () => {
    setError(''); setErrors({});
    try {
      await attendeeApi.register(event._id, { ...form, day, passType });
      onDone();
    } catch (err) {
      setError(errMsg(err));
      setErrors(fieldErrors(err));
    }
  });

  return (
    <Modal open={open} onClose={onClose} busy={busy} size="lg" title="Register for this event"
      description={`${event.title}: free registration. The organizer confirms each request, then your QR ticket is issued.`}
      footer={<><button className="btn btn-secondary" onClick={onClose} disabled={busy}>Cancel</button><button className="btn btn-primary" onClick={submit} disabled={busy}>{busy ? 'Sending…' : 'Send registration'}</button></>}>
      <div className="space-y-5">
        <fieldset>
          <legend className="label">Choose your day</legend>
          <div className="flex flex-wrap gap-2">
            {days.map((d, i) => (
              <button key={d} type="button" onClick={() => setDay(d)} aria-pressed={day === d}
                className={`rounded-lg border px-3 py-2 text-left text-sm transition-colors ${day === d ? 'border-brand bg-brand-soft text-brand-dark' : 'border-slate-200 hover:border-slate-300'}`}>
                <span className="block font-medium">Day {i + 1}</span><span className="text-xs text-ink-muted">{fmtShortDay(d)}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="label">Pass type</legend>
          <div className="space-y-2">
            {PASS_TYPES.map((p) => (
              <label key={p.id} className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 text-sm ${passType === p.id ? 'border-brand bg-brand-soft' : 'border-slate-200'}`}>
                <input type="radio" name="passType" className="mt-1" checked={passType === p.id} onChange={() => setPassType(p.id)} />
                <span className="flex-1"><strong className="block">{p.name}</strong><span className="text-xs text-ink-muted">{p.description}</span></span>
                <span className="text-xs font-semibold text-emerald-700">Free</span>
              </label>
            ))}
          </div>
        </fieldset>

        <div className="grid gap-3 sm:grid-cols-2">
          <TextField label="Full name" required maxLength={120} value={form.fullName} onChange={set('fullName')} error={errors.fullName} />
          <TextField label="Email" type="email" required maxLength={254} value={form.email} onChange={set('email')} error={errors.email} hint="Your ticket link is sent here when email is set up." />
          <TextField label="Cell / WhatsApp" type="tel" required maxLength={30} placeholder="+92 3xx xxxxxxx" value={form.phone} onChange={set('phone')} error={errors.phone} />
          <TextField label="Company" required maxLength={160} value={form.company} onChange={set('company')} error={errors.company} />
          <div className="sm:col-span-2"><TextField label="Job title" required maxLength={160} value={form.jobTitle} onChange={set('jobTitle')} error={errors.jobTitle} /></div>
        </div>

        <label className="flex items-start gap-2 text-sm text-ink-muted">
          <input type="checkbox" className="mt-1" checked={form.marketingConsent} onChange={set('marketingConsent')} />
          <span>I would like optional emails about future events. I can withdraw this later from My agenda.</span>
        </label>
        {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm font-medium text-rose-700">{error}</p>}
      </div>
    </Modal>
  );
}
