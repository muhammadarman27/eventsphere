import { useEffect, useState } from 'react';
import { Cpu, Factory, GraduationCap, HeartPulse, Landmark, Shirt, Sparkles, UtensilsCrossed } from 'lucide-react';

export const CATEGORY_ICONS = {
  Technology: Cpu, Healthcare: HeartPulse, Education: GraduationCap, 'Food & Beverage': UtensilsCrossed,
  Manufacturing: Factory, Fashion: Shirt, Finance: Landmark, General: Sparkles,
};
const PALETTES = [
  ['#1E1B4B', '#7C4DFF'], ['#312E81', '#A855F7'], ['#0F172A', '#4F46E5'],
  ['#3730A3', '#C026D3'], ['#1D4ED8', '#7C3AED'], ['#111A33', '#6D5BFF'],
];
const hash = (s = '') => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);

export default function EventBanner({ event, className = '', rounded = true }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [event.banner]);

  const shape = rounded ? 'rounded-t-xl' : '';
  if (event.banner && !failed) {
    return (
      <img
        src={event.banner}
        alt={`${event.title} banner`}
        loading="lazy"
        decoding="async"
        onError={() => setFailed(true)}
        className={`w-full object-cover ${shape} ${className}`}
      />
    );
  }

  const [from, to] = PALETTES[hash(event.title) % PALETTES.length];
  const Icon = CATEGORY_ICONS[event.category] || Sparkles;
  return (
    <div
      role="img"
      aria-label={`${event.title} banner`}
      className={`relative w-full overflow-hidden ${shape} ${className}`}
      style={{ background: `linear-gradient(135deg, ${from}, ${to})` }}
    >
      <div
        className="absolute inset-0 opacity-25"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,.35) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.35) 1px, transparent 1px)',
          backgroundSize: '28px 28px',
        }}
        aria-hidden="true"
      />
      <Icon className="absolute -bottom-4 -right-3 text-white/20" size={120} strokeWidth={1.25} aria-hidden="true" />
    </div>
  );
}
