import { useId } from 'react';

function Wrapper({ id, label, error, hint, required, children }) {
  return (
    <div>
      {label && (
        <label htmlFor={id} className="label">
          {label}
          {required && <span className="ml-0.5 text-rose-500" aria-hidden="true">*</span>}
        </label>
      )}
      {children}
      {hint && !error && <p id={`${id}-hint`} className="mt-1 text-xs text-ink-muted">{hint}</p>}
      {error && <p id={`${id}-err`} role="alert" className="mt-1 text-xs font-medium text-rose-600">{error}</p>}
    </div>
  );
}

const aria = (id, error, hint) => ({
  'aria-invalid': error ? true : undefined,
  'aria-describedby': error ? `${id}-err` : hint ? `${id}-hint` : undefined,
});

export function TextField({ label, error, hint, required, className = '', ...props }) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} error={error} hint={hint} required={required}>
      <input id={id} required={required} className={`input ${error ? 'input-error' : ''} ${className}`} {...aria(id, error, hint)} {...props} />
    </Wrapper>
  );
}

export function SelectField({ label, error, hint, required, children, className = '', ...props }) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} error={error} hint={hint} required={required}>
      <select id={id} required={required} className={`input ${error ? 'input-error' : ''} ${className}`} {...aria(id, error, hint)} {...props}>
        {children}
      </select>
    </Wrapper>
  );
}

export function TextAreaField({ label, error, hint, required, maxLength, value, className = '', ...props }) {
  const id = useId();
  return (
    <Wrapper id={id} label={label} error={error} hint={hint} required={required}>
      <textarea id={id} required={required} maxLength={maxLength} value={value} className={`input ${error ? 'input-error' : ''} ${className}`} {...aria(id, error, hint)} {...props} />
      {maxLength && <p className="mt-1 text-right text-xs text-slate-400">{(value || '').length}/{maxLength}</p>}
    </Wrapper>
  );
}
