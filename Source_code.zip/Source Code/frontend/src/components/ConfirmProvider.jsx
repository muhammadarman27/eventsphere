import { createContext, useCallback, useContext, useRef, useState } from 'react';
import Modal from './Modal';

const ConfirmContext = createContext(() => Promise.resolve(false));

export const useConfirm = () => useContext(ConfirmContext);

export function ConfirmProvider({ children }) {
  const [state, setState] = useState(null);
  const resolver = useRef(null);

  const confirm = useCallback(
    (options) => new Promise((resolve) => {
      resolver.current = resolve;
      setState(options);
    }),
    []
  );

  const close = (result) => {
    resolver.current?.(result);
    resolver.current = null;
    setState(null);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      <Modal
        open={!!state}
        onClose={() => close(false)}
        title={state?.title || 'Are you sure?'}
        size="sm"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => close(false)}>{state?.cancelLabel || 'Cancel'}</button>
            <button data-autofocus className={`btn ${state?.tone === 'danger' ? 'btn-danger' : 'btn-primary'}`} onClick={() => close(true)}>
              {state?.confirmLabel || 'Confirm'}
            </button>
          </>
        }
      >
        <p className="text-sm text-ink-muted">{state?.message}</p>
      </Modal>
    </ConfirmContext.Provider>
  );
}
