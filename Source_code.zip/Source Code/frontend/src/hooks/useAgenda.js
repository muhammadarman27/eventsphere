import { useCallback, useEffect, useMemo, useState } from 'react';
import { attendeeApi } from '../api/services';
import { useAuth } from '../context/AuthContext';

const EMPTY = { bookmarked: [], booked: [], registeredExpos: [], registrations: [] };

export default function useAgenda() {
  const { user } = useAuth();
  const enabled = user?.role === 'attendee';
  const [agenda, setAgenda] = useState(EMPTY);
  const [loading, setLoading] = useState(enabled);

  const reload = useCallback(async () => {
    if (!enabled) return;
    try {
      setAgenda(await attendeeApi.agenda());
    } catch {
    } finally {
      setLoading(false);
    }
  }, [enabled]);

  useEffect(() => { reload(); }, [reload]);

  return useMemo(
    () => ({
      agenda,
      loading,
      reload,
      bookmarkedIds: new Set(agenda.bookmarked.map((s) => s._id)),
      bookedIds: new Set(agenda.booked.map((s) => s._id)),
      registeredIds: new Set(agenda.registeredExpos),
    }),
    [agenda, loading, reload]
  );
}
