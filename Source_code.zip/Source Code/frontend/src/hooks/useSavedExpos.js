import { useCallback, useEffect, useState } from 'react';

const KEY = 'eventsphere.saved-expos.v1';

const read = () => {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === 'string'))] : [];
  } catch { return []; }
};

export default function useSavedExpos() {
  const [ids, setIds] = useState(read);

  useEffect(() => {
    const sync = () => setIds(read());
    window.addEventListener('storage', sync);
    window.addEventListener('saved-expos', sync);
    return () => { window.removeEventListener('storage', sync); window.removeEventListener('saved-expos', sync); };
  }, []);

  const toggle = useCallback((id) => {
    const current = read();
    const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
      window.dispatchEvent(new Event('saved-expos'));
      setIds(next);
      return next.includes(id);
    } catch { return null; }
  }, []);

  return { ids, has: (id) => ids.includes(id), toggle };
}
