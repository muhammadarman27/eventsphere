import { useCallback, useEffect, useRef, useState } from 'react';
import { errMsg } from '../api/api';

export default function useFetch(fetcher, deps = [], { enabled = true } = {}) {
  const [state, setState] = useState({ data: null, loading: enabled, error: '' });
  const latest = useRef(0);

  const run = useCallback(async (silent = false) => {
    const id = ++latest.current;
    if (!silent) setState((s) => ({ ...s, loading: true, error: '' }));
    try {
      const data = await fetcher();
      if (id === latest.current) setState({ data, loading: false, error: '' });
    } catch (e) {
      if (id === latest.current) setState((s) => ({ ...s, loading: false, error: errMsg(e) }));
    }
  }, deps);

  useEffect(() => {
    if (enabled) run();
    else setState((s) => ({ ...s, loading: false }));
    return () => { latest.current += 1; };
  }, [run, enabled]);

  const setData = useCallback((updater) => setState((s) => ({ ...s, data: typeof updater === 'function' ? updater(s.data) : updater })), []);

  const loading = state.loading || (enabled && state.data === null && !state.error);
  return { ...state, loading, reload: () => run(false), refresh: () => run(true), setData };
}
