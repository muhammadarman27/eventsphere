import { useEffect, useRef } from 'react';

export default function useSocketRefresh(socket, events, refresh) {
  const latest = useRef(refresh);
  latest.current = refresh;
  const key = events.join(',');

  useEffect(() => {
    if (!socket) return undefined;
    const handler = () => latest.current();
    events.forEach((name) => socket.on(name, handler));
    return () => events.forEach((name) => socket.off(name, handler));
  }, [socket, key]);
}
