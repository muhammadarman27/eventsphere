import { useCallback, useRef, useState } from 'react';

export default function useSubmit(handler) {
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const ref = useRef(handler);
  ref.current = handler;

  const submit = useCallback(async (...args) => {
    if (lock.current) return undefined;
    lock.current = true;
    setBusy(true);
    try {
      return await ref.current(...args);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }, []);

  return [submit, busy];
}
