import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { io } from 'socket.io-client';
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import { useAuth } from './AuthContext';
import { API_URL } from '../api/api';
import { messageApi, notificationApi } from '../api/services';

const SocketContext = createContext({
  socket: null, connected: false, toast: () => {}, notifications: [], unreadCount: 0,
  unreadMessages: 0, markRead: () => {}, markAllRead: () => {}, refreshUnreadMessages: () => {},
});
export const useSocket = () => useContext(SocketContext);

const TONES = {
  success: { icon: CheckCircle2, bar: 'bg-emerald-500', text: 'text-emerald-600' },
  error: { icon: AlertTriangle, bar: 'bg-rose-500', text: 'text-rose-600' },
  info: { icon: Info, bar: 'bg-brand', text: 'text-brand' },
};

export function SocketProvider({ children }) {
  const { token, user } = useAuth();
  const location = useLocation();
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const pathRef = useRef(location.pathname);
  pathRef.current = location.pathname;
  const timers = useRef(new Map());

  const dismiss = useCallback((id) => {
    clearTimeout(timers.current.get(id));
    timers.current.delete(id);
    setToasts((list) => list.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback((message, title = 'Notice', tone = 'info') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((list) => {
      if (list.some((t) => t.message === message && t.title === title)) return list;
      return [...list.slice(-3), { id, title, message, tone }];
    });
    timers.current.set(id, setTimeout(() => dismiss(id), 5000));
  }, [dismiss]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const loadNotifications = useCallback(async () => {
    try {
      const res = await notificationApi.list({ limit: 15 });
      setNotifications(res.data);
      setUnreadCount(res.unreadCount);
    } catch { }
  }, []);

  const refreshUnreadMessages = useCallback(async () => {
    try {
      setUnreadMessages((await messageApi.unreadCount()).count);
    } catch { }
  }, []);

  const markRead = useCallback(async (id) => {
    setNotifications((list) => list.map((n) => (n._id === id ? { ...n, read: true } : n)));
    setUnreadCount((c) => Math.max(c - 1, 0));
    try { await notificationApi.markRead(id); } catch { loadNotifications(); }
  }, [loadNotifications]);

  const markAllRead = useCallback(async () => {
    setNotifications((list) => list.map((n) => ({ ...n, read: true })));
    setUnreadCount(0);
    try { await notificationApi.markAllRead(); } catch { loadNotifications(); }
  }, [loadNotifications]);

  useEffect(() => {
    if (!token || !user) {
      setSocket(null);
      setConnected(false);
      setNotifications([]);
      setUnreadCount(0);
      setUnreadMessages(0);
      return undefined;
    }
    const s = io(API_URL, { auth: { token }, reconnectionDelayMax: 10000 });

    const sync = () => { loadNotifications(); refreshUnreadMessages(); };
    s.on('connect', () => { setConnected(true); sync(); });
    s.on('disconnect', () => setConnected(false));
    s.on('connect_error', () => setConnected(false));

    s.on('notification', (n) => {
      setNotifications((list) => (list.some((x) => x._id === n._id) ? list : [n, ...list].slice(0, 30)));
      setUnreadCount((c) => c + 1);
      toast(n.message, n.title);
    });
    s.on('message', (m) => {
      setUnreadMessages((c) => c + 1);
      if (!pathRef.current.endsWith('/messages')) toast(`${m.senderName}: ${m.content.slice(0, 60)}`, 'New message');
    });

    setSocket(s);
    return () => { s.removeAllListeners(); s.disconnect(); };
  }, [token, user?.id, toast, loadNotifications, refreshUnreadMessages]);

  const value = useMemo(
    () => ({ socket, connected, toast, notifications, unreadCount, unreadMessages, markRead, markAllRead, refreshUnreadMessages, reloadNotifications: loadNotifications }),
    [socket, connected, toast, notifications, unreadCount, unreadMessages, markRead, markAllRead, refreshUnreadMessages, loadNotifications]
  );

  return (
    <SocketContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-3 bottom-3 z-[70] flex flex-col items-end gap-2 sm:inset-x-auto sm:right-4 sm:bottom-4 sm:w-96" aria-live="polite">
        {toasts.map((t) => {
          const tone = TONES[t.tone] || TONES.info;
          const Icon = tone.icon;
          return (
            <div key={t.id} role={t.tone === 'error' ? 'alert' : 'status'} className="pointer-events-auto flex w-full animate-pop overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lift">
              <span className={`w-1 shrink-0 ${tone.bar}`} />
              <Icon size={18} className={`mt-3.5 ml-3 shrink-0 ${tone.text}`} aria-hidden="true" />
              <div className="min-w-0 flex-1 px-3 py-3">
                <p className="text-sm font-semibold">{t.title}</p>
                <p className="break-words text-sm text-ink-muted">{t.message}</p>
              </div>
              <button onClick={() => dismiss(t.id)} aria-label="Dismiss notification" className="self-start p-3 text-slate-400 hover:text-ink">
                <X size={16} />
              </button>
            </div>
          );
        })}
      </div>
    </SocketContext.Provider>
  );
}
