import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api/services';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem('token'));
  const [sessionExpired, setSessionExpired] = useState(false);

  const clearSession = useCallback(() => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  }, []);

  useEffect(() => {
    if (!localStorage.getItem('token')) {
      setLoading(false);
      return undefined;
    }
    let cancelled = false;
    authApi
      .me()
      .then((res) => !cancelled && setUser(res.user))
      .catch((err) => {
        if (!cancelled && err.response?.status === 401) clearSession();
      })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [clearSession]);

  useEffect(() => {
    const onExpired = () => {
      clearSession();
      setSessionExpired(true);
    };
    window.addEventListener('auth:expired', onExpired);
    return () => window.removeEventListener('auth:expired', onExpired);
  }, [clearSession]);

  const saveSession = useCallback((data) => {
    localStorage.setItem('token', data.token);
    setToken(data.token);
    setUser(data.user);
    setSessionExpired(false);
    return data.user;
  }, []);

  const login = useCallback(async (email, password) => saveSession(await authApi.login(email, password)), [saveSession]);
  const register = useCallback(async (form) => saveSession(await authApi.register(form)), [saveSession]);
  const logout = useCallback(() => { clearSession(); setSessionExpired(false); }, [clearSession]);
  const updateUser = useCallback((next) => setUser((u) => ({ ...u, ...next })), []);
  const replaceToken = useCallback((t) => { localStorage.setItem('token', t); setToken(t); }, []);

  const value = useMemo(
    () => ({ user, token, loading, sessionExpired, login, register, logout, updateUser, replaceToken }),
    [user, token, loading, sessionExpired, login, register, logout, updateUser, replaceToken]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
