export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: { 950: '#070B1A', 900: '#0B1124', 800: '#111A33', 700: '#1A2547', 600: '#26345F' },
        brand: { DEFAULT: '#7C4DFF', dark: '#5B2EE0', light: '#A78BFA', soft: '#EFEAFF' },
        canvas: '#F5F6FB',
        gold: { DEFAULT: '#D9B86C', light: '#EBD9A6', dark: '#A98B3F' },
        ivory: '#F7F3EA',
        ink: { DEFAULT: '#121830', muted: '#5B6483' },
      },
      fontFamily: {
        display: ['"Instrument Serif"', 'Georgia', 'serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(18,24,48,0.04), 0 4px 16px -6px rgba(18,24,48,0.08)',
        pass: '0 30px 60px -20px rgba(0,0,0,0.7), 0 0 0 1px rgba(217,184,108,0.25)',
        lift: '0 2px 4px rgba(18,24,48,0.05), 0 12px 28px -10px rgba(91,46,224,0.25)',
      },
      keyframes: {
        pop: { from: { opacity: 0, transform: 'translateY(6px) scale(.98)' }, to: { opacity: 1, transform: 'none' } },
        sheet: { from: { opacity: 0, transform: 'translateY(12px)' }, to: { opacity: 1, transform: 'none' } },
        drop: { from: { opacity: 0, transform: 'translateY(-40px) rotate(-6deg)' }, to: { opacity: 1, transform: 'translateY(0) rotate(2deg)' } },
        sheen: { from: { transform: 'translateX(-120%)' }, to: { transform: 'translateX(220%)' } },
        tile: { '0%,100%': { opacity: 0.35 }, '50%': { opacity: 1 } },
      },
      animation: { drop: 'drop .9s cubic-bezier(.2,.8,.2,1) both', sheen: 'sheen 3.2s ease-in-out 1.2s 2', pop: 'pop .16s ease-out', sheet: 'sheet .2s ease-out', tile: 'tile 4s ease-in-out infinite' },
    },
  },
  plugins: [],
};
