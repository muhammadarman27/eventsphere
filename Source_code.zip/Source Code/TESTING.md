# Verification

## Checked automatically (executed, passing)

| Check | Result |
|---|---|
| Backend unit tests: validators, NoSQL sanitizer, pagination, event-status logic, date series (`cd backend && npm test`) | 21 / 21 pass |
| Backend module-load smoke test: all 8 controllers export their handlers, all 8 routers build | 16 / 16 pass (run with third-party packages stubbed; run it again for real after `npm install`) |
| `node --check` on every backend file | no syntax errors |
| Frontend: every `.jsx`/`.js` file parsed with esbuild | 66 files, 0 syntax errors |
| Frontend: every relative import resolves and every named/default import has a matching export | 0 problems |
| Contract check: every API call in `frontend/src/api/services.js` matched to a backend route by method and path | 53 / 53 match |

## NOT executed (this was built in a sandbox with no network, MongoDB or browser)

* `npm install` for either side, and therefore `npm run build`, starting the server, and all tests that need `express`/`mongoose`.
* Any flow that needs the database or sockets (login, CRUD, booth reservation, booking, messaging, live notifications).
* Visual and responsive checks at 375 / 430 / 768 / 1366 / 1920 px, keyboard navigation, contrast, browser console errors.
* The lucide-react icon names were checked against the icons I know exist in the pinned version (0.395), but not against the installed package. If the build reports a missing icon, rename it.

Treat the project as **complete but not yet run end-to-end**. Work through the checklist below once; fix anything it finds.

## Manual checklist

Start MongoDB, then `cd backend && npm run seed && npm run dev` and `cd frontend && npm run dev`. Also run `cd backend && npm test` and `cd frontend && npm run build` first. Both must finish without errors.

**Public**
1. `/` shows hero, live stats, upcoming events, categories. With the API stopped, the page still renders (stats show "unavailable").
2. `/events`: search, category, status buttons, dates, sort, pagination, Clear filters. Reload keeps filters. Draft event "Fashion Forward" must NOT appear.
3. `/events/:id` while logged out: all tabs work; "Log in to register" returns you to the event after login.

**Auth and security**
4. Register as attendee; weak password is rejected inline. Registration only offers attendee and exhibitor roles.
5. Logout, refresh: still logged out. Log in, refresh: still logged in. Edit the token in localStorage → next request logs you out with the "session expired" notice.
6. Forgot password with `EXPOSE_RESET_TOKEN=true`: link appears, reset works, old password fails. With it `false`: no link shown.
7. Account page: change name/email/phone; change password (wrong current password rejected). A second browser logged in as the same user is signed out.
8. As attendee open `/admin` → redirected to `/attendee`.

**Organizer**
9. Dashboard numbers match the database; date presets and custom range change the charts; Refresh works.
10. Create event (draft) → not visible publicly → Publish → visible. Edit, Mark completed, Delete (confirm dialog).
11. Applications: approve with a booth, reject with note, revoke; exhibitor gets a notification and the booth map updates live.
12. Booths: assign, edit price, release. Sessions: create, edit (booked attendee gets a notification), room clash is rejected, delete.
13. Users: search, filter, delete an attendee.

**Exhibitor**
14. Apply to an event; apply again → "already applied". Reserve booth; try to reserve one already taken (use two browsers) → refused. Release, withdraw.
15. Edit company profile (invalid URL/email rejected). Overview shows visits after an attendee opens your card.

**Attendee**
16. Register (event with capacity 1 and two attendees → second gets "full"). Book a session without registering → refused. Book two overlapping sessions → refused. Cancel ticket, bookmark, agenda view. Cancel registration → tickets cancelled too.

**Messaging and live updates**
17. Two browsers: message from attendee to exhibitor → appears instantly, unread badge shows, opening the chat clears it. Stop the API, restart it: header shows "Reconnecting" then recovers.
18. Try opening another user's thread by editing the id in the API → returns only your own messages with that user.

**Responsive and accessibility**
19. At 375 px: no sideways scroll; sidebar opens as a drawer; tables become cards; modals fit the screen.
20. Tab through a form and a modal (focus stays inside, Esc closes). Enable "reduce motion" in the OS: animations stop.

## Registration, ticket and check-in flow (manual)

1. `npm run seed` in `backend`, start both servers.
2. Log in as `attendee@eventsphere.test`, open an event, click **Register**, choose a day and pass, submit. The status shows *Waiting for organizer approval*, and session tickets are locked.
3. Log in as `admin@eventsphere.test` → **Registrations** → the request is under *Pending*. Click **Confirm**.
4. Back as the attendee: **My agenda → QR ticket**. Print or save as PDF.
5. As the organizer: **Check-in**, type the 8-character number under the QR (or scan the QR). First scan succeeds, second says *already checked in*. A ticket for another day is refused.
6. Reject a different request and confirm the event's *registered* count drops by one.
7. **Help & feedback**: send a request as an attendee, answer it as the organizer, check the attendee gets a notification.
