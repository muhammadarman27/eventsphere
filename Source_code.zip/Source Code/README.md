# EventSphere

Developed by Muhammad Arman.

A full-stack expo and event management platform for three roles:

| Role | What they do |
|---|---|
| **Organizer** (admin) | Create and publish events, review exhibitor applications, manage booths and sessions, see live analytics, manage users |
| **Exhibitor** | Maintain a company profile, apply to events, reserve a preferred booth, track application status, see booth visits, message attendees |
| **Attendee** | Discover events, request a day pass (organizer approves), get a QR ticket, book session tickets, bookmark sessions, save events, export the agenda to a calendar, browse exhibitors, message exhibitors |

Anyone (no login) can browse the landing page and all published events.

**Stack:** React 18 + Vite + Tailwind CSS · Node.js + Express · MongoDB + Mongoose · Socket.IO · JWT auth

---

## Quick start

Requirements: **Node.js 18+** and a running **MongoDB** (local or Atlas).

```bash
# 1. Backend
cd backend
cp .env.example .env        # then edit .env (see "Environment" below)
npm install
npm run seed                # optional demo data, local development only
npm run dev                 # http://localhost:5000

# 2. Frontend (new terminal)
cd frontend
cp .env.example .env
npm install
npm run dev                 # http://localhost:3000
```

### Demo accounts (created by `npm run seed`, local development only)

| Role | Email | Password |
|---|---|---|
| Organizer | admin@eventsphere.test | admin1234 |
| Exhibitor (approved, booth A2) | exhibitor@eventsphere.test | exhibitor123 |
| Exhibitor (pending application) | exhibitor2@eventsphere.test | exhibitor123 |
| Exhibitor (rejected application) | exhibitor3@eventsphere.test | exhibitor123 |
| Attendee | attendee@eventsphere.test | attendee123 |

These passwords are public. **Never run the seed against a real database.** The script refuses to run when `NODE_ENV=production`, and refuses when the database already has users unless you pass `--force` (which deletes everything first).

---

## Environment

`backend/.env`

| Variable | Required | Purpose |
|---|---|---|
| `MONGO_URI` | yes | MongoDB connection string |
| `JWT_SECRET` | yes | Long random string. In production it must be 32+ characters and not the example value, or the server refuses to start |
| `JWT_EXPIRES_IN` | no | Token lifetime, default `7d` |
| `CLIENT_URL` | yes | Allowed browser origin(s), comma separated, no trailing slash |
| `EXPOSE_RESET_TOKEN` | dev only | `true` makes "forgot password" return the reset link so you can test without email. Ignored in production |
| `TRUST_PROXY` | behind a proxy | Number of reverse proxies in front of the API (needed for correct rate limiting) |
| `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` | for image upload | From Cloudinary Dashboard > Settings > API Keys. Keep the secret only in `backend/.env`. Without them, upload buttons show "not set up" and pasting image links still works |
| `RATE_LIMIT_DISABLED` | tests only | Set `true` in automated tests |

`frontend/.env`: `VITE_API_URL` (API address), `VITE_CONTACT_EMAIL` (public footer).

Generate a secret: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

---

## Passes, QR tickets and check-in

1. **Attendee** opens an event, clicks *Register*, picks a **day** and a **pass type**, and fills in contact details (optionally agreeing to marketing emails). The request is **pending** and uses one place in the event's capacity.
2. **Organizer** opens *Registrations* and **confirms** or **rejects** it. Confirming issues a secret ticket token, notifies the attendee (live and stored) and, if SMTP is configured, emails the ticket link. Rejecting gives the place back.
3. **Attendee** opens *My agenda* (or the event page) and clicks **QR ticket**. The page at `/tickets/:id` can be printed or saved as PDF.
4. At the gate the **organizer** opens *Check-in*, scans the QR with a phone camera (it opens `/admin/check-in?token=...`) or types the 8-character ticket number. A ticket works once, only on its chosen day (time zone `EVENT_TIMEZONE`, default `Asia/Karachi`).
5. Session tickets can only be booked once the registration is **confirmed**. Old registrations without a status count as confirmed.

Other additions: **Help & feedback** page for every role (organizers answer requests, users are notified), **Saved events** (heart on each event card, stored in the browser), **Add to calendar (.ics)** on My agenda, **Get directions** link on events and tickets, and **withdraw marketing consent**.

Optional ticket emails: set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` in `backend/.env`. Run `npm install` in `backend` and `frontend` again, because `nodemailer` and `qrcode` were added.

## Upgrading an existing v1 database

Registrations moved from an array on the user to their own collection (so they have timestamps, capacity checks and cancellation). Run once, safely and repeatably:

```bash
cd backend && npm run migrate
```

It copies old registrations over and corrects event counters. It never deletes data.

---

## Commands

| Where | Command | What |
|---|---|---|
| backend | `npm run dev` | API with auto-restart |
| backend | `npm start` | API (production) |
| backend | `npm test` | Unit tests (validators, sanitizer, pagination, event status, date series, passes and ticket codes) and module-load smoke test |
| backend | `npm run seed` / `npm run migrate` | See above |
| frontend | `npm run dev` | Dev server |
| frontend | `npm run build` | Production build to `frontend/dist` |

---

## Project structure

```
backend/
  server.js            app setup: helmet, CORS, rate limits, sanitizer, sockets, routes, error handler
  config/db.js         connection with retry (API stays up and answers 503 while the DB is down)
  controllers/         auth, expo, admin, exhibitor, attendee, registration (approval, tickets, check-in), feedback, message, notification, public
  middleware/          auth (protect / optionalAuth / authorize), validateId, sanitize, rateLimit, errorHandler
  models/              User, Expo, Exhibitor, Booth, Session, Message, Registration, Notification, Visit
  utils/               validators, pagination, expo status logic, series, notify, reminders, mailer
  test/                node:test unit tests
  seed.js  scripts/migrate.js
frontend/src/
  api/                 api.js (axios, 401 handling) and services.js (every request, grouped)
  context/             AuthContext, SocketContext (live updates, notifications, toasts)
  hooks/               useFetch, useSubmit, useDebounce, useAgenda, useSocketRefresh, useDismiss
  components/          shared UI: layouts, Modal, ConfirmProvider, Fields, Pagination, Charts, EventCard, BoothGrid, Messaging...
  pages/               Landing, auth pages, Account, admin/, exhibitor/, attendee/
```

Routes are real URLs (`/admin/events`, `/attendee/agenda`, ...), so refresh, back and shareable links work. Filters live in the query string.

---

## How the main rules work

* **Event status**: `draft` is hidden from everyone except organizers. Otherwise status is derived from the dates (upcoming → live → ended), so it never goes stale. Organizers can also mark an event completed.
* **Booths**: `available → reserved` (exhibitor picks a preferred booth) `→ booked` (organizer approves). Every claim is an atomic database update, so two people can never take the same booth. Releasing or rejecting keeps booth and application status consistent.
* **Registration**: unique per attendee and event; capacity is claimed atomically; cancelling also cancels that attendee's session tickets for the event.
* **Session tickets**: need an event registration, cannot be booked after the session ended, cannot overlap another ticket, and seats are claimed atomically. Organizers cannot lower seats below the booked count or double-book a room.
* **Notifications** are stored (90-day retention) and pushed live over Socket.IO. They are never lost if you were offline; the bell syncs on reconnect.
* **Booth visits** count once per attendee, per exhibitor, per day.

---

## Security measures

* Passwords: bcrypt (cost 12), minimum 8 characters with a letter and a number. Tokens issued before a password change stop working.
* Password reset: hashed single-use token, 15-minute expiry, identical response whether or not the email exists, token never returned in production.
* Every protected route enforces role and ownership on the **server**; the client never decides roles.
* `helmet` headers, CORS allow-list, 100 KB body limit, rate limits (login failures, registration/reset, whole API).
* Input validation on all writes; NoSQL operator keys (`$…`) stripped from input; regex search input escaped; malformed ids return 400.
* Errors are sanitized: no stack traces or internal messages reach clients.
* Conversations are only ever readable by the two participants.

### Before deploying to production

1. Set a strong `JWT_SECRET`, `NODE_ENV=production`, the real `CLIENT_URL`, and `TRUST_PROXY` if behind a proxy.
2. Serve over HTTPS.
3. Connect an email provider in `backend/utils/mailer.js` (it currently sends nothing, so password-reset emails will not be delivered until you do).
4. Do **not** run `npm run seed`.
5. Back up MongoDB, and restrict database network access.

---

## Known limitations

* **No email delivery yet** (see above). Use `EXPOSE_RESET_TOKEN=true` locally to test the reset flow.
* **Image upload** (event banners, exhibitor logos) uses Cloudinary signed uploads straight from the browser: JPG, PNG or WebP up to 5 MB. Product images still take a link. Broken or empty links fall back to a generated banner or an initial.
* Floor-plan size is fixed after an event is created.
* Real-time updates use a single server instance. Running several instances needs the Socket.IO Redis adapter.
* Event dates are calendar dates plus daily opening hours; session times are exact moments shown in the viewer's time zone.
* The UI is English only and has no dark mode.

---

## Verification status

See [TESTING.md](TESTING.md) for exactly what has been checked automatically and the manual checklist for everything that needs a running database and browser.
