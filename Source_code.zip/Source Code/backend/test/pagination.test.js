const test = require('node:test');
const assert = require('node:assert/strict');
const { parsePagination, paginationMeta } = require('../utils/pagination');

test('defaults and clamping', () => {
  assert.deepEqual(parsePagination({}), { page: 1, limit: 10, skip: 0 });
  assert.deepEqual(parsePagination({ page: '3', limit: '20' }), { page: 3, limit: 20, skip: 40 });
  assert.equal(parsePagination({ limit: '9999' }, { maxLimit: 50 }).limit, 50);
  assert.equal(parsePagination({ page: '-4', limit: '0' }).page, 1);
  assert.equal(parsePagination({ page: 'abc', limit: { $gt: 1 } }).limit, 10);
});

test('paginationMeta always reports at least one page', () => {
  assert.deepEqual(paginationMeta(0, 1, 10), { page: 1, limit: 10, total: 0, pages: 1 });
  assert.equal(paginationMeta(21, 1, 10).pages, 3);
});
