const test = require('node:test');
const assert = require('node:assert/strict');
const {
  isObjectId, isEmail, isHttpUrl, parseDate, passwordError, safeEqual, escapeRegex, asString, createValidator,
} = require('../utils/validators');
const ApiError = require('../utils/ApiError');

test('isObjectId accepts only 24 hex characters', () => {
  assert.equal(isObjectId('507f1f77bcf86cd799439011'), true);
  assert.equal(isObjectId('507f1f77bcf86cd79943901'), false);
  assert.equal(isObjectId('zzzf1f77bcf86cd799439011'), false);
  assert.equal(isObjectId({ $ne: null }), false);
  assert.equal(isObjectId(undefined), false);
});

test('isEmail / isHttpUrl', () => {
  assert.equal(isEmail('a@b.co'), true);
  assert.equal(isEmail('a@b'), false);
  assert.equal(isEmail('a b@c.com'), false);
  assert.equal(isHttpUrl('https://example.com/x.png'), true);
  assert.equal(isHttpUrl('javascript:alert(1)'), false);
  assert.equal(isHttpUrl('ftp://example.com'), false);
  assert.equal(isHttpUrl('not a url'), false);
});

test('parseDate rejects numbers, garbage and absurd years', () => {
  assert.ok(parseDate('2026-05-01'));
  assert.ok(parseDate('2026-05-01T10:00:00.000Z'));
  assert.equal(parseDate(1700000000000), null);
  assert.equal(parseDate('nope'), null);
  assert.equal(parseDate(''), null);
  assert.equal(parseDate('1850-01-01'), null);
  assert.equal(parseDate({ $gt: '' }), null);
});

test('passwordError enforces length, a letter and a number', () => {
  assert.match(passwordError('short1'), /at least 8/);
  assert.match(passwordError('onlyletters'), /letter and one number/);
  assert.match(passwordError('12345678'), /letter and one number/);
  assert.equal(passwordError('goodpass1'), null);
  assert.match(passwordError(undefined), /at least 8/);
  assert.match(passwordError('a1'.repeat(70)), /128/);
});

test('safeEqual compares secrets', () => {
  assert.equal(safeEqual('secret', 'secret'), true);
  assert.equal(safeEqual('secret', 'Secret'), false);
  assert.equal(safeEqual('', 'x'), false);
});

test('escapeRegex neutralises regex syntax; asString ignores non-strings', () => {
  assert.equal(new RegExp(escapeRegex('a.b(c)*')).test('a.b(c)*'), true);
  assert.equal(new RegExp(escapeRegex('a.b')).test('axb'), false);
  assert.equal(asString(['x']), '');
  assert.equal(asString('  hi '), 'hi');
});

test('validator: required strings, trimming and length limits', () => {
  const v = createValidator({ title: '  Hello  ', description: 'x'.repeat(11) })
    .string('title', { required: true, max: 20 })
    .string('description', { max: 10, label: 'Description' })
    .string('location', { required: true, label: 'Location' });
  assert.equal(v.value.title, 'Hello');
  assert.equal(v.errors.description, 'Description must be 10 characters or fewer');
  assert.equal(v.errors.location, 'Location is required');
  assert.equal(v.ok(), false);
  assert.throws(() => v.assert(), (e) => e instanceof ApiError && e.status === 400 && e.errors.location === "Location is required");
});

test('validator: partial mode only validates what was sent', () => {
  const ok = createValidator({ title: 'New title' }, { partial: true }).string('title', { required: true }).string('location', { required: true });
  assert.equal(ok.ok(), true);
  assert.deepEqual(ok.value, { title: 'New title' });

  const blank = createValidator({ title: '   ' }, { partial: true }).string('title', { required: true, label: 'Title' });
  assert.equal(blank.errors.title, 'Title is required');
});

test('validator: int, oneOf, date, time, url, boolean', () => {
  const v = createValidator({
    capacity: '25', rows: 'abc', category: 'Nope', startDate: '2026-06-01', openTime: '9:00', banner: 'javascript:x', published: 'false',
  })
    .int('capacity', { min: 0, max: 100 })
    .int('rows', { min: 1 })
    .int('seats', { fallback: 100 })
    .oneOf('category', ['General', 'Technology'], { label: 'Category' })
    .oneOf('level', ['a', 'b'], { fallback: 'a' })
    .date('startDate')
    .time('openTime', { label: 'Opening time' })
    .url('banner', { label: 'Banner' })
    .boolean('published');
  assert.equal(v.value.capacity, 25);
  assert.equal(v.value.seats, 100);
  assert.equal(v.value.level, 'a');
  assert.equal(v.value.published, false);
  assert.ok(v.value.startDate instanceof Date);
  assert.ok(v.errors.rows);
  assert.ok(v.errors.category);
  assert.ok(v.errors.openTime);
  assert.ok(v.errors.banner);
});

test('validator: email is lowercased; objects are rejected as text', () => {
  const v = createValidator({ email: ' Ada@Example.COM ', name: { $ne: 1 } }).email('email', { required: true }).string('name', { required: true });
  assert.equal(v.value.email, 'ada@example.com');
  assert.ok(v.errors.name);
});
