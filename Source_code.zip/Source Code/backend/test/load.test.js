const test = require('node:test');
const assert = require('node:assert/strict');

const controllers = {
  authController: ['register', 'login', 'getMe', 'updateProfile', 'changePassword', 'forgotPassword', 'resetPassword'],
  expoController: ['getExpos', 'getExpo', 'getBooths', 'getSessions', 'getExhibitors', 'createExpo', 'updateExpo', 'deleteExpo', 'getRegistrations'],
  adminController: ['getApplications', 'reviewApplication', 'updateBooth', 'assignBooth', 'releaseBooth', 'createSession', 'updateSession', 'deleteSession', 'getUsers', 'deleteUser', 'getAnalytics'],
  exhibitorController: ['getMyProfile', 'updateMyProfile', 'applyToExpo', 'withdrawApplication', 'reserveBooth', 'releaseBooth', 'getOverview', 'getSchedule', 'recordVisit'],
  attendeeController: ['getAgenda', 'registerForExpo', 'unregisterFromExpo', 'toggleBookmark', 'bookTicket', 'cancelTicket', 'withdrawConsent'],
  registrationController: ['reviewRegistration', 'getTicket', 'checkIn', 'listRegistrations'],
  feedbackController: ['listFeedback', 'createFeedback', 'respondToFeedback'],
  messageController: ['getContacts', 'getConversations', 'getUnreadCount', 'getThread', 'markThreadRead', 'sendMessage'],
  notificationController: ['getNotifications', 'markAllRead', 'markRead'],
  publicController: ['getStats', 'getCategories'],
  uploadController: ['signUpload'],
};

for (const [file, names] of Object.entries(controllers)) {
  test(`controllers/${file} exports its handlers`, () => {
    const mod = require(`../controllers/${file}`);
    names.forEach((n) => assert.equal(typeof mod[n], 'function', `${file}.${n} should be a function`));
  });
}

for (const file of ['auth', 'expo', 'admin', 'exhibitor', 'attendee', 'message', 'notification', 'public', 'upload', 'ticket', 'feedback']) {
  test(`routes/${file}Routes builds a router`, () => {
    assert.equal(typeof require(`../routes/${file}Routes`), 'function');
  });
}
