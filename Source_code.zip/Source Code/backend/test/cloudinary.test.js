const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { signParams } = require('../utils/cloudinary');

test('signature = sha1 of sorted key=value pairs plus the secret', () => {
  const expected = crypto.createHash('sha1').update('folder=eventsphere/events&timestamp=1700000000SECRET').digest('hex');
  assert.equal(signParams({ timestamp: 1700000000, folder: 'eventsphere/events' }, 'SECRET'), expected);
});

test('a different secret or a different folder changes the signature', () => {
  const a = signParams({ folder: 'a', timestamp: 1 }, 's1');
  assert.notEqual(a, signParams({ folder: 'a', timestamp: 1 }, 's2'));
  assert.notEqual(a, signParams({ folder: 'b', timestamp: 1 }, 's1'));
  assert.match(a, /^[a-f0-9]{40}$/);
});
