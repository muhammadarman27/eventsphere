const test = require('node:test');
const assert = require('node:assert/strict');
const { eachDay, fillSeries } = require('../utils/series');

test('eachDay is inclusive and ordered', () => {
  assert.deepEqual(eachDay(new Date('2026-01-30T05:00:00Z'), new Date('2026-02-02T01:00:00Z')), [
    '2026-01-30', '2026-01-31', '2026-02-01', '2026-02-02',
  ]);
});

test('fillSeries puts zeros on empty days', () => {
  const out = fillSeries([{ _id: '2026-01-02', n: 3 }], new Date('2026-01-01T00:00:00Z'), new Date('2026-01-03T00:00:00Z'));
  assert.deepEqual(out, [
    { date: '2026-01-01', value: 0 }, { date: '2026-01-02', value: 3 }, { date: '2026-01-03', value: 0 },
  ]);
});

test('eachDay is capped so a huge range cannot blow up memory', () => {
  assert.ok(eachDay(new Date('2000-01-01'), new Date('2100-01-01')).length <= 400);
});
