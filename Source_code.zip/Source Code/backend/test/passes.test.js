const test = require('node:test');
const assert = require('node:assert/strict');
const { eventDays, passError, PASS_TYPES } = require('../utils/passes');
const { parseTicketCode } = require('../utils/ticketCode');

const expo = { startDate: new Date('2026-11-10T00:00:00Z'), endDate: new Date('2026-11-12T00:00:00Z') };

test('eventDays lists every day of the event', () => {
  assert.deepEqual(eventDays(expo), ['2026-11-10', '2026-11-11', '2026-11-12']);
});

test('a one-day event has one day', () => {
  assert.deepEqual(eventDays({ startDate: expo.startDate, endDate: expo.startDate }), ['2026-11-10']);
});

test('passError accepts valid choices and rejects others', () => {
  assert.equal(passError(expo, '2026-11-11', PASS_TYPES[0].id), '');
  assert.ok(passError(expo, '2026-11-13', PASS_TYPES[0].id));
  assert.ok(passError(expo, '2026-11-11', 'vip'));
});

test('parseTicketCode accepts short numbers, tokens and QR URLs', () => {
  const token = 'a'.repeat(64);
  assert.deepEqual(parseTicketCode('AB12CD34'), { code: 'ab12cd34', short: true });
  assert.deepEqual(parseTicketCode(token), { code: token, short: false });
  assert.deepEqual(parseTicketCode(`https://example.com/admin/check-in?token=${token}`), { code: token, short: false });
});

test('parseTicketCode rejects junk', () => {
  assert.throws(() => parseTicketCode('hello'));
  assert.throws(() => parseTicketCode(''));
  assert.throws(() => parseTicketCode(42));
  assert.throws(() => parseTicketCode('https://example.com/?token=zzz'));
});
