const test = require('node:test');
const assert = require('node:assert/strict');
const clean = require('../utils/sanitize');

test('strips operator keys and dotted keys, recursively', () => {
  const body = { email: { $ne: null }, name: 'ok', nested: { deep: { $gt: '' }, keep: 1 }, 'a.b': 1, list: [{ $where: 'x', fine: 2 }] };
  clean(body);
  assert.deepEqual(body, { email: {}, name: 'ok', nested: { deep: {}, keep: 1 }, list: [{ fine: 2 }] });
});

test('leaves primitives and null alone', () => {
  assert.equal(clean(null), null);
  assert.equal(clean('x'), 'x');
  assert.deepEqual(clean({ a: [1, 2] }), { a: [1, 2] });
});
