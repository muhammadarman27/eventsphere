const test = require('node:test');
const assert = require('node:assert/strict');
const { computeStatus, statusQuery, serializeExpo } = require('../utils/expoUtils');

const DAY = 86400000;
const now = new Date('2026-06-10T12:00:00Z');
const day = (offset) => new Date(Date.UTC(2026, 5, 10) + offset * DAY);

test('computeStatus follows the dates, except draft/completed which are explicit', () => {
  assert.equal(computeStatus({ status: 'upcoming', startDate: day(3), endDate: day(4) }, now), 'upcoming');
  assert.equal(computeStatus({ status: 'upcoming', startDate: day(-1), endDate: day(1) }, now), 'ongoing');
  assert.equal(computeStatus({ status: 'upcoming', startDate: day(-3), endDate: day(-2) }, now), 'completed');
  assert.equal(computeStatus({ status: 'draft', startDate: day(-3), endDate: day(-2) }, now), 'draft');
  assert.equal(computeStatus({ status: 'completed', startDate: day(3), endDate: day(4) }, now), 'completed');
});

test('an event is still live on its last day', () => {
  assert.equal(computeStatus({ status: 'upcoming', startDate: day(-2), endDate: day(0) }, now), 'ongoing');
});

test('statusQuery returns a filter per status and null for unknown', () => {
  assert.deepEqual(statusQuery('draft'), { status: 'draft' });
  assert.ok(statusQuery('upcoming').startDate.$gt);
  assert.ok(statusQuery('ongoing').endDate.$gte);
  assert.ok(statusQuery('past').$or);
  assert.equal(statusQuery('bogus'), null);
});

test('serializeExpo adds derived fields and hides the organizer from non-admins', () => {
  const raw = { _id: 'x', status: 'upcoming', startDate: day(3), endDate: day(4), capacity: 10, registeredCount: 4, organizer: 'o' };
  const pub = serializeExpo(raw);
  assert.equal(pub.spotsLeft, 6);
  assert.equal(pub.published, true);
  assert.equal(pub.organizer, undefined);
  assert.equal(serializeExpo(raw, {}, { isAdmin: true }).organizer, 'o');
  assert.equal(serializeExpo({ ...raw, capacity: 0 }).spotsLeft, null);
  assert.equal(serializeExpo({ ...raw, status: 'draft' }).published, false);
});
