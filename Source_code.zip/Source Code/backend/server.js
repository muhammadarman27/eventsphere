require('dotenv').config();

const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { Server } = require('socket.io');

const connectDB = require('./config/db');
const User = require('./models/User');
const ApiError = require('./utils/ApiError');
const startReminders = require('./utils/reminders');
const sanitize = require('./middleware/sanitize');
const { apiLimiter } = require('./middleware/rateLimit');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const isProd = process.env.NODE_ENV === 'production';

const secret = process.env.JWT_SECRET || '';
if (!secret) {
  console.error('JWT_SECRET is not set. Copy backend/.env.example to backend/.env and set a long random value.');
  process.exit(1);
}
if (isProd && (secret.length < 32 || /change_this/i.test(secret))) {
  console.error('JWT_SECRET is too weak for production. Use a random value of at least 32 characters.');
  process.exit(1);
}
if (!isProd && /change_this/i.test(secret)) {
  console.warn('Warning: JWT_SECRET is still the example value. Fine for local use, never for production.');
}

const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:3000')
  .split(',')
  .map((s) => s.trim().replace(/\/$/, ''))
  .filter(Boolean);
if (!isProd) allowedOrigins.push('http://127.0.0.1:3000');

connectDB();

const app = express();
const server = http.createServer(app);
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(
  cors({
    origin: (origin, cb) =>
      !origin || allowedOrigins.includes(origin) ? cb(null, true) : cb(new ApiError(403, 'Origin not allowed')),
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);
app.use(express.json({ limit: '100kb' }));
app.use(sanitize);

const io = new Server(server, { cors: { origin: allowedOrigins } });

io.use(async (socket, next) => {
  try {
    const decoded = jwt.verify(socket.handshake.auth.token, secret);
    const user = await User.findById(decoded.id).select('_id passwordChangedAt');
    if (!user) return next(new Error('Unauthorized'));
    if (user.passwordChangedAt && Math.floor(user.passwordChangedAt.getTime() / 1000) > decoded.iat) {
      return next(new Error('Unauthorized'));
    }
    socket.userId = String(user._id);
    next();
  } catch (error) {
    next(new Error('Unauthorized'));
  }
});
io.on('connection', (socket) => socket.join(`user:${socket.userId}`));

app.set('io', io);
startReminders(io);

app.get('/api/health', (req, res) =>
  res.json({
    status: mongoose.connection.readyState === 1 ? 'ok' : 'degraded',
    database: ['disconnected', 'connected', 'connecting', 'disconnecting'][mongoose.connection.readyState] || 'unknown',
  })
);

app.use('/api', apiLimiter);

app.use('/api', (req, res, next) => {
  if (mongoose.connection.readyState === 1) return next();
  res.status(503).json({ message: 'The service is temporarily unavailable. Please try again in a moment.' });
});

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/expos', require('./routes/expoRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api/exhibitors', require('./routes/exhibitorRoutes'));
app.use('/api/attendee', require('./routes/attendeeRoutes'));
app.use('/api/messages', require('./routes/messageRoutes'));
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/uploads', require('./routes/uploadRoutes'));
app.use('/api/tickets', require('./routes/ticketRoutes'));
app.use('/api/feedback', require('./routes/feedbackRoutes'));
app.use('/api/public', require('./routes/publicRoutes'));

app.get('/', (req, res) => res.json({ message: 'EventSphere API is running' }));

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));

const shutdown = (signal) => {
  console.log(`${signal} received, shutting down`);
  io.close();
  server.close(() => mongoose.connection.close(false).then(() => process.exit(0), () => process.exit(1)));
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = { app, server };
