const Notification = require('../models/Notification');

const notifyUsers = async (io, userIds, { title, message, link = '', type = 'info' }) => {
  try {
    const ids = [...new Set((userIds || []).map(String))];
    if (!ids.length) return;
    const docs = await Notification.insertMany(ids.map((user) => ({ user, title, message, link, type })));
    if (io) {
      docs.forEach((d) =>
        io.to(`user:${d.user}`).emit('notification', {
          _id: d._id,
          title: d.title,
          message: d.message,
          link: d.link,
          type: d.type,
          read: false,
          createdAt: d.createdAt,
        })
      );
    }
  } catch (err) {
    console.error('Notification error:', err.message);
  }
};

module.exports = { notifyUsers };
