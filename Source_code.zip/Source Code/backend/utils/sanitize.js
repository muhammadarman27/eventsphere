const clean = (obj, depth = 0) => {
  if (!obj || typeof obj !== 'object' || depth > 8) return obj;
  for (const key of Object.keys(obj)) {
    if (key.startsWith('$') || key.includes('.')) {
      delete obj[key];
      continue;
    }
    clean(obj[key], depth + 1);
  }
  return obj;
};

module.exports = clean;
