const { DAY } = require('./constants');

const dayKey = (d) => new Date(d).toISOString().slice(0, 10);

const eachDay = (from, to) => {
  const days = [];
  let t = Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate());
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  while (t <= end && days.length < 400) {
    days.push(dayKey(t));
    t += DAY;
  }
  return days;
};

const fillSeries = (rows, from, to) => {
  const byDay = new Map(rows.map((r) => [r._id, r.n]));
  return eachDay(from, to).map((date) => ({ date, value: byDay.get(date) || 0 }));
};

module.exports = { dayKey, eachDay, fillSeries };
