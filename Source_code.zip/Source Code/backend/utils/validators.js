const crypto = require('crypto');
const ApiError = require('./ApiError');

const OBJECT_ID = /^[a-f\d]{24}$/i;
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

const isObjectId = (v) => typeof v === 'string' && OBJECT_ID.test(v);
const isEmail = (v) => typeof v === 'string' && v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
const isHttpUrl = (v) => {
  if (typeof v !== 'string' || v.length > 2048) return false;
  try {
    const u = new URL(v);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
};

const asString = (v) => (typeof v === 'string' ? v.trim() : '');
const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const parseDate = (v) => {
  if (!(typeof v === 'string' || v instanceof Date) || v === '') return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return null;
  const year = d.getUTCFullYear();
  return year >= 2000 && year <= 2100 ? d : null;
};

const passwordError = (pw) => {
  if (typeof pw !== 'string' || pw.length < 8) return 'Password must be at least 8 characters';
  if (pw.length > 128) return 'Password must be 128 characters or fewer';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Password must include at least one letter and one number';
  return null;
};

const safeEqual = (a, b) => {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
};

const createValidator = (input = {}, { partial = false } = {}) => {
  const src = input && typeof input === 'object' ? input : {};
  const errors = {};
  const value = {};
  const present = (f) => src[f] !== undefined;
  const missing = (f, label, required) => {
    if (required && !partial) errors[f] = `${label} is required`;
  };

  const api = {
    errors,
    value,

    string(f, { label = f, required = false, min = 0, max = 255 } = {}) {
      if (!present(f)) { missing(f, label, required); return api; }
      const raw = src[f];
      if (raw !== null && typeof raw !== 'string') { errors[f] = `${label} must be text`; return api; }
      const s = (raw || '').trim();
      if (!s) {
        if (required) errors[f] = `${label} is required`;
        else value[f] = '';
        return api;
      }
      if (s.length < min) errors[f] = `${label} must be at least ${min} characters`;
      else if (s.length > max) errors[f] = `${label} must be ${max} characters or fewer`;
      else value[f] = s;
      return api;
    },

    email(f, { label = 'Email', required = false } = {}) {
      if (!present(f)) { missing(f, label, required); return api; }
      const s = typeof src[f] === 'string' ? src[f].trim().toLowerCase() : '';
      if (!s) { if (required) errors[f] = `${label} is required`; return api; }
      if (!isEmail(s)) errors[f] = `${label} must be a valid email address`;
      else value[f] = s;
      return api;
    },

    url(f, { label = f, required = false } = {}) {
      if (!present(f)) { missing(f, label, required); return api; }
      const s = typeof src[f] === 'string' ? src[f].trim() : '';
      if (!s) { if (required) errors[f] = `${label} is required`; else value[f] = ''; return api; }
      if (!isHttpUrl(s)) errors[f] = `${label} must be a valid http(s) link`;
      else value[f] = s;
      return api;
    },

    oneOf(f, options, { label = f, required = false, fallback } = {}) {
      if (!present(f)) {
        if (fallback !== undefined && !partial) value[f] = fallback;
        else missing(f, label, required);
        return api;
      }
      if (!options.includes(src[f])) errors[f] = `${label} must be one of: ${options.join(', ')}`;
      else value[f] = src[f];
      return api;
    },

    int(f, { label = f, min = -Infinity, max = Infinity, required = false, fallback } = {}) {
      if (!present(f) || src[f] === '' || src[f] === null) {
        if (fallback !== undefined && !partial) value[f] = fallback;
        else missing(f, label, required);
        return api;
      }
      const n = typeof src[f] === 'number' ? src[f] : typeof src[f] === 'string' && /^-?\d+$/.test(src[f].trim()) ? Number(src[f]) : NaN;
      if (!Number.isInteger(n)) errors[f] = `${label} must be a whole number`;
      else if (n < min || n > max) errors[f] = `${label} must be between ${min} and ${max}`;
      else value[f] = n;
      return api;
    },

    date(f, { label = f, required = false } = {}) {
      if (!present(f)) { missing(f, label, required); return api; }
      const d = parseDate(src[f]);
      if (!d) errors[f] = `${label} must be a valid date`;
      else value[f] = d;
      return api;
    },

    time(f, { label = f } = {}) {
      if (!present(f)) return api;
      if (typeof src[f] !== 'string' || !TIME.test(src[f])) errors[f] = `${label} must be a time like 09:30`;
      else value[f] = src[f];
      return api;
    },

    boolean(f) {
      if (!present(f)) return api;
      if (src[f] === true || src[f] === 'true') value[f] = true;
      else if (src[f] === false || src[f] === 'false') value[f] = false;
      else errors[f] = `${f} must be true or false`;
      return api;
    },

    fail(f, message) {
      errors[f] = message;
      return api;
    },

    ok: () => Object.keys(errors).length === 0,

    assert() {
      if (Object.keys(errors).length) {
        throw new ApiError(400, Object.values(errors)[0], errors);
      }
      return value;
    },
  };
  return api;
};

module.exports = {
  isObjectId,
  isEmail,
  isHttpUrl,
  asString,
  escapeRegex,
  parseDate,
  passwordError,
  safeEqual,
  createValidator,
};
