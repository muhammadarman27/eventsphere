const sendResetEmail = async (user, url) => {
  if (process.env.NODE_ENV !== 'production' && process.env.EXPOSE_RESET_TOKEN === 'true') {
    console.log(`[dev] Password reset link for ${user.email}: ${url}`);
    return;
  }
  console.warn('[mail] No mail provider is configured, so the password reset email was not sent.');
};

module.exports = { sendResetEmail };

const sendTicketEmail = async (registration, expo) => {
  if (!process.env.SMTP_HOST || !registration.email) return 'not-configured';
  try {
    const nodemailer = require('nodemailer');
    const transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_PORT === '465',
      connectionTimeout: 10000,
      socketTimeout: 15000,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    });
    const base = (process.env.CLIENT_URL || 'http://localhost:3000').split(',')[0].trim().replace(/\/$/, '');
    await transport.sendMail({
      from: process.env.MAIL_FROM || 'EventSphere <no-reply@example.com>',
      to: registration.email,
      subject: `Your confirmed pass: ${expo.title}`,
      text: `Hello ${registration.fullName},\nYour registration is confirmed for ${registration.day}.\nSign in and open your ticket (you can print it or save it as PDF):\n${base}/tickets/${registration._id}\nVenue: ${expo.venue || expo.location}\nThis is a registration confirmation, not marketing.`,
    });
    return 'sent';
  } catch (err) {
    console.error('[mail] Ticket email failed:', err.message);
    return 'failed';
  }
};

module.exports.sendTicketEmail = sendTicketEmail;
