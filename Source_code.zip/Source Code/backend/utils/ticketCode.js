const MESSAGE = 'Enter the 8-character ticket number or scan the full QR URL.';

const parseTicketCode = (input) => {
  if (typeof input !== 'string' || input.length > 4096) throw new Error(MESSAGE);
  let code = input.trim();
  if (/^https?:\/\//i.test(code)) {
    let url;
    try { url = new URL(code); } catch (e) { throw new Error('Invalid ticket URL.'); }
    code = url.searchParams.get('token') || '';
  }
  code = code.trim().toLowerCase();
  if (!/^(?:[a-f0-9]{8}|[a-f0-9]{64})$/.test(code)) throw new Error(MESSAGE);
  return { code, short: code.length === 8 };
};

module.exports = { parseTicketCode };
