const CATEGORIES = [
  'General',
  'Technology',
  'Healthcare',
  'Education',
  'Food & Beverage',
  'Manufacturing',
  'Fashion',
  'Finance',
];

const EXPO_STATUSES = ['draft', 'upcoming', 'ongoing', 'completed'];
const ROLES = ['admin', 'exhibitor', 'attendee'];
const DAY = 24 * 60 * 60 * 1000;

module.exports = { CATEGORIES, EXPO_STATUSES, ROLES, DAY };
