const PASS_TYPES = [
  { id: 'trade', name: 'Trade & Corporate Visitor', description: 'Business professionals, enterprise executives, software engineers and IT buyers.' },
  { id: 'conference', name: 'Conference & Workshop Delegate', description: 'Technical workshops, panel discussions and keynote conversations.' },
  { id: 'media', name: 'Media & Tech Influencer', description: 'Press, content creators, journalists and media delegations.' },
];

const EVENT_TZ = process.env.EVENT_TIMEZONE || 'Asia/Karachi';

const todayAtVenue = (now = new Date()) =>
  new Intl.DateTimeFormat('en-CA', { timeZone: EVENT_TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);

const eventDays = (expo) => {
  const start = new Date(expo.startDate).toISOString().slice(0, 10);
  const end = new Date(expo.endDate).toISOString().slice(0, 10);
  const days = [];
  for (let d = new Date(`${start}T12:00:00Z`); d.toISOString().slice(0, 10) <= end && days.length < 366; d.setUTCDate(d.getUTCDate() + 1)) {
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
};

const passError = (expo, day, passType) =>
  eventDays(expo).includes(day) && PASS_TYPES.some((p) => p.id === passType) ? '' : 'Choose a valid event day and pass.';

module.exports = { PASS_TYPES, EVENT_TZ, todayAtVenue, eventDays, passError };
