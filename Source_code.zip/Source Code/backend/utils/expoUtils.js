const { DAY } = require('./constants');

const computeStatus = (expo, now = new Date()) => {
  if (expo.status === 'draft') return 'draft';
  if (expo.status === 'completed') return 'completed';
  const start = new Date(expo.startDate).getTime();
  const end = new Date(expo.endDate).getTime() + DAY - 1;
  const t = now.getTime();
  if (t > end) return 'completed';
  if (t >= start) return 'ongoing';
  return 'upcoming';
};

const statusQuery = (status, now = new Date()) => {
  const endedBefore = new Date(now.getTime() - DAY + 1);
  switch (status) {
    case 'draft':
      return { status: 'draft' };
    case 'upcoming':
      return { status: { $nin: ['draft', 'completed'] }, startDate: { $gt: now } };
    case 'ongoing':
      return { status: { $nin: ['draft', 'completed'] }, startDate: { $lte: now }, endDate: { $gte: endedBefore } };
    case 'completed':
    case 'past':
      return { status: { $ne: 'draft' }, $or: [{ status: 'completed' }, { endDate: { $lt: endedBefore } }] };
    default:
      return null;
  }
};

const serializeExpo = (doc, extra = {}, { isAdmin = false } = {}) => {
  const o = typeof doc.toObject === 'function' ? doc.toObject() : { ...doc };
  const capacity = o.capacity || 0;
  const out = {
    ...o,
    status: computeStatus(o),
    published: o.status !== 'draft',
    capacity,
    registeredCount: o.registeredCount || 0,
    spotsLeft: capacity > 0 ? Math.max(capacity - (o.registeredCount || 0), 0) : null,
    ...extra,
  };
  delete out.__v;
  if (!isAdmin) delete out.organizer;
  return out;
};

module.exports = { computeStatus, statusQuery, serializeExpo };
