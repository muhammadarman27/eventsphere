const Session = require('../models/Session');
const User = require('../models/User');
const { notifyUsers } = require('./notify');

const startReminders = (io) => {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try {
      const now = new Date();
      const soon = new Date(now.getTime() + 15 * 60 * 1000);
      const sessions = await Session.find({ startTime: { $gt: now, $lte: soon }, reminderSent: false });

      for (const s of sessions) {
        const bookmarkers = await User.find({ bookmarkedSessions: s._id }).select('_id');
        const ids = new Set([...s.attendees.map(String), ...bookmarkers.map((u) => String(u._id))]);
        await notifyUsers(io, [...ids], {
          title: 'Starting soon',
          message: `"${s.title}" starts in less than 15 minutes at ${s.location}.`,
          link: '/attendee/agenda',
          type: 'reminder',
        });
        s.reminderSent = true;
        await s.save();
      }
    } catch (err) {
      console.error('Reminder error:', err.message);
    } finally {
      running = false;
    }
  }, 60 * 1000);
  timer.unref();
  return timer;
};

module.exports = startReminders;
