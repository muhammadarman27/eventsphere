const rateLimit = require('express-rate-limit');

const skip = () => process.env.RATE_LIMIT_DISABLED === 'true';
const base = { standardHeaders: true, legacyHeaders: false, skip };

const apiLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 1500,
  message: { message: 'Too many requests. Please slow down and try again shortly.' },
});

const loginLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  message: { message: 'Too many login attempts. Try again in 15 minutes.' },
});

const sensitiveLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 15,
  message: { message: 'Too many attempts. Try again in 15 minutes.' },
});

module.exports = { apiLimiter, loginLimiter, sensitiveLimiter };
