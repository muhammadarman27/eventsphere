const ApiError = require('../utils/ApiError');

const notFound = (req, res) => res.status(404).json({ message: 'Route not found' });

const errorHandler = (err, req, res, next) => {
  if (err instanceof ApiError) {
    return res.status(err.status).json({ message: err.message, ...(err.errors ? { errors: err.errors } : {}) });
  }

  if (err.name === 'ValidationError' && err.errors) {
    const errors = {};
    Object.entries(err.errors).forEach(([field, e]) => (errors[field] = e.message));
    return res.status(400).json({ message: Object.values(errors)[0] || 'Validation failed', errors });
  }
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid value for ' + (err.path || 'field') });
  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || err.keyValue || {})[0] || 'value';
    return res.status(409).json({ message: `That ${field} is already in use` });
  }
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({ message: 'Not authorized, token invalid or expired' });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'Request body is not valid JSON' });
  if (err.type === 'entity.too.large') return res.status(413).json({ message: 'Request body is too large' });

  console.error(`[error] ${req.method} ${req.originalUrl}: ${process.env.NODE_ENV === 'production' ? err.message : err.stack}`);
  res.status(500).json({ message: 'Something went wrong on our side. Please try again.' });
};

module.exports = { notFound, errorHandler };
