const jwt = require('jsonwebtoken');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');

const getToken = (req) => {
  const header = req.headers.authorization;
  return header && header.startsWith('Bearer ') ? header.slice(7) : null;
};

const userFromToken = async (token) => {
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  const user = await User.findById(decoded.id);
  if (!user) return null;
  if (user.passwordChangedAt && Math.floor(user.passwordChangedAt.getTime() / 1000) > decoded.iat) return null;
  return user;
};

const protect = async (req, res, next) => {
  const token = getToken(req);
  if (!token) return next(new ApiError(401, 'Not authorized, no token'));
  try {
    const user = await userFromToken(token);
    if (!user) return next(new ApiError(401, 'Your session is no longer valid. Please log in again.'));
    req.user = user;
    next();
  } catch (error) {
    next(new ApiError(401, 'Not authorized, token invalid or expired'));
  }
};

const optionalAuth = async (req, res, next) => {
  const token = getToken(req);
  if (token) {
    try {
      const user = await userFromToken(token);
      if (user) req.user = user;
    } catch (error) {
    }
  }
  next();
};

const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return next(new ApiError(403, 'You do not have permission to do this'));
  }
  next();
};

module.exports = { protect, optionalAuth, authorize };
