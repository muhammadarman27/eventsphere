const ApiError = require('../utils/ApiError');
const { isObjectId } = require('../utils/validators');

module.exports = (req, res, next, value, name) => {
  if (!isObjectId(value)) return next(new ApiError(400, `Invalid ${name}`));
  next();
};
