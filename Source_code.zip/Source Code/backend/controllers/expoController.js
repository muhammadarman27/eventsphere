const Expo = require('../models/Expo');
const Booth = require('../models/Booth');
const Session = require('../models/Session');
const Exhibitor = require('../models/Exhibitor');
const User = require('../models/User');
const Registration = require('../models/Registration');
const Message = require('../models/Message');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { CATEGORIES } = require('../utils/constants');
const { createValidator, asString, escapeRegex, parseDate } = require('../utils/validators');
const { parsePagination, paginationMeta } = require('../utils/pagination');
const { computeStatus, statusQuery, serializeExpo } = require('../utils/expoUtils');
const { notifyUsers } = require('../utils/notify');

const makeBoothNumber = (row, col) => `${String.fromCharCode(65 + row)}${col + 1}`;
const isAdmin = (req) => req.user && req.user.role === 'admin';

const loadVisibleExpo = async (req, fields) => {
  const expo = await Expo.findById(req.params.id).select(fields);
  if (!expo || (expo.status === 'draft' && !isAdmin(req))) throw new ApiError(404, 'Event not found');
  return expo;
};

const SORTS = {
  date_asc: { startDate: 1, _id: 1 },
  date_desc: { startDate: -1, _id: 1 },
  newest: { createdAt: -1, _id: 1 },
  popular: { registeredCount: -1, startDate: 1 },
};

exports.getExpos = asyncHandler(async (req, res) => {
  const search = asString(req.query.search);
  const category = asString(req.query.category);
  const status = asString(req.query.status);
  const sort = SORTS[asString(req.query.sort)] || SORTS.date_asc;
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 9, maxLimit: 100 });

  const filters = [];
  if (!isAdmin(req)) filters.push({ status: { $ne: 'draft' } });
  if (search) {
    const rx = new RegExp(escapeRegex(search.slice(0, 80)), 'i');
    filters.push({ $or: [{ title: rx }, { theme: rx }, { location: rx }, { venue: rx }, { description: rx }] });
  }
  if (CATEGORIES.includes(category)) filters.push({ category });
  const sq = status ? statusQuery(status) : null;
  if (sq) filters.push(sq);
  const from = parseDate(asString(req.query.from));
  const to = parseDate(asString(req.query.to));
  if (from) filters.push({ endDate: { $gte: from } });
  if (to) filters.push({ startDate: { $lte: new Date(to.getTime() + 24 * 60 * 60 * 1000 - 1) } });
  const filter = filters.length ? { $and: filters } : {};

  const [items, total] = await Promise.all([
    Expo.find(filter).sort(sort).skip(skip).limit(limit).lean(),
    Expo.countDocuments(filter),
  ]);

  let registered = new Set();
  if (req.user && req.user.role === 'attendee' && items.length) {
    const regs = await Registration.find({ user: req.user._id, expo: { $in: items.map((e) => e._id) } }).select('expo').lean();
    registered = new Set(regs.map((r) => String(r.expo)));
  }

  res.json({
    data: items.map((e) => serializeExpo(e, { isRegistered: registered.has(String(e._id)) }, { isAdmin: isAdmin(req) })),
    pagination: paginationMeta(total, page, limit),
  });
});

exports.getExpo = asyncHandler(async (req, res) => {
  const expo = await loadVisibleExpo(req, '');
  if (!isAdmin(req)) Expo.updateOne({ _id: expo._id }, { $inc: { views: 1 } }).catch(() => {});

  const [boothRows, sessionCount, exhibitorCount, registration] = await Promise.all([
    Booth.aggregate([{ $match: { expo: expo._id } }, { $group: { _id: '$status', n: { $sum: 1 } } }]),
    Session.countDocuments({ expo: expo._id }),
    Exhibitor.countDocuments({ applications: { $elemMatch: { expo: expo._id, status: 'approved' } } }),
    req.user && req.user.role === 'attendee' ? Registration.findOne({ user: req.user._id, expo: expo._id }).select('status day passType').lean() : null,
  ]);
  const booths = { total: 0, available: 0, reserved: 0, booked: 0 };
  boothRows.forEach((r) => {
    booths[r._id] = r.n;
    booths.total += r.n;
  });

  res.json(serializeExpo(
    expo,
    {
      isRegistered: !!registration,
      registration: registration ? { _id: registration._id, status: registration.status || 'confirmed', day: registration.day || '', passType: registration.passType || '' } : null,
      booths, sessionCount, exhibitorCount,
    },
    { isAdmin: isAdmin(req) }
  ));
});

exports.getBooths = asyncHandler(async (req, res) => {
  await loadVisibleExpo(req, '_id status');
  const booths = await Booth.find({ expo: req.params.id })
    .populate('exhibitor', 'companyName logo category user')
    .sort({ row: 1, column: 1 })
    .lean();

  const admin = isAdmin(req);
  res.json(
    booths.map((b) => ({
      ...b,
      visitorCount: admin ? b.visitorCount : undefined,
      exhibitor: b.exhibitor ? { ...b.exhibitor, user: req.user ? b.exhibitor.user : undefined } : null,
    }))
  );
});

exports.getSessions = asyncHandler(async (req, res) => {
  await loadVisibleExpo(req, '_id status');
  const filter = { expo: req.params.id };
  if (req.query.upcoming === 'true') filter.endTime = { $gt: new Date() };

  const sessions = await Session.find(filter).sort({ startTime: 1 }).lean();
  res.json(sessions.map((s) => ({ ...s, attendeeCount: s.attendees.length, attendees: undefined })));
});

exports.getExhibitors = asyncHandler(async (req, res) => {
  const expo = await loadVisibleExpo(req, '_id status');
  const search = asString(req.query.search).toLowerCase();
  const category = asString(req.query.category);
  const booth = asString(req.query.booth).toLowerCase();
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 12, maxLimit: 50 });

  const exhibitors = await Exhibitor.find({
    applications: { $elemMatch: { expo: expo._id, status: 'approved' } },
    ...(category ? { category } : {}),
  })
    .populate('applications.booth', 'boothNumber')
    .sort({ companyName: 1 })
    .lean();

  const list = exhibitors
    .map((ex) => {
      const application = ex.applications.find((a) => String(a.expo) === String(expo._id) && a.status === 'approved');
      return {
        _id: ex._id,
        user: req.user ? ex.user : undefined,
        companyName: ex.companyName,
        logo: ex.logo,
        description: ex.description,
        category: ex.category,
        website: ex.website,
        products: ex.products,
        boothNumber: (application && application.booth && application.booth.boothNumber) || '',
      };
    })
    .filter((ex) => {
      const text = `${ex.companyName} ${ex.description} ${ex.products.map((p) => p.name).join(' ')}`.toLowerCase();
      return (!search || text.includes(search)) && (!booth || ex.boothNumber.toLowerCase().includes(booth));
    });

  res.json({ data: list.slice(skip, skip + limit), pagination: paginationMeta(list.length, page, limit) });
});

const expoValidator = (body, partial) =>
  createValidator(body, { partial })
    .string('title', { required: true, min: 3, max: 120, label: 'Title' })
    .string('description', { max: 5000, label: 'Description' })
    .string('theme', { max: 120, label: 'Theme' })
    .oneOf('category', CATEGORIES, { fallback: 'General', label: 'Category' })
    .url('banner', { label: 'Banner image' })
    .string('location', { required: true, min: 2, max: 160, label: 'Location' })
    .string('venue', { max: 160, label: 'Venue' })
    .string('address', { max: 300, label: 'Address' })
    .date('startDate', { required: true, label: 'Start date' })
    .date('endDate', { required: true, label: 'End date' })
    .time('openTime', { label: 'Opening time' })
    .time('closeTime', { label: 'Closing time' })
    .int('capacity', { min: 0, max: 1000000, fallback: 0, label: 'Capacity' });

exports.createExpo = asyncHandler(async (req, res) => {
  const v = expoValidator(req.body, false)
    .int('rows', { min: 1, max: 10, fallback: 4, label: 'Booth rows' })
    .int('columns', { min: 1, max: 12, fallback: 6, label: 'Booth columns' })
    .boolean('published');
  const data = v.assert();
  if (data.endDate < data.startDate) {
    throw new ApiError(400, 'End date must be on or after the start date', { endDate: 'End date must be on or after the start date' });
  }
  if (data.openTime && data.closeTime && data.closeTime <= data.openTime && data.startDate.getTime() === data.endDate.getTime()) {
    throw new ApiError(400, 'Closing time must be after opening time', { closeTime: 'Closing time must be after opening time' });
  }

  const { rows, columns, published, ...fields } = data;
  const expo = await Expo.create({
    ...fields,
    status: published === false ? 'draft' : 'upcoming',
    floorPlan: { rows, columns },
    organizer: req.user._id,
  });

  const booths = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < columns; col++) {
      booths.push({
        expo: expo._id,
        boothNumber: makeBoothNumber(row, col),
        row,
        column: col,
        size: row === 0 ? 'large' : 'small',
        price: row === 0 ? 1500 : 800,
      });
    }
  }
  try {
    await Booth.insertMany(booths);
  } catch (err) {
    await expo.deleteOne();
    throw err;
  }

  res.status(201).json(serializeExpo(expo, {}, { isAdmin: true }));
});

exports.updateExpo = asyncHandler(async (req, res) => {
  const expo = await Expo.findById(req.params.id);
  if (!expo) throw new ApiError(404, 'Event not found');

  const v = expoValidator(req.body, true).boolean('published').oneOf('status', ['completed'], { label: 'Status' });
  const { published, status, ...data } = v.assert();

  const startDate = data.startDate || expo.startDate;
  const endDate = data.endDate || expo.endDate;
  if (endDate < startDate) {
    throw new ApiError(400, 'End date must be on or after the start date', { endDate: 'End date must be on or after the start date' });
  }
  if (data.capacity !== undefined && data.capacity > 0 && data.capacity < expo.registeredCount) {
    throw new ApiError(400, `Capacity cannot be lower than the ${expo.registeredCount} people already registered`, {
      capacity: `Already ${expo.registeredCount} registered`,
    });
  }

  const watched = ['startDate', 'endDate', 'location', 'venue', 'address'];
  const scheduleChanged = watched.some((f) => data[f] !== undefined && String(data[f]) !== String(expo[f]));

  Object.assign(expo, data);
  if (published === false) expo.status = 'draft';
  else if (published === true && expo.status === 'draft') expo.status = 'upcoming';
  if (status === 'completed') expo.status = 'completed';
  await expo.save();

  if (scheduleChanged && expo.status !== 'draft') {
    const regs = await Registration.find({ expo: expo._id }).select('user').limit(5000).lean();
    notifyUsers(req.app.get('io'), regs.map((r) => r.user), {
      title: 'Event details changed',
      message: `"${expo.title}" was updated. Please check the new dates and location.`,
      link: `/attendee/events/${expo._id}`,
      type: 'event',
    });
  }
  req.app.get('io').emit('schedule-updated', { expo: String(expo._id), message: `Updated: ${expo.title}` });

  res.json(serializeExpo(expo, {}, { isAdmin: true }));
});

exports.deleteExpo = asyncHandler(async (req, res) => {
  const expo = await Expo.findById(req.params.id);
  if (!expo) throw new ApiError(404, 'Event not found');

  const [sessions, regs] = await Promise.all([
    Session.find({ expo: expo._id }).select('_id'),
    Registration.find({ expo: expo._id }).select('user').limit(5000).lean(),
  ]);
  const sessionIds = sessions.map((s) => s._id);

  await Promise.all([
    Booth.deleteMany({ expo: expo._id }),
    Session.deleteMany({ expo: expo._id }),
    Registration.deleteMany({ expo: expo._id }),
    Exhibitor.updateMany({}, { $pull: { applications: { expo: expo._id } } }),
    User.updateMany(
      { $or: [{ bookmarkedSessions: { $in: sessionIds } }, { registeredExpos: expo._id }] },
      { $pull: { bookmarkedSessions: { $in: sessionIds }, registeredExpos: expo._id } }
    ),
    Message.updateMany({ expo: expo._id }, { $unset: { expo: 1 } }),
    expo.deleteOne(),
  ]);

  if (expo.status !== 'draft') {
    notifyUsers(req.app.get('io'), regs.map((r) => r.user), {
      title: 'Event cancelled',
      message: `"${expo.title}" has been removed by the organizer.`,
      type: 'event',
    });
  }
  req.app.get('io').emit('schedule-updated', { expo: String(expo._id), message: `Removed: ${expo.title}` });
  res.json({ message: 'Event deleted' });
});

exports.getRegistrations = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 50 });
  const status = asString(req.query.status);
  const filter = { expo: req.params.id };
  if (status === 'confirmed') filter.status = { $nin: ['pending', 'rejected'] };
  else if (['pending', 'rejected'].includes(status)) filter.status = status;
  const [rows, total] = await Promise.all([
    Registration.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('user', 'name email').lean(),
    Registration.countDocuments(filter),
  ]);
  res.json({
    data: rows.filter((r) => r.user).map((r) => ({
      _id: r._id,
      user: r.user,
      registeredAt: r.createdAt,
      status: r.status || 'confirmed',
      day: r.day || '',
      passType: r.passType || '',
      fullName: r.fullName || r.user.name,
      email: r.email || r.user.email,
      phone: r.phone || '',
      company: r.company || '',
      jobTitle: r.jobTitle || '',
      checkedInAt: r.checkedInAt || null,
      emailStatus: r.emailStatus || '',
    })),
    pagination: paginationMeta(total, page, limit),
  });
});

exports.computeStatus = computeStatus;
