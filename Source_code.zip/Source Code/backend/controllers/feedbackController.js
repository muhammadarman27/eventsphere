const Feedback = require('../models/Feedback');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { asString } = require('../utils/validators');
const { notifyUsers } = require('../utils/notify');
const User = require('../models/User');

const STATUSES = ['open', 'in-progress', 'resolved'];

exports.listFeedback = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { user: req.user._id };
  const status = asString(req.query.status);
  if (STATUSES.includes(status)) filter.status = status;
  const items = await Feedback.find(filter).sort({ createdAt: -1 }).limit(200).populate('user', 'name role').lean();
  res.json(items.map((f) => ({ ...f, user: f.user ? { _id: f.user._id, name: f.user.name, role: f.user.role } : null })));
});

exports.createFeedback = asyncHandler(async (req, res) => {
  const subject = asString(req.body && req.body.subject);
  const message = asString(req.body && req.body.message);
  if (!subject || !message) throw new ApiError(400, 'Enter a subject and a message', { subject: !subject ? 'Required' : undefined, message: !message ? 'Required' : undefined });
  if (subject.length > 160 || message.length > 5000) throw new ApiError(400, 'Your message is too long');
  const item = await Feedback.create({ user: req.user._id, subject, message });

  const admins = await User.find({ role: 'admin' }).select('_id').limit(50).lean();
  notifyUsers(req.app.get('io'), admins.map((a) => a._id), { title: 'New support request', message: subject.slice(0, 120), link: '/admin/support', type: 'support' });
  res.status(201).json(item);
});

exports.respondToFeedback = asyncHandler(async (req, res) => {
  const body = req.body || {};
  const set = {};
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) throw new ApiError(400, 'Choose open, in-progress or resolved');
    set.status = body.status;
  }
  if (body.response !== undefined) {
    const response = asString(body.response);
    if (response.length > 5000) throw new ApiError(400, 'The response is too long');
    set.response = response;
  }
  const item = await Feedback.findByIdAndUpdate(req.params.id, { $set: set }, { new: true, runValidators: true });
  if (!item) throw new ApiError(404, 'Request not found');
  const owner = await User.findById(item.user).select('role');
  notifyUsers(req.app.get('io'), [item.user], { title: 'Support update', message: item.subject.slice(0, 120), link: `/${owner ? owner.role : 'attendee'}/support`, type: 'support' });
  res.json(item);
});
