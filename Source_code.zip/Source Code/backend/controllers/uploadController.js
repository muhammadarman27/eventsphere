const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { signParams, isConfigured } = require('../utils/cloudinary');

exports.signUpload = asyncHandler(async (req, res) => {
  if (!isConfigured()) {
    throw new ApiError(503, 'Image upload is not set up yet. Add the Cloudinary keys to backend/.env.');
  }
  const timestamp = Math.floor(Date.now() / 1000);
  const folder = req.user.role === 'admin' ? 'eventsphere/events' : 'eventsphere/logos';
  const signature = signParams({ folder, timestamp }, process.env.CLOUDINARY_API_SECRET);

  res.json({
    cloudName: process.env.CLOUDINARY_CLOUD_NAME,
    apiKey: process.env.CLOUDINARY_API_KEY,
    timestamp,
    folder,
    signature,
  });
});
