const User = require('../models/User');
const Expo = require('../models/Expo');
const Session = require('../models/Session');
const Registration = require('../models/Registration');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { computeStatus, serializeExpo } = require('../utils/expoUtils');
const { passError } = require('../utils/passes');
const { isEmail } = require('../utils/validators');
const { notifyUsers } = require('../utils/notify');

const isConfirmed = (r) => !r.status || r.status === 'confirmed';

const attendeeDetails = (body) => {
  const out = {};
  const limits = { fullName: 120, email: 254, phone: 30, company: 160, jobTitle: 160 };
  for (const [key, max] of Object.entries(limits)) {
    const v = typeof body[key] === 'string' ? body[key].trim() : '';
    if (!v || v.length > max) throw new ApiError(400, 'Complete all attendee details.', { [key]: 'This field is required' });
    out[key] = v;
  }
  if (!isEmail(out.email)) throw new ApiError(400, 'Enter a valid email.', { email: 'Enter a valid email' });
  if (!/^\+?[\d ()-]{7,30}$/.test(out.phone) || out.phone.replace(/\D/g, '').length < 7) {
    throw new ApiError(400, 'Enter a valid phone number.', { phone: 'Enter a valid phone number' });
  }
  out.marketingConsent = body.marketingConsent === true;
  if (out.marketingConsent) out.marketingConsentAt = new Date();
  return out;
};

const toPlain = (session) => {
  const obj = session.toObject ? session.toObject() : { ...session };
  obj.attendeeCount = obj.attendees.length;
  delete obj.attendees;
  return obj;
};
const byTime = (a, b) => new Date(a.startTime) - new Date(b.startTime);

exports.getAgenda = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('bookmarkedSessions');
  const [bookmarked, booked, regs] = await Promise.all([
    Session.find({ _id: { $in: user.bookmarkedSessions } }).populate('expo', 'title'),
    Session.find({ attendees: req.user._id }).populate('expo', 'title'),
    Registration.find({ user: req.user._id }).populate('expo').lean(),
  ]);
  const registrations = regs.filter((r) => r.expo);

  res.json({
    bookmarked: bookmarked.map(toPlain).sort(byTime),
    booked: booked.map(toPlain).sort(byTime),
    registeredExpos: registrations.map((r) => String(r.expo._id)),
    registrations: registrations
      .map((r) => ({
        _id: r._id,
        registeredAt: r.createdAt,
        status: r.status || 'confirmed',
        day: r.day || '',
        passType: r.passType || '',
        checkedIn: !!r.checkedInAt,
        marketingConsent: !!r.marketingConsent,
        expo: serializeExpo(r.expo),
      }))
      .sort((a, b) => new Date(a.expo.startDate) - new Date(b.expo.startDate)),
  });
});

exports.registerForExpo = asyncHandler(async (req, res) => {
  const expo = await Expo.findById(req.params.id).select('title status startDate endDate organizer');
  if (!expo || expo.status === 'draft') throw new ApiError(404, 'Event not found');
  if (computeStatus(expo) === 'completed') throw new ApiError(400, 'This event has already ended');

  const body = req.body || {};
  const problem = passError(expo, body.day, body.passType);
  if (problem) throw new ApiError(400, problem);
  const details = attendeeDetails(body);

  if (await Registration.exists({ user: req.user._id, expo: expo._id })) {
    throw new ApiError(409, 'You already registered for this event');
  }

  const claimed = await Expo.findOneAndUpdate(
    { _id: expo._id, $or: [{ capacity: { $not: { $gt: 0 } } }, { $expr: { $lt: ['$registeredCount', '$capacity'] } }] },
    { $inc: { registeredCount: 1 } },
    { new: true }
  );
  if (!claimed) throw new ApiError(409, 'This event is full');

  let registration;
  try {
    registration = await Registration.create({
      user: req.user._id, expo: expo._id, status: 'pending', day: body.day, passType: body.passType, ...details,
    });
  } catch (err) {
    await Expo.updateOne({ _id: expo._id, registeredCount: { $gt: 0 } }, { $inc: { registeredCount: -1 } });
    if (err.code === 11000) throw new ApiError(409, 'You already registered for this event');
    throw err;
  }

  const io = req.app.get('io');
  notifyUsers(io, [req.user._id], { title: 'Registration submitted', message: `Your request for "${expo.title}" is waiting for organizer confirmation.`, link: '/attendee/agenda', type: 'registration' });
  notifyUsers(io, [expo.organizer], { title: 'New registration request', message: `${details.fullName} requested a pass for "${expo.title}".`, link: '/admin/registrations', type: 'registration' });
  res.status(201).json({ message: 'Registration sent to the organizer', status: 'pending', registrationId: registration._id, registeredCount: claimed.registeredCount });
});

exports.unregisterFromExpo = asyncHandler(async (req, res) => {
  const removed = await Registration.findOneAndDelete({ user: req.user._id, expo: req.params.id });
  if (!removed) throw new ApiError(404, 'You are not registered for this event');
  if (removed.status !== 'rejected') await Expo.updateOne({ _id: req.params.id, registeredCount: { $gt: 0 } }, { $inc: { registeredCount: -1 } });

  const result = await Session.updateMany({ expo: req.params.id, attendees: req.user._id }, { $pull: { attendees: req.user._id } });
  res.json({ message: 'Registration cancelled', ticketsCancelled: result.modifiedCount || 0 });
});

exports.toggleBookmark = asyncHandler(async (req, res) => {
  const session = await Session.findById(req.params.id).select('_id');
  if (!session) throw new ApiError(404, 'Session not found');

  const added = await User.updateOne(
    { _id: req.user._id, bookmarkedSessions: { $ne: session._id } },
    { $addToSet: { bookmarkedSessions: session._id } }
  );
  if (added.modifiedCount) {
    await Session.updateOne({ _id: session._id }, { $inc: { bookmarkCount: 1 } });
    return res.json({ bookmarked: true });
  }
  const removed = await User.updateOne(
    { _id: req.user._id, bookmarkedSessions: session._id },
    { $pull: { bookmarkedSessions: session._id } }
  );
  if (removed.modifiedCount) await Session.updateOne({ _id: session._id, bookmarkCount: { $gt: 0 } }, { $inc: { bookmarkCount: -1 } });
  res.json({ bookmarked: false });
});

exports.bookTicket = asyncHandler(async (req, res) => {
  const session = await Session.findById(req.params.id).select('expo title startTime endTime');
  if (!session) throw new ApiError(404, 'Session not found');
  if (session.endTime <= new Date()) throw new ApiError(400, 'This session has already ended');

  const registration = await Registration.findOne({ user: req.user._id, expo: session.expo }).select('status').lean();
  if (!registration) throw new ApiError(403, 'Register for this event before booking its sessions');
  if (!isConfirmed(registration)) throw new ApiError(403, 'Your registration must be confirmed by the organizer before you can book sessions');
  const clash = await Session.findOne({
    attendees: req.user._id,
    _id: { $ne: session._id },
    startTime: { $lt: session.endTime },
    endTime: { $gt: session.startTime },
  }).select('title');
  if (clash) throw new ApiError(409, `This overlaps with "${clash.title}" in your schedule`);

  const updated = await Session.findOneAndUpdate(
    {
      _id: session._id,
      attendees: { $ne: req.user._id },
      $expr: { $lt: [{ $size: '$attendees' }, '$capacity'] },
    },
    { $addToSet: { attendees: req.user._id } },
    { new: true }
  );
  if (!updated) {
    const fresh = await Session.findById(session._id).select('attendees');
    if (fresh && fresh.attendees.some((id) => id.equals(req.user._id))) throw new ApiError(409, 'You already booked this session');
    throw new ApiError(409, 'This session is full');
  }

  res.json({ message: 'Ticket booked', seatsLeft: updated.capacity - updated.attendees.length });
});

exports.cancelTicket = asyncHandler(async (req, res) => {
  const result = await Session.updateOne({ _id: req.params.id, attendees: req.user._id }, { $pull: { attendees: req.user._id } });
  if (!result.modifiedCount) throw new ApiError(404, 'You do not have a ticket for this session');
  res.json({ message: 'Ticket cancelled' });
});

exports.withdrawConsent = asyncHandler(async (req, res) => {
  const reg = await Registration.findOneAndUpdate({ _id: req.params.id, user: req.user._id }, { $set: { marketingConsent: false } }, { new: true });
  if (!reg) throw new ApiError(404, 'Registration not found');
  res.json({ message: 'Marketing consent withdrawn' });
});
