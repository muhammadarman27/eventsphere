const mongoose = require('mongoose');
const Message = require('../models/Message');
const User = require('../models/User');
const Exhibitor = require('../models/Exhibitor');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { createValidator, asString, escapeRegex, isObjectId, parseDate } = require('../utils/validators');

const canMessage = {
  attendee: ['exhibitor', 'admin'],
  exhibitor: ['admin', 'exhibitor', 'attendee'],
  admin: ['admin', 'exhibitor', 'attendee'],
};

const contactRoles = {
  attendee: ['exhibitor', 'admin'],
  exhibitor: ['admin', 'exhibitor'],
  admin: ['exhibitor', 'attendee'],
};

const attachCompanies = async (users) => {
  const profiles = await Exhibitor.find({ user: { $in: users.map((u) => u._id) } }).select('user companyName').lean();
  const byUser = new Map(profiles.map((p) => [String(p.user), p.companyName]));
  return users.map((u) => ({ _id: u._id, name: u.name, role: u.role, companyName: byUser.get(String(u._id)) || '' }));
};

exports.getContacts = asyncHandler(async (req, res) => {
  const q = asString(req.query.q).slice(0, 60);
  const filter = { role: { $in: contactRoles[req.user.role] }, _id: { $ne: req.user._id } };
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    const byCompany = await Exhibitor.find({ companyName: rx }).select('user').limit(50).lean();
    filter.$or = [{ name: rx }, { _id: { $in: byCompany.map((c) => c.user) } }];
  }
  const users = await User.find(filter).select('name role').sort({ name: 1 }).limit(50).lean();
  res.json(await attachCompanies(users));
});

exports.getConversations = asyncHandler(async (req, res) => {
  const me = req.user._id;
  const rows = await Message.aggregate([
    { $match: { $or: [{ sender: me }, { receiver: me }] } },
    { $addFields: { partner: { $cond: [{ $eq: ['$sender', me] }, '$receiver', '$sender'] } } },
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: '$partner',
        lastMessage: { $first: '$content' },
        lastAt: { $first: '$createdAt' },
        unread: { $sum: { $cond: [{ $and: [{ $eq: ['$receiver', me] }, { $eq: ['$read', false] }] }, 1, 0] } },
      },
    },
    { $sort: { lastAt: -1 } },
    { $limit: 100 },
    { $lookup: { from: User.collection.name, localField: '_id', foreignField: '_id', as: 'partner' } },
    { $unwind: '$partner' },
    { $project: { _id: 0, partner: { _id: '$partner._id', name: '$partner.name', role: '$partner.role' }, lastMessage: 1, lastAt: 1, unread: 1 } },
  ]);

  const withCompany = await attachCompanies(rows.map((r) => ({ _id: r.partner._id, name: r.partner.name, role: r.partner.role })));
  res.json(rows.map((r, i) => ({ ...r, partner: withCompany[i] })));
});

exports.getUnreadCount = asyncHandler(async (req, res) => {
  res.json({ count: await Message.countDocuments({ receiver: req.user._id, read: false }) });
});

exports.getThread = asyncHandler(async (req, res) => {
  const me = req.user._id;
  const other = req.params.userId;
  if (!(await User.exists({ _id: other }))) throw new ApiError(404, 'User not found');

  const latest = await Message.find({
    $or: [{ sender: me, receiver: other }, { sender: other, receiver: me }],
  })
    .sort({ createdAt: -1 })
    .limit(200)
    .lean();

  await Message.updateMany({ sender: other, receiver: me, read: false }, { read: true });
  res.json(latest.reverse());
});

exports.markThreadRead = asyncHandler(async (req, res) => {
  await Message.updateMany({ sender: req.params.userId, receiver: req.user._id, read: false }, { read: true });
  res.json({ ok: true });
});

exports.sendMessage = asyncHandler(async (req, res) => {
  const body = req.body || {};
  if (!isObjectId(body.receiver)) throw new ApiError(400, 'Choose who to message');
  const data = createValidator(body)
    .string('content', { required: true, max: 2000, label: 'Message' })
    .oneOf('type', ['message', 'inquiry', 'appointment'], { fallback: 'message', label: 'Type' })
    .assert();

  const target = await User.findById(body.receiver).select('role');
  if (!target) throw new ApiError(404, 'Recipient not found');
  if (String(target._id) === String(req.user._id)) throw new ApiError(400, 'You cannot message yourself');
  if (!canMessage[req.user.role].includes(target.role)) throw new ApiError(403, 'You cannot message this user');

  let appointmentSlot;
  if (data.type === 'appointment') {
    appointmentSlot = parseDate(body.appointmentSlot);
    if (!appointmentSlot || appointmentSlot <= new Date()) {
      throw new ApiError(400, 'Pick a time in the future for the appointment', { appointmentSlot: 'Pick a time in the future' });
    }
  }

  const message = await Message.create({
    sender: req.user._id,
    receiver: target._id,
    content: data.content,
    type: data.type,
    appointmentSlot,
    expo: isObjectId(body.expo) ? new mongoose.Types.ObjectId(body.expo) : undefined,
  });

  req.app.get('io').to(`user:${target._id}`).emit('message', {
    _id: message._id,
    sender: String(req.user._id),
    receiver: String(target._id),
    senderName: req.user.name,
    content: message.content,
    type: message.type,
    appointmentSlot: message.appointmentSlot,
    createdAt: message.createdAt,
  });

  res.status(201).json(message);
});
