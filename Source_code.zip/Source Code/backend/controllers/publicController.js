const Expo = require('../models/Expo');
const User = require('../models/User');
const Session = require('../models/Session');
const Exhibitor = require('../models/Exhibitor');
const asyncHandler = require('../utils/asyncHandler');
const { DAY } = require('../utils/constants');

let cache = { at: 0, stats: null, categories: null };

const refresh = async () => {
  const now = new Date();
  const published = { status: { $ne: 'draft' } };
  const [events, upcoming, exhibitors, attendees, sessions, categoryRows] = await Promise.all([
    Expo.countDocuments(published),
    Expo.countDocuments({ status: { $nin: ['draft', 'completed'] }, endDate: { $gte: new Date(now.getTime() - DAY + 1) } }),
    Exhibitor.countDocuments({ 'applications.status': 'approved' }),
    User.countDocuments({ role: 'attendee' }),
    Session.countDocuments(),
    Expo.aggregate([
      { $match: { ...published, status: { $ne: 'completed' }, endDate: { $gte: new Date(now.getTime() - DAY + 1) } } },
      { $group: { _id: '$category', n: { $sum: 1 } } },
    ]),
  ]);
  cache = {
    at: Date.now(),
    stats: { events, upcoming, exhibitors, attendees, sessions },
    categories: categoryRows.map((r) => ({ category: r._id, count: r.n })),
  };
};

const ensureFresh = async () => {
  if (!cache.stats || Date.now() - cache.at > 60 * 1000) await refresh();
};

exports.getStats = asyncHandler(async (req, res) => {
  await ensureFresh();
  res.json(cache.stats);
});

exports.getCategories = asyncHandler(async (req, res) => {
  await ensureFresh();
  res.json(cache.categories);
});
