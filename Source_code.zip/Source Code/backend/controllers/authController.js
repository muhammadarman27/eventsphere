const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Exhibitor = require('../models/Exhibitor');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { createValidator, passwordError, isEmail } = require('../utils/validators');
const { sendResetEmail } = require('../utils/mailer');

const generateToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const userResponse = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  phone: user.phone || '',
  bio: user.bio || '',
  createdAt: user.createdAt,
});

exports.register = asyncHandler(async (req, res) => {
  const v = createValidator(req.body)
    .string('name', { required: true, min: 2, max: 80, label: 'Name' })
    .email('email', { required: true })
    .oneOf('role', ['exhibitor', 'attendee'], { fallback: 'attendee', label: 'Role' })
    .string('companyName', { max: 100, label: 'Company name' });
  const pwError = passwordError(req.body && req.body.password);
  if (pwError) v.fail('password', pwError);
  const data = v.assert();

  if (await User.exists({ email: data.email })) {
    throw new ApiError(409, 'Email is already registered', { email: 'Email is already registered' });
  }

  const user = await User.create({ name: data.name, email: data.email, password: req.body.password, role: data.role });

  if (data.role === 'exhibitor') {
    try {
      await Exhibitor.create({ user: user._id, companyName: data.companyName || data.name });
    } catch (err) {
      await user.deleteOne();
      throw err;
    }
  }

  res.status(201).json({ token: generateToken(user._id), user: userResponse(user) });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
    throw new ApiError(400, 'Email and password are required');
  }

  const user = await User.findOne({ email: email.trim().toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    throw new ApiError(401, 'Invalid email or password');
  }

  res.json({ token: generateToken(user._id), user: userResponse(user) });
});

exports.getMe = asyncHandler(async (req, res) => {
  res.json({ user: userResponse(req.user) });
});

exports.updateProfile = asyncHandler(async (req, res) => {
  const data = createValidator(req.body, { partial: true })
    .string('name', { required: true, min: 2, max: 80, label: 'Name' })
    .email('email', { required: true })
    .string('phone', { max: 30, label: 'Phone' })
    .string('bio', { max: 500, label: 'Bio' })
    .assert();

  if (data.email && data.email !== req.user.email) {
    if (await User.exists({ email: data.email, _id: { $ne: req.user._id } })) {
      throw new ApiError(409, 'Email is already registered', { email: 'Email is already registered' });
    }
  }

  Object.assign(req.user, data);
  await req.user.save();
  res.json({ user: userResponse(req.user) });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (typeof currentPassword !== 'string' || !currentPassword) {
    throw new ApiError(400, 'Current password is required', { currentPassword: 'Current password is required' });
  }
  const pwError = passwordError(newPassword);
  if (pwError) throw new ApiError(400, pwError, { newPassword: pwError });

  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.matchPassword(currentPassword))) {
    throw new ApiError(400, 'Current password is incorrect', { currentPassword: 'Current password is incorrect' });
  }
  if (currentPassword === newPassword) {
    throw new ApiError(400, 'Choose a password you have not used just now', { newPassword: 'Choose a different password' });
  }

  user.password = newPassword;
  await user.save();
  res.json({ message: 'Password updated', token: generateToken(user._id) });
});

exports.forgotPassword = asyncHandler(async (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const reply = { message: 'If an account exists for that email, a reset link has been sent.' };

  const user = isEmail(email) ? await User.findOne({ email }) : null;
  if (user) {
    const rawToken = user.createResetToken();
    await user.save({ validateBeforeSave: false });

    const clientUrl = (process.env.CLIENT_URL || 'http://localhost:3000').split(',')[0].trim().replace(/\/$/, '');
    await sendResetEmail(user, `${clientUrl}/reset-password/${rawToken}`);

    if (process.env.EXPOSE_RESET_TOKEN === 'true' && process.env.NODE_ENV !== 'production') {
      reply.resetToken = rawToken;
    }
  }
  res.json(reply);
});

exports.resetPassword = asyncHandler(async (req, res) => {
  const pwError = passwordError(req.body && req.body.password);
  if (pwError) throw new ApiError(400, pwError, { password: pwError });

  const hashedToken = crypto.createHash('sha256').update(String(req.params.token)).digest('hex');
  const user = await User.findOne({
    resetPasswordToken: hashedToken,
    resetPasswordExpire: { $gt: Date.now() },
  });
  if (!user) throw new ApiError(400, 'This reset link is invalid or has expired');

  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpire = undefined;
  await user.save();

  res.json({ message: 'Password updated. You can log in now.' });
});
