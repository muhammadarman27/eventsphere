const Exhibitor = require('../models/Exhibitor');
const Expo = require('../models/Expo');
const Booth = require('../models/Booth');
const User = require('../models/User');
const Session = require('../models/Session');
const Message = require('../models/Message');
const Visit = require('../models/Visit');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { CATEGORIES } = require('../utils/constants');
const { createValidator, isObjectId, isEmail, isHttpUrl } = require('../utils/validators');
const { computeStatus } = require('../utils/expoUtils');
const { notifyUsers } = require('../utils/notify');

const getOrCreateProfile = async (user) => {
  let profile = await Exhibitor.findOne({ user: user._id });
  if (!profile) profile = await Exhibitor.create({ user: user._id, companyName: user.name });
  return profile;
};

const populateProfile = (query) =>
  query
    .populate('applications.expo', 'title startDate endDate location status')
    .populate('applications.booth', 'boothNumber size price');

exports.getMyProfile = asyncHandler(async (req, res) => {
  await getOrCreateProfile(req.user);
  res.json(await populateProfile(Exhibitor.findOne({ user: req.user._id })));
});

exports.updateMyProfile = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const body = req.body || {};

  const v = createValidator(body, { partial: true })
    .string('companyName', { required: true, min: 2, max: 100, label: 'Company name' })
    .url('logo', { label: 'Logo link' })
    .string('description', { max: 2000, label: 'Description' })
    .oneOf('category', CATEGORIES, { label: 'Category' })
    .url('website', { label: 'Website' });

  const list = (field, label, max, check) => {
    if (body[field] === undefined) return;
    if (!Array.isArray(body[field]) || body[field].length > max) return v.fail(field, `${label}: at most ${max} entries`);
    for (const item of body[field]) {
      const err = check(item || {});
      if (err) return v.fail(field, `${label}: ${err}`);
    }
    v.value[field] = body[field].map((i) => ({ ...i, name: i.name.trim() }));
  };
  list('products', 'Products', 20, (p) => {
    if (typeof p.name !== 'string' || !p.name.trim() || p.name.length > 100) return 'each product needs a name (max 100 characters)';
    if (p.description && String(p.description).length > 300) return 'description must be 300 characters or fewer';
    if (p.image && !isHttpUrl(p.image)) return 'image must be a valid http(s) link';
    return null;
  });
  list('staff', 'Staff', 20, (s) => {
    if (typeof s.name !== 'string' || !s.name.trim() || s.name.length > 100) return 'each person needs a name (max 100 characters)';
    if (s.email && !isEmail(s.email)) return `"${s.email}" is not a valid email`;
    if (s.position && String(s.position).length > 100) return 'position must be 100 characters or fewer';
    return null;
  });

  const data = v.assert();
  ['companyName', 'logo', 'description', 'category', 'website', 'products', 'staff'].forEach((f) => {
    if (data[f] !== undefined) profile[f] = data[f];
  });
  await profile.save();
  res.json(await populateProfile(Exhibitor.findOne({ user: req.user._id })));
});

exports.applyToExpo = asyncHandler(async (req, res) => {
  const { expoId } = req.body || {};
  if (!isObjectId(expoId)) throw new ApiError(400, 'Choose an event to apply to');
  const { note } = createValidator(req.body).string('note', { max: 1000, label: 'Note' }).assert();

  const expo = await Expo.findById(expoId);
  if (!expo || expo.status === 'draft') throw new ApiError(404, 'Event not found');
  if (computeStatus(expo) === 'completed') throw new ApiError(400, 'This event has already ended');

  const profile = await getOrCreateProfile(req.user);
  if (profile.applications.some((a) => String(a.expo) === String(expoId))) {
    throw new ApiError(409, 'You already applied to this event');
  }

  profile.applications.push({ expo: expoId, note: note || '' });
  await profile.save();

  const admins = await User.find({ role: 'admin' }).select('_id');
  notifyUsers(req.app.get('io'), admins.map((a) => a._id), {
    title: 'New application',
    message: `${profile.companyName} applied for "${expo.title}".`,
    link: '/admin/applications',
    type: 'application',
  });

  res.status(201).json({ message: 'Application sent' });
});

exports.withdrawApplication = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const application = profile.applications.id(req.params.applicationId);
  if (!application) throw new ApiError(404, 'Application not found');
  if (application.status !== 'pending') throw new ApiError(400, 'Only pending applications can be withdrawn');

  if (application.booth) {
    await Booth.updateOne({ _id: application.booth, exhibitor: profile._id }, { status: 'available', exhibitor: null });
  }
  const expoId = String(application.expo);
  application.deleteOne();
  await profile.save();

  req.app.get('io').emit('booths-updated', { expo: expoId });
  res.json({ message: 'Application withdrawn' });
});

exports.reserveBooth = asyncHandler(async (req, res) => {
  if (!isObjectId(req.body && req.body.boothId)) throw new ApiError(400, 'Choose a booth');
  const profile = await getOrCreateProfile(req.user);

  const target = await Booth.findById(req.body.boothId);
  if (!target) throw new ApiError(404, 'Booth not found');

  const application = profile.applications.find((a) => String(a.expo) === String(target.expo));
  if (!application) throw new ApiError(400, 'Apply to this event first');
  if (application.status === 'rejected') throw new ApiError(400, 'Your application was rejected');
  if (application.status === 'approved') throw new ApiError(400, 'Your booth is already confirmed by the organizer');

  const booth = await Booth.findOneAndUpdate(
    { _id: target._id, status: 'available' },
    { status: 'reserved', exhibitor: profile._id },
    { new: true }
  );
  if (!booth) throw new ApiError(409, 'This booth is no longer available');

  if (application.booth) {
    await Booth.updateOne(
      { _id: application.booth, exhibitor: profile._id, status: 'reserved' },
      { status: 'available', exhibitor: null }
    );
  }
  application.booth = booth._id;
  await profile.save();

  req.app.get('io').emit('booths-updated', { expo: String(booth.expo) });
  res.json({ message: `Booth ${booth.boothNumber} reserved` });
});

exports.releaseBooth = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const booth = await Booth.findOneAndUpdate(
    { _id: req.params.boothId, exhibitor: profile._id, status: 'reserved' },
    { status: 'available', exhibitor: null },
    { new: true }
  );
  if (!booth) throw new ApiError(404, 'You have no reserved booth with that id');

  const application = profile.applications.find((a) => String(a.booth) === String(booth._id));
  if (application) application.booth = null;
  await profile.save();

  req.app.get('io').emit('booths-updated', { expo: String(booth.expo) });
  res.json({ message: `Booth ${booth.boothNumber} released` });
});

exports.getOverview = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const approvedExpoIds = profile.applications.filter((a) => a.status === 'approved').map((a) => a.expo);

  const [full, booths, unreadMessages, upcomingSessions] = await Promise.all([
    populateProfile(Exhibitor.findOne({ _id: profile._id })).lean(),
    Booth.find({ exhibitor: profile._id }).populate('expo', 'title').lean(),
    Message.countDocuments({ receiver: req.user._id, read: false }),
    Session.countDocuments({ expo: { $in: approvedExpoIds }, endTime: { $gt: new Date() } }),
  ]);

  const counts = { pending: 0, approved: 0, rejected: 0 };
  full.applications.forEach((a) => { counts[a.status] += 1; });
  const checks = [full.description, full.logo, full.website, full.products.length, full.staff.length];
  const completeness = Math.round((checks.filter(Boolean).length / checks.length) * 100);

  res.json({
    company: { companyName: full.companyName, category: full.category, completeness },
    counts,
    visits: booths.reduce((s, b) => s + (b.visitorCount || 0), 0),
    unreadMessages,
    upcomingSessions,
    booths: booths.map((b) => ({ _id: b._id, boothNumber: b.boothNumber, status: b.status, expo: b.expo, visits: b.visitorCount || 0 })),
    applications: full.applications
      .filter((a) => a.expo)
      .map((a) => ({
        _id: a._id, status: a.status, expo: a.expo, booth: a.booth, reviewNote: a.reviewNote, appliedAt: a.appliedAt,
      }))
      .sort((a, b) => new Date(b.appliedAt) - new Date(a.appliedAt)),
  });
});

exports.getSchedule = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const expoIds = profile.applications.filter((a) => a.status === 'approved').map((a) => a.expo);
  const sessions = await Session.find({ expo: { $in: expoIds }, endTime: { $gt: new Date() } })
    .sort({ startTime: 1 })
    .limit(100)
    .populate('expo', 'title')
    .lean();
  res.json(sessions.map((s) => ({ ...s, attendeeCount: s.attendees.length, attendees: undefined })));
});

exports.recordVisit = asyncHandler(async (req, res) => {
  if (!(await Exhibitor.exists({ _id: req.params.id }))) throw new ApiError(404, 'Exhibitor not found');
  try {
    await Visit.create({ attendee: req.user._id, exhibitor: req.params.id, day: new Date().toISOString().slice(0, 10) });
  } catch (err) {
    if (err.code === 11000) return res.json({ ok: true, counted: false });
    throw err;
  }
  await Booth.updateMany({ exhibitor: req.params.id, status: 'booked' }, { $inc: { visitorCount: 1 } });
  res.json({ ok: true, counted: true });
});
