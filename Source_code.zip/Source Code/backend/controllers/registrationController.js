const crypto = require('crypto');
const Registration = require('../models/Registration');
const Expo = require('../models/Expo');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const mongoose = require('mongoose');
const { asString, isObjectId } = require('../utils/validators');
const { parsePagination, paginationMeta } = require('../utils/pagination');
const { parseTicketCode } = require('../utils/ticketCode');
const { todayAtVenue } = require('../utils/passes');
const { computeStatus } = require('../utils/expoUtils');
const { notifyUsers } = require('../utils/notify');
const { sendTicketEmail } = require('../utils/mailer');

const newToken = () => crypto.randomBytes(32).toString('hex');

exports.reviewRegistration = asyncHandler(async (req, res) => {
  const status = asString(req.body && req.body.status);
  if (!['confirmed', 'rejected'].includes(status)) throw new ApiError(400, 'Choose confirmed or rejected');

  const reg = await Registration.findById(req.params.id);
  if (!reg) throw new ApiError(404, 'Registration not found');
  const expo = await Expo.findById(reg.expo).select('title venue location status startDate endDate');
  if (!expo) throw new ApiError(404, 'Event not found');

  const update = { status, ...(status === 'confirmed' ? { ticketToken: newToken() } : {}) };
  const updated = await Registration.findOneAndUpdate({ _id: reg._id, status: 'pending' }, { $set: update }, { new: true });
  if (!updated) throw new ApiError(409, 'This registration has already been reviewed');

  if (status === 'rejected') {
    await Expo.updateOne({ _id: expo._id, registeredCount: { $gt: 0 } }, { $inc: { registeredCount: -1 } });
  } else {
    updated.emailStatus = await sendTicketEmail(updated, expo);
    await updated.save();
  }

  notifyUsers(req.app.get('io'), [reg.user], {
    title: status === 'confirmed' ? 'Registration confirmed' : 'Registration not approved',
    message: status === 'confirmed' ? `Your pass for "${expo.title}" is ready. Open My agenda to view your QR ticket.` : `Your registration for "${expo.title}" was not approved.`,
    link: '/attendee/agenda',
    type: 'registration',
  });
  res.json({ _id: updated._id, status: updated.status, emailStatus: updated.emailStatus });
});

exports.getTicket = asyncHandler(async (req, res) => {
  const reg = await Registration.findById(req.params.id).select('+ticketToken');
  if (!reg) throw new ApiError(404, 'Ticket not found');
  const isOwner = String(reg.user) === String(req.user._id);
  if (!isOwner && req.user.role !== 'admin') throw new ApiError(403, 'This ticket is private');

  const expo = await Expo.findById(reg.expo).lean();
  if (!expo) throw new ApiError(404, 'Event not found');
  const status = reg.status || 'confirmed';
  if (status !== 'confirmed' || expo.status === 'draft') throw new ApiError(409, 'Tickets are available only for confirmed registrations');

  if (!reg.ticketToken) {
    const issued = await Registration.findOneAndUpdate({ _id: reg._id, ticketToken: { $exists: false } }, { $set: { ticketToken: newToken() } }, { new: true }).select('+ticketToken');
    reg.ticketToken = (issued || (await Registration.findById(reg._id).select('+ticketToken'))).ticketToken;
  }
  const holder = isOwner ? req.user : await User.findById(reg.user).select('name');
  res.json({
    registration: {
      _id: reg._id,
      day: reg.day || '',
      passType: reg.passType || '',
      fullName: reg.fullName || (holder && holder.name) || 'Attendee',
      ticketToken: reg.ticketToken,
      checkedInAt: reg.checkedInAt || null,
    },
    expo: {
      _id: expo._id, title: expo.title, location: expo.location, venue: expo.venue, address: expo.address,
      startDate: expo.startDate, endDate: expo.endDate, openTime: expo.openTime, closeTime: expo.closeTime, banner: expo.banner,
      status: computeStatus(expo),
    },
  });
});

exports.checkIn = asyncHandler(async (req, res) => {
  let parsed;
  try { parsed = parseTicketCode(req.body && req.body.token); } catch (e) { throw new ApiError(400, e.message); }

  const filter = parsed.short
    ? { $expr: { $eq: [{ $substrBytes: [{ $toString: '$_id' }, 16, 8] }, parsed.code] } }
    : { ticketToken: parsed.code };
  const matches = await Registration.find(filter).select('+ticketToken').limit(2);
  if (matches.length > 1) throw new ApiError(409, 'More than one ticket matches this number. Scan the full QR code instead.');
  const reg = matches[0];
  if (!reg) throw new ApiError(404, 'Ticket not found');

  const expo = await Expo.findById(reg.expo).select('title status startDate endDate');
  if (!expo || expo.status === 'draft' || (reg.status || 'confirmed') !== 'confirmed') throw new ApiError(409, 'This ticket is not valid');
  if (reg.day && reg.day !== todayAtVenue()) throw new ApiError(409, `This pass is valid only on ${reg.day}`);

  const updated = await Registration.findOneAndUpdate(
    { _id: reg._id, checkedInAt: { $exists: false }, status: { $ne: 'rejected' } },
    { $set: { checkedInAt: new Date() } },
    { new: true }
  );
  if (!updated) throw new ApiError(409, 'This ticket has already been checked in');
  req.app.get('io').to(`user:${reg.user}`).emit('schedule-updated', { expo: String(expo._id), message: 'You are checked in' });
  res.json({ name: updated.fullName || 'Attendee', event: expo.title, day: updated.day, checkedInAt: updated.checkedInAt });
});

exports.listRegistrations = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 12, maxLimit: 50 });
  const status = asString(req.query.status);
  const expoId = asString(req.query.expo);
  if (expoId && !isObjectId(expoId)) throw new ApiError(400, 'Invalid event');
  const filter = {};
  if (expoId) filter.expo = expoId;
  if (status === 'confirmed') filter.status = { $nin: ['pending', 'rejected'] };
  else if (['pending', 'rejected'].includes(status)) filter.status = status;

  const [rows, total, counts] = await Promise.all([
    Registration.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('user', 'name email').populate('expo', 'title').lean(),
    Registration.countDocuments(filter),
    Registration.aggregate([
      { $match: expoId ? { expo: new mongoose.Types.ObjectId(expoId) } : {} },
      { $group: { _id: { $ifNull: ['$status', 'confirmed'] }, n: { $sum: 1 } } },
    ]),
  ]);
  const summary = { pending: 0, confirmed: 0, rejected: 0 };
  counts.forEach((c) => { summary[c._id] = c.n; });

  res.json({
    data: rows.filter((r) => r.user && r.expo).map((r) => ({
      _id: r._id,
      expo: r.expo,
      user: r.user,
      status: r.status || 'confirmed',
      day: r.day || '',
      passType: r.passType || '',
      fullName: r.fullName || r.user.name,
      email: r.email || r.user.email,
      phone: r.phone || '',
      company: r.company || '',
      jobTitle: r.jobTitle || '',
      registeredAt: r.createdAt,
      checkedInAt: r.checkedInAt || null,
      emailStatus: r.emailStatus || '',
    })),
    summary,
    pagination: paginationMeta(total, page, limit),
  });
});
