const mongoose = require('mongoose');
const Expo = require('../models/Expo');
const Booth = require('../models/Booth');
const Session = require('../models/Session');
const Exhibitor = require('../models/Exhibitor');
const User = require('../models/User');
const Message = require('../models/Message');
const Registration = require('../models/Registration');
const Notification = require('../models/Notification');
const Visit = require('../models/Visit');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { DAY } = require('../utils/constants');
const { createValidator, asString, escapeRegex, isObjectId, parseDate } = require('../utils/validators');
const { parsePagination, paginationMeta } = require('../utils/pagination');
const { fillSeries } = require('../utils/series');
const { notifyUsers } = require('../utils/notify');

const toObjectId = (id) => new mongoose.Types.ObjectId(id);

const applicationsPipeline = ({ status, expo, search } = {}) => {
  const match = {};
  if (status) match['applications.status'] = status;
  if (expo) match['applications.expo'] = toObjectId(expo);

  const pipeline = [{ $unwind: '$applications' }];
  if (Object.keys(match).length) pipeline.push({ $match: match });
  pipeline.push(
    { $lookup: { from: Expo.collection.name, localField: 'applications.expo', foreignField: '_id', as: 'expoDoc' } },
    { $unwind: '$expoDoc' },
    { $lookup: { from: Booth.collection.name, localField: 'applications.booth', foreignField: '_id', as: 'boothDoc' } },
    { $unwind: { path: '$boothDoc', preserveNullAndEmptyArrays: true } }
  );
  if (search) {
    const rx = new RegExp(escapeRegex(search.slice(0, 80)), 'i');
    pipeline.push({ $match: { $or: [{ companyName: rx }, { 'expoDoc.title': rx }] } });
  }
  pipeline.push({
    $project: {
      _id: 0,
      exhibitorId: '$_id',
      applicationId: '$applications._id',
      companyName: 1,
      category: 1,
      expoId: '$expoDoc._id',
      expoTitle: '$expoDoc.title',
      status: '$applications.status',
      note: '$applications.note',
      reviewNote: '$applications.reviewNote',
      boothId: '$boothDoc._id',
      boothNumber: { $ifNull: ['$boothDoc.boothNumber', ''] },
      appliedAt: '$applications.appliedAt',
    },
  });
  return pipeline;
};

exports.getApplications = asyncHandler(async (req, res) => {
  const status = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : '';
  const expo = isObjectId(req.query.expo) ? req.query.expo : '';
  const search = asString(req.query.search);
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 50 });

  const [result, countRows] = await Promise.all([
    Exhibitor.aggregate([
      ...applicationsPipeline({ status, expo, search }),
      { $sort: { appliedAt: -1 } },
      { $facet: { data: [{ $skip: skip }, { $limit: limit }], total: [{ $count: 'n' }] } },
    ]),
    Exhibitor.aggregate([
      { $unwind: '$applications' },
      ...(expo ? [{ $match: { 'applications.expo': toObjectId(expo) } }] : []),
      { $group: { _id: '$applications.status', n: { $sum: 1 } } },
    ]),
  ]);

  const counts = { pending: 0, approved: 0, rejected: 0, all: 0 };
  countRows.forEach((r) => {
    counts[r._id] = r.n;
    counts.all += r.n;
  });
  const total = (result[0].total[0] && result[0].total[0].n) || 0;
  res.json({ data: result[0].data, pagination: paginationMeta(total, page, limit), counts });
});

const approveWithBooth = async (exhibitor, application, boothId) => {
  if (!isObjectId(String(boothId || ''))) throw new ApiError(400, 'Assign a booth before approving');

  const booth = await Booth.findOneAndUpdate(
    { _id: boothId, expo: application.expo, $or: [{ exhibitor: null }, { exhibitor: exhibitor._id }] },
    { status: 'booked', exhibitor: exhibitor._id },
    { new: true }
  );
  if (!booth) {
    const existing = await Booth.findById(boothId).select('boothNumber expo');
    if (!existing || String(existing.expo) !== String(application.expo)) {
      throw new ApiError(400, 'Invalid booth for this event');
    }
    throw new ApiError(409, `Booth ${existing.boothNumber} is already taken`);
  }

  if (application.booth && String(application.booth) !== String(booth._id)) {
    await Booth.updateOne({ _id: application.booth, exhibitor: exhibitor._id }, { status: 'available', exhibitor: null });
  }
  application.booth = booth._id;
  application.status = 'approved';
  return booth;
};

exports.reviewApplication = asyncHandler(async (req, res) => {
  const data = createValidator(req.body)
    .oneOf('status', ['approved', 'rejected'], { required: true, label: 'Status' })
    .string('reviewNote', { max: 1000, label: 'Note' })
    .assert();

  const exhibitor = await Exhibitor.findById(req.params.exhibitorId);
  if (!exhibitor) throw new ApiError(404, 'Exhibitor not found');
  const application = exhibitor.applications.id(req.params.applicationId);
  if (!application) throw new ApiError(404, 'Application not found');

  if (data.status === 'approved') {
    await approveWithBooth(exhibitor, application, (req.body && req.body.boothId) || application.booth);
  } else {
    if (application.booth) {
      await Booth.updateOne({ _id: application.booth, exhibitor: exhibitor._id }, { status: 'available', exhibitor: null });
    }
    application.booth = null;
    application.status = 'rejected';
  }
  application.reviewNote = data.reviewNote || '';
  application.reviewedAt = new Date();
  await exhibitor.save();

  const expo = await Expo.findById(application.expo).select('title');
  const io = req.app.get('io');
  notifyUsers(io, [exhibitor.user], {
    title: `Application ${data.status}`,
    message: `Your application for "${expo ? expo.title : 'the event'}" was ${data.status}.${data.reviewNote ? ' Note: ' + data.reviewNote : ''}`,
    link: '/exhibitor/booths',
    type: 'application',
  });
  io.emit('booths-updated', { expo: String(application.expo) });

  res.json({ message: `Application ${data.status}` });
});

exports.updateBooth = asyncHandler(async (req, res) => {
  const data = createValidator(req.body, { partial: true })
    .int('price', { min: 0, max: 1000000, label: 'Price' })
    .oneOf('size', ['small', 'medium', 'large'], { label: 'Size' })
    .assert();
  const booth = await Booth.findByIdAndUpdate(req.params.id, data, { new: true });
  if (!booth) throw new ApiError(404, 'Booth not found');
  req.app.get('io').emit('booths-updated', { expo: String(booth.expo) });
  res.json(booth);
});

exports.assignBooth = asyncHandler(async (req, res) => {
  const { exhibitorId } = req.body || {};
  if (!isObjectId(exhibitorId)) throw new ApiError(400, 'Choose an exhibitor');

  const booth = await Booth.findById(req.params.id);
  if (!booth) throw new ApiError(404, 'Booth not found');
  const exhibitor = await Exhibitor.findById(exhibitorId);
  if (!exhibitor) throw new ApiError(404, 'Exhibitor not found');

  const application = exhibitor.applications.find((a) => String(a.expo) === String(booth.expo) && a.status !== 'rejected');
  if (!application) throw new ApiError(400, 'This exhibitor has no active application for the event');

  await approveWithBooth(exhibitor, application, booth._id);
  application.reviewedAt = new Date();
  await exhibitor.save();

  const io = req.app.get('io');
  notifyUsers(io, [exhibitor.user], {
    title: 'Booth assigned',
    message: `The organizer assigned you booth ${booth.boothNumber}.`,
    link: '/exhibitor/booths',
    type: 'booth',
  });
  io.emit('booths-updated', { expo: String(booth.expo) });
  res.json({ message: `Booth ${booth.boothNumber} assigned to ${exhibitor.companyName}` });
});

exports.releaseBooth = asyncHandler(async (req, res) => {
  const booth = await Booth.findById(req.params.id);
  if (!booth) throw new ApiError(404, 'Booth not found');
  if (booth.status === 'available') throw new ApiError(400, 'This booth is already available');

  const io = req.app.get('io');
  if (booth.exhibitor) {
    const exhibitor = await Exhibitor.findById(booth.exhibitor);
    const application = exhibitor && exhibitor.applications.find((a) => String(a.booth) === String(booth._id));
    if (application) {
      application.booth = null;
      if (application.status === 'approved') application.status = 'pending';
      application.reviewNote = 'Your booth was released by the organizer.';
      await exhibitor.save();
      notifyUsers(io, [exhibitor.user], {
        title: 'Booth released',
        message: `Booth ${booth.boothNumber} was released by the organizer. Please choose another booth.`,
        link: '/exhibitor/booths',
        type: 'booth',
      });
    }
  }
  booth.status = 'available';
  booth.exhibitor = null;
  await booth.save();

  io.emit('booths-updated', { expo: String(booth.expo) });
  res.json({ message: `Booth ${booth.boothNumber} is available again` });
});

const usersAffectedBy = async (session) => {
  const bookmarkers = await User.find({ bookmarkedSessions: session._id }).select('_id');
  return [...new Set([...session.attendees.map(String), ...bookmarkers.map((u) => String(u._id))])];
};

const sessionValidator = (body, partial) =>
  createValidator(body, { partial })
    .string('title', { required: true, min: 3, max: 140, label: 'Title' })
    .string('description', { max: 3000, label: 'Description' })
    .string('speakerName', { required: true, min: 2, max: 100, label: 'Speaker' })
    .string('speakerBio', { max: 160, label: 'Speaker role' })
    .string('location', { required: true, max: 100, label: 'Room or hall' })
    .date('startTime', { required: true, label: 'Start time' })
    .date('endTime', { required: true, label: 'End time' })
    .int('capacity', { min: 1, max: 10000, fallback: 100, label: 'Seats' });

const assertRoomFree = async (expo, location, startTime, endTime, ignoreId) => {
  const clash = await Session.findOne({
    expo,
    location,
    startTime: { $lt: endTime },
    endTime: { $gt: startTime },
    ...(ignoreId ? { _id: { $ne: ignoreId } } : {}),
  }).select('title');
  if (clash) throw new ApiError(409, `${location} is already used by "${clash.title}" at that time`, { location: 'Room is already in use at that time' });
};

exports.createSession = asyncHandler(async (req, res) => {
  if (!isObjectId(req.body && req.body.expo)) throw new ApiError(400, 'Choose an event', { expo: 'Choose an event' });
  const data = sessionValidator(req.body, false).assert();
  if (data.endTime <= data.startTime) {
    throw new ApiError(400, 'End time must be after start time', { endTime: 'End time must be after start time' });
  }
  if (data.endTime - data.startTime > DAY) throw new ApiError(400, 'A session cannot be longer than 24 hours', { endTime: 'Too long' });
  const expo = await Expo.findById(req.body.expo).select('title');
  if (!expo) throw new ApiError(404, 'Event not found');
  await assertRoomFree(expo._id, data.location, data.startTime, data.endTime);

  const session = await Session.create({
    expo: expo._id,
    title: data.title,
    description: data.description,
    speaker: { name: data.speakerName, bio: data.speakerBio },
    location: data.location,
    startTime: data.startTime,
    endTime: data.endTime,
    capacity: data.capacity,
  });

  req.app.get('io').emit('schedule-updated', { expo: String(expo._id), message: `New session: ${data.title}` });
  res.status(201).json(session);
});

exports.updateSession = asyncHandler(async (req, res) => {
  const session = await Session.findById(req.params.id);
  if (!session) throw new ApiError(404, 'Session not found');

  const { speakerName, speakerBio, ...data } = sessionValidator(req.body, true).assert();
  if (data.capacity !== undefined && data.capacity < session.attendees.length) {
    throw new ApiError(400, `${session.attendees.length} people already booked, so seats cannot go below that`, { capacity: 'Below booked seats' });
  }
  Object.assign(session, data);
  if (speakerName !== undefined) session.speaker.name = speakerName;
  if (speakerBio !== undefined) session.speaker.bio = speakerBio;

  if (session.endTime <= session.startTime) {
    throw new ApiError(400, 'End time must be after start time', { endTime: 'End time must be after start time' });
  }
  await assertRoomFree(session.expo, session.location, session.startTime, session.endTime, session._id);
  if (data.startTime !== undefined) session.reminderSent = false;
  await session.save();

  const io = req.app.get('io');
  io.emit('schedule-updated', { expo: String(session.expo), message: `Updated: ${session.title}` });
  notifyUsers(io, await usersAffectedBy(session), {
    title: 'Schedule change',
    message: `"${session.title}" was updated. Please check the new time and location.`,
    link: '/attendee/agenda',
    type: 'schedule',
  });

  res.json(session);
});

exports.deleteSession = asyncHandler(async (req, res) => {
  const session = await Session.findById(req.params.id);
  if (!session) throw new ApiError(404, 'Session not found');

  const affected = await usersAffectedBy(session);
  await User.updateMany({ bookmarkedSessions: session._id }, { $pull: { bookmarkedSessions: session._id } });
  await session.deleteOne();

  const io = req.app.get('io');
  io.emit('schedule-updated', { expo: String(session.expo), message: `Cancelled: ${session.title}` });
  notifyUsers(io, affected, {
    title: 'Session cancelled',
    message: `"${session.title}" has been cancelled.`,
    link: '/attendee/agenda',
    type: 'schedule',
  });

  res.json({ message: 'Session deleted' });
});

exports.getUsers = asyncHandler(async (req, res) => {
  const search = asString(req.query.search);
  const role = ['admin', 'exhibitor', 'attendee'].includes(req.query.role) ? req.query.role : '';
  const { page, limit, skip } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 50 });

  const filter = {};
  if (role) filter.role = role;
  if (search) {
    const rx = new RegExp(escapeRegex(search.slice(0, 80)), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }
  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).select('name email role createdAt').lean(),
    User.countDocuments(filter),
  ]);

  const companies = await Exhibitor.find({ user: { $in: users.map((u) => u._id) } }).select('user companyName').lean();
  const byUser = new Map(companies.map((c) => [String(c.user), c.companyName]));
  res.json({
    data: users.map((u) => ({ ...u, companyName: byUser.get(String(u._id)) || '' })),
    pagination: paginationMeta(total, page, limit),
  });
});

exports.deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'User not found');
  if (String(user._id) === String(req.user._id)) throw new ApiError(400, 'You cannot delete your own account here');
  if (user.role === 'admin') throw new ApiError(403, 'Organizer accounts cannot be deleted here');

  if (user.role === 'exhibitor') {
    const exhibitor = await Exhibitor.findOne({ user: user._id });
    if (exhibitor) {
      await Booth.updateMany({ exhibitor: exhibitor._id }, { status: 'available', exhibitor: null });
      await Visit.deleteMany({ exhibitor: exhibitor._id });
      await exhibitor.deleteOne();
    }
  } else {
    const regs = await Registration.find({ user: user._id, status: { $ne: 'rejected' } }).select('expo').lean();
    await Promise.all(regs.map((r) => Expo.updateOne({ _id: r.expo, registeredCount: { $gt: 0 } }, { $inc: { registeredCount: -1 } })));
    await Registration.deleteMany({ user: user._id });
    await Session.updateMany({ attendees: user._id }, { $pull: { attendees: user._id } });
    if (user.bookmarkedSessions.length) {
      await Session.updateMany({ _id: { $in: user.bookmarkedSessions }, bookmarkCount: { $gt: 0 } }, { $inc: { bookmarkCount: -1 } });
    }
    await Visit.deleteMany({ attendee: user._id });
  }
  await Promise.all([
    Message.deleteMany({ $or: [{ sender: user._id }, { receiver: user._id }] }),
    Notification.deleteMany({ user: user._id }),
    user.deleteOne(),
  ]);
  req.app.get('io').emit('booths-updated', {});
  res.json({ message: 'User deleted' });
});

const dateRange = (query) => {
  const now = new Date();
  const toParsed = parseDate(asString(query.to));
  const fromParsed = parseDate(asString(query.from));
  let to = toParsed ? new Date(toParsed.getTime() + DAY - 1) : now;
  let from = fromParsed || new Date(to.getTime() - 29 * DAY);
  if (from > to) [from, to] = [to, from];
  if (to - from > 366 * DAY) from = new Date(to.getTime() - 366 * DAY);
  return { from, to };
};

const dailyCounts = (Model, field, from, to, extraMatch = {}) =>
  Model.aggregate([
    { $match: { [field]: { $gte: from, $lte: to }, ...extraMatch } },
    { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: `$${field}` } }, n: { $sum: 1 } } },
  ]);

exports.getAnalytics = asyncHandler(async (req, res) => {
  const { from, to } = dateRange(req.query);
  const now = new Date();
  const published = { status: { $ne: 'draft' } };

  const [
    attendees, exhibitors, totalExpos, draftExpos, upcomingExpos, liveExpos, sessionsTotal, upcomingSessions,
    registrations, messages, boothRows, applicationRows, sessionSums, sessionPopularity, trafficBooths,
    categoryRows, registrationRows, signupRows, recentApps, recentRegs, recentUsers,
  ] = await Promise.all([
    User.countDocuments({ role: 'attendee' }),
    User.countDocuments({ role: 'exhibitor' }),
    Expo.countDocuments(),
    Expo.countDocuments({ status: 'draft' }),
    Expo.countDocuments({ ...published, status: { $nin: ['draft', 'completed'] }, startDate: { $gt: now } }),
    Expo.countDocuments({ status: { $nin: ['draft', 'completed'] }, startDate: { $lte: now }, endDate: { $gte: new Date(now.getTime() - DAY + 1) } }),
    Session.countDocuments(),
    Session.countDocuments({ startTime: { $gt: now } }),
    Registration.countDocuments(),
    Message.countDocuments(),
    Booth.aggregate([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    Exhibitor.aggregate([{ $unwind: '$applications' }, { $group: { _id: '$applications.status', n: { $sum: 1 } } }]),
    Session.aggregate([
      { $group: { _id: null, seats: { $sum: '$capacity' }, tickets: { $sum: { $size: '$attendees' } }, bookmarks: { $sum: '$bookmarkCount' } } },
    ]),
    Session.aggregate([
      { $project: { title: 1, capacity: 1, bookmarks: '$bookmarkCount', tickets: { $size: '$attendees' } } },
      { $addFields: { score: { $add: ['$tickets', '$bookmarks'] } } },
      { $sort: { score: -1 } },
      { $limit: 6 },
    ]),
    Booth.find({ visitorCount: { $gt: 0 } }).sort({ visitorCount: -1 }).limit(6).populate('exhibitor', 'companyName').lean(),
    Expo.aggregate([{ $match: published }, { $group: { _id: '$category', n: { $sum: 1 } } }, { $sort: { n: -1 } }]),
    dailyCounts(Registration, 'createdAt', from, to),
    dailyCounts(User, 'createdAt', from, to, { role: { $ne: 'admin' } }),
    Exhibitor.aggregate([...applicationsPipeline(), { $sort: { appliedAt: -1 } }, { $limit: 6 }]),
    Registration.find().sort({ createdAt: -1 }).limit(6).populate('user', 'name').populate('expo', 'title').lean(),
    User.find({ role: { $ne: 'admin' } }).sort({ createdAt: -1 }).limit(6).select('name role createdAt').lean(),
  ]);

  const booths = { total: 0, available: 0, reserved: 0, booked: 0 };
  boothRows.forEach((r) => { booths[r._id] = r.n; booths.total += r.n; });
  const applications = { pending: 0, approved: 0, rejected: 0 };
  applicationRows.forEach((r) => { applications[r._id] = r.n; });
  const sums = sessionSums[0] || { seats: 0, tickets: 0, bookmarks: 0 };

  const activity = [
    ...recentApps.map((a) => ({ type: 'application', title: `${a.companyName} applied`, detail: a.expoTitle, status: a.status, at: a.appliedAt })),
    ...recentRegs.filter((r) => r.user && r.expo).map((r) => ({ type: 'registration', title: `${r.user.name} registered`, detail: r.expo.title, at: r.createdAt })),
    ...recentUsers.map((u) => ({ type: 'signup', title: `${u.name} joined`, detail: `New ${u.role}`, at: u.createdAt })),
  ]
    .sort((a, b) => new Date(b.at) - new Date(a.at))
    .slice(0, 10);

  res.json({
    range: { from, to },
    totals: {
      attendees, exhibitors, expos: totalExpos, draftExpos, upcomingExpos, liveExpos,
      sessions: sessionsTotal, upcomingSessions, registrations, messages,
      pendingApplications: applications.pending,
      boothsTotal: booths.total, boothsBooked: booths.booked,
      boothVisits: trafficBooths.reduce((s, b) => s + b.visitorCount, 0),
    },
    booths,
    applications,
    sessionStats: {
      seats: sums.seats, tickets: sums.tickets, bookmarks: sums.bookmarks,
      fillRate: sums.seats ? Math.round((sums.tickets / sums.seats) * 100) : 0,
    },
    registrationsSeries: fillSeries(registrationRows, from, to),
    signupsSeries: fillSeries(signupRows, from, to),
    eventsByCategory: categoryRows.map((r) => ({ category: r._id, count: r.n })),
    sessionPopularity: sessionPopularity.map((s) => ({ title: s.title, tickets: s.tickets, bookmarks: s.bookmarks, capacity: s.capacity })),
    boothTraffic: trafficBooths.map((b) => ({
      boothNumber: b.boothNumber,
      company: b.exhibitor ? b.exhibitor.companyName : 'Unassigned',
      visits: b.visitorCount,
    })),
    recentActivity: activity,
  });
});
