require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Expo = require('../models/Expo');
const Registration = require('../models/Registration');

const run = async () => {
  if (!process.env.MONGO_URI) {
    console.error('MONGO_URI is not set.');
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGO_URI);

  let copied = 0;
  const cursor = User.find({ 'registeredExpos.0': { $exists: true } }).select('registeredExpos').cursor();
  for await (const user of cursor) {
    for (const expoId of user.registeredExpos) {
      if (!(await Expo.exists({ _id: expoId }))) continue;
      const result = await Registration.updateOne({ user: user._id, expo: expoId }, { $setOnInsert: { user: user._id, expo: expoId } }, { upsert: true });
      if (result.upsertedCount) copied += 1;
    }
  }

  const counts = await Registration.aggregate([{ $group: { _id: '$expo', n: { $sum: 1 } } }]);
  const byExpo = new Map(counts.map((c) => [String(c._id), c.n]));
  let updated = 0;
  for await (const expo of Expo.find().select('_id registeredCount')) {
    const n = byExpo.get(String(expo._id)) || 0;
    if (expo.registeredCount !== n) {
      await Expo.updateOne({ _id: expo._id }, { registeredCount: n });
      updated += 1;
    }
  }

  console.log(`Migration complete: ${copied} registration(s) copied, ${updated} event counter(s) corrected.`);
  await mongoose.disconnect();
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
