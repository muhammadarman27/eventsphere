const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    receiver: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    expo: { type: mongoose.Schema.Types.ObjectId, ref: 'Expo' },
    type: { type: String, enum: ['message', 'inquiry', 'appointment'], default: 'message' },
    content: { type: String, required: true, trim: true, maxlength: 2000 },
    appointmentSlot: { type: Date },
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);

messageSchema.index({ sender: 1, receiver: 1, createdAt: -1 });
messageSchema.index({ receiver: 1, read: 1 });

module.exports = mongoose.model('Message', messageSchema);
