const mongoose = require('mongoose');

const visitSchema = new mongoose.Schema({
  attendee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  exhibitor: { type: mongoose.Schema.Types.ObjectId, ref: 'Exhibitor', required: true },
  day: { type: String, required: true },
});

visitSchema.index({ attendee: 1, exhibitor: 1, day: 1 }, { unique: true });
visitSchema.index({ exhibitor: 1 });

module.exports = mongoose.model('Visit', visitSchema);
