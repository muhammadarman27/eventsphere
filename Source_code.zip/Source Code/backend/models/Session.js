const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema(
  {
    expo: { type: mongoose.Schema.Types.ObjectId, ref: 'Expo', required: true },
    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 140 },
    description: { type: String, default: '', maxlength: 3000 },
    speaker: {
      name: { type: String, required: true, maxlength: 100 },
      bio: { type: String, default: '', maxlength: 160 },
    },
    location: { type: String, required: true, maxlength: 100 },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    capacity: { type: Number, default: 100, min: 1 },

    attendees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

    bookmarkCount: { type: Number, default: 0, min: 0 },

    reminderSent: { type: Boolean, default: false },
  },
  { timestamps: true }
);

sessionSchema.index({ expo: 1, startTime: 1 });
sessionSchema.index({ attendees: 1, startTime: 1 });
sessionSchema.index({ startTime: 1, reminderSent: 1 });

module.exports = mongoose.model('Session', sessionSchema);
