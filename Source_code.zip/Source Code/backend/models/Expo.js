const mongoose = require('mongoose');
const { CATEGORIES, EXPO_STATUSES } = require('../utils/constants');

const expoSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 120 },
    description: { type: String, default: '', maxlength: 5000 },
    theme: { type: String, default: '', maxlength: 120 },
    category: { type: String, enum: CATEGORIES, default: 'General' },
    banner: { type: String, default: '' },

    location: { type: String, required: [true, 'Location is required'], trim: true, maxlength: 160 },
    venue: { type: String, default: '', trim: true, maxlength: 160 },
    address: { type: String, default: '', trim: true, maxlength: 300 },

    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    openTime: { type: String, default: '09:00' },
    closeTime: { type: String, default: '18:00' },

    status: { type: String, enum: EXPO_STATUSES, default: 'upcoming' },

    capacity: { type: Number, default: 0, min: 0 },
    registeredCount: { type: Number, default: 0, min: 0 },

    floorPlan: {
      rows: { type: Number, default: 4 },
      columns: { type: Number, default: 6 },
    },

    organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    views: { type: Number, default: 0 },
  },
  { timestamps: true }
);

expoSchema.index({ status: 1, startDate: 1 });
expoSchema.index({ category: 1, startDate: 1 });
expoSchema.index({ startDate: 1, endDate: 1 });

module.exports = mongoose.model('Expo', expoSchema);
