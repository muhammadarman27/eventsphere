const mongoose = require('mongoose');

const boothSchema = new mongoose.Schema(
  {
    expo: { type: mongoose.Schema.Types.ObjectId, ref: 'Expo', required: true },
    boothNumber: { type: String, required: true },
    row: { type: Number, required: true },
    column: { type: Number, required: true },
    size: { type: String, enum: ['small', 'medium', 'large'], default: 'small' },
    price: { type: Number, default: 0, min: 0 },
    status: { type: String, enum: ['available', 'reserved', 'booked'], default: 'available' },
    exhibitor: { type: mongoose.Schema.Types.ObjectId, ref: 'Exhibitor', default: null },

    visitorCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

boothSchema.index({ expo: 1, boothNumber: 1 }, { unique: true });
boothSchema.index({ expo: 1, status: 1 });
boothSchema.index({ exhibitor: 1 });

module.exports = mongoose.model('Booth', boothSchema);
