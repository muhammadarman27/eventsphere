const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  expo: { type: mongoose.Schema.Types.ObjectId, ref: 'Expo', required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  booth: { type: mongoose.Schema.Types.ObjectId, ref: 'Booth', default: null },
  note: { type: String, default: '', maxlength: 1000 },
  reviewNote: { type: String, default: '', maxlength: 1000 },
  reviewedAt: Date,
  appliedAt: { type: Date, default: Date.now },
});

const exhibitorSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    companyName: { type: String, required: true, trim: true, maxlength: 100 },
    logo: { type: String, default: '' },
    description: { type: String, default: '', maxlength: 2000 },
    category: { type: String, default: 'General' },
    website: { type: String, default: '' },

    products: [
      {
        name: { type: String, required: true, maxlength: 100 },
        description: { type: String, maxlength: 300 },
        image: String,
      },
    ],

    staff: [
      {
        name: { type: String, required: true, maxlength: 100 },
        email: String,
        position: { type: String, maxlength: 100 },
      },
    ],

    applications: [applicationSchema],
  },
  { timestamps: true }
);

exhibitorSchema.index({ 'applications.expo': 1, 'applications.status': 1 });

module.exports = mongoose.model('Exhibitor', exhibitorSchema);
