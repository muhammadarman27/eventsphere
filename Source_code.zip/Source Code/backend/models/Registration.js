const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    expo: { type: mongoose.Schema.Types.ObjectId, ref: 'Expo', required: true },

    status: { type: String, enum: ['pending', 'confirmed', 'rejected'], default: 'confirmed' },
    day: { type: String, default: '' },
    passType: { type: String, default: '' },

    fullName: { type: String, default: '', maxlength: 120 },
    email: { type: String, default: '', maxlength: 254 },
    phone: { type: String, default: '', maxlength: 30 },
    company: { type: String, default: '', maxlength: 160 },
    jobTitle: { type: String, default: '', maxlength: 160 },
    marketingConsent: { type: Boolean, default: false },
    marketingConsentAt: { type: Date },

    ticketToken: { type: String, select: false },
    checkedInAt: { type: Date },
    emailStatus: { type: String, default: '' },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

registrationSchema.index({ user: 1, expo: 1 }, { unique: true });
registrationSchema.index({ expo: 1, createdAt: -1 });
registrationSchema.index({ createdAt: -1 });
registrationSchema.index({ ticketToken: 1 }, { sparse: true });

module.exports = mongoose.model('Registration', registrationSchema);
