const mongoose = require('mongoose');

const connectDB = () => {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error('MONGO_URI is not set. Copy backend/.env.example to backend/.env first.');
    process.exit(1);
  }

  let attempt = 0;
  const tryConnect = async () => {
    try {
      const conn = await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
      attempt = 0;
      console.log(`MongoDB connected: ${conn.connection.host}`);
    } catch (error) {
      attempt += 1;
      const delay = Math.min(30000, 2000 * attempt);
      console.error(`MongoDB connection failed (${error.message}). Retrying in ${delay / 1000}s...`);
      setTimeout(tryConnect, delay);
    }
  };

  mongoose.connection.on('disconnected', () => console.warn('MongoDB disconnected'));
  mongoose.connection.on('reconnected', () => console.log('MongoDB reconnected'));
  return tryConnect();
};

module.exports = connectDB;
