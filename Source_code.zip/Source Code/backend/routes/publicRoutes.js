const express = require('express');
const c = require('../controllers/publicController');

const router = express.Router();
router.get('/stats', c.getStats);
router.get('/categories', c.getCategories);

module.exports = router;
