const express = require('express');
const c = require('../controllers/messageController');
const { protect } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.use(protect);
router.param('userId', checkObjectId);

router.get('/contacts', c.getContacts);
router.get('/conversations', c.getConversations);
router.get('/unread-count', c.getUnreadCount);
router.get('/thread/:userId', c.getThread);
router.put('/thread/:userId/read', c.markThreadRead);
router.post('/', c.sendMessage);

module.exports = router;
