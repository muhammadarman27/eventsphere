const express = require('express');
const c = require('../controllers/feedbackController');
const { protect, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.param('id', checkObjectId);
router.use(protect);

router.get('/', c.listFeedback);
router.post('/', c.createFeedback);
router.put('/:id', authorize('admin'), c.respondToFeedback);

module.exports = router;
