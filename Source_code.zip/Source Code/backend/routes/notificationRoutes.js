const express = require('express');
const c = require('../controllers/notificationController');
const { protect } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.use(protect);
router.param('id', checkObjectId);

router.get('/', c.getNotifications);
router.put('/read-all', c.markAllRead);
router.put('/:id/read', c.markRead);

module.exports = router;
