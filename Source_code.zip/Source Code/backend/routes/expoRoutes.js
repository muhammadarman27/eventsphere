const express = require('express');
const c = require('../controllers/expoController');
const { protect, optionalAuth, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.param('id', checkObjectId);

router.get('/', optionalAuth, c.getExpos);
router.get('/:id', optionalAuth, c.getExpo);
router.get('/:id/booths', optionalAuth, c.getBooths);
router.get('/:id/sessions', optionalAuth, c.getSessions);
router.get('/:id/exhibitors', optionalAuth, c.getExhibitors);

router.post('/', protect, authorize('admin'), c.createExpo);
router.put('/:id', protect, authorize('admin'), c.updateExpo);
router.delete('/:id', protect, authorize('admin'), c.deleteExpo);
router.get('/:id/registrations', protect, authorize('admin'), c.getRegistrations);

module.exports = router;
