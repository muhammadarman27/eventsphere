const express = require('express');
const c = require('../controllers/attendeeController');
const { protect, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.use(protect, authorize('attendee'));
router.param('id', checkObjectId);

router.get('/agenda', c.getAgenda);
router.post('/expos/:id/register', c.registerForExpo);
router.delete('/expos/:id/register', c.unregisterFromExpo);
router.put('/registrations/:id/consent', c.withdrawConsent);
router.post('/sessions/:id/bookmark', c.toggleBookmark);
router.post('/sessions/:id/book', c.bookTicket);
router.delete('/sessions/:id/book', c.cancelTicket);

module.exports = router;
