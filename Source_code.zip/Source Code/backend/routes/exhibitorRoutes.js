const express = require('express');
const c = require('../controllers/exhibitorController');
const { protect, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.use(protect);
['id', 'boothId', 'applicationId'].forEach((name) => router.param(name, checkObjectId));

router.get('/me', authorize('exhibitor'), c.getMyProfile);
router.put('/me', authorize('exhibitor'), c.updateMyProfile);
router.get('/me/overview', authorize('exhibitor'), c.getOverview);
router.get('/me/schedule', authorize('exhibitor'), c.getSchedule);
router.post('/me/apply', authorize('exhibitor'), c.applyToExpo);
router.delete('/me/applications/:applicationId', authorize('exhibitor'), c.withdrawApplication);
router.post('/me/reserve', authorize('exhibitor'), c.reserveBooth);
router.delete('/me/reserve/:boothId', authorize('exhibitor'), c.releaseBooth);

router.post('/:id/visit', authorize('attendee'), c.recordVisit);

module.exports = router;
