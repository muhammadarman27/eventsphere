const express = require('express');
const c = require('../controllers/uploadController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();
router.post('/sign', protect, authorize('admin', 'exhibitor'), c.signUpload);

module.exports = router;
