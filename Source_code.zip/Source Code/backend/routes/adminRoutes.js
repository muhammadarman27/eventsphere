const express = require('express');
const c = require('../controllers/adminController');
const r = require('../controllers/registrationController');
const { protect, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.use(protect, authorize('admin'));
['id', 'exhibitorId', 'applicationId'].forEach((name) => router.param(name, checkObjectId));

router.get('/applications', c.getApplications);
router.put('/applications/:exhibitorId/:applicationId', c.reviewApplication);

router.put('/booths/:id', c.updateBooth);
router.put('/booths/:id/assign', c.assignBooth);
router.put('/booths/:id/release', c.releaseBooth);

router.post('/sessions', c.createSession);
router.put('/sessions/:id', c.updateSession);
router.delete('/sessions/:id', c.deleteSession);

router.get('/users', c.getUsers);
router.delete('/users/:id', c.deleteUser);

router.get('/registrations', r.listRegistrations);
router.put('/registrations/:id', r.reviewRegistration);
router.post('/check-in', r.checkIn);

router.get('/analytics', c.getAnalytics);

module.exports = router;
