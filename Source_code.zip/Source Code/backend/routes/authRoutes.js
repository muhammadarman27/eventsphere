const express = require('express');
const c = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const { loginLimiter, sensitiveLimiter } = require('../middleware/rateLimit');

const router = express.Router();

router.post('/register', sensitiveLimiter, c.register);
router.post('/login', loginLimiter, c.login);
router.post('/forgot-password', sensitiveLimiter, c.forgotPassword);
router.put('/reset-password/:token', sensitiveLimiter, c.resetPassword);

router.get('/me', protect, c.getMe);
router.put('/profile', protect, c.updateProfile);
router.put('/password', protect, sensitiveLimiter, c.changePassword);

module.exports = router;
