const express = require('express');
const c = require('../controllers/registrationController');
const { protect, authorize } = require('../middleware/auth');
const checkObjectId = require('../middleware/validateId');

const router = express.Router();
router.param('id', checkObjectId);
router.get('/:id', protect, authorize('attendee', 'admin'), c.getTicket);

module.exports = router;
