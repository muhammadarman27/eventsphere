require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Expo = require('./models/Expo');
const Exhibitor = require('./models/Exhibitor');
const Booth = require('./models/Booth');
const Session = require('./models/Session');
const Message = require('./models/Message');
const Registration = require('./models/Registration');
const Notification = require('./models/Notification');
const Visit = require('./models/Visit');

const DAY = 24 * 60 * 60 * 1000;
const force = process.argv.includes('--force');

const utcMidnight = (offsetDays) => {
  const d = new Date(Date.now() + offsetDays * DAY);
  d.setUTCHours(0, 0, 0, 0);
  return d;
};

const run = async () => {
  if (process.env.NODE_ENV === 'production') {
    console.error('Refusing to seed: NODE_ENV is production. The seed script is for local development only.');
    process.exit(1);
  }
  if (!process.env.MONGO_URI) {
    console.error('MONGO_URI is not set. Copy backend/.env.example to backend/.env first.');
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGO_URI);

  const existing = await User.countDocuments();
  if (existing > 0 && !force) {
    console.error(`The database already has ${existing} user(s). Nothing was changed.`);
    console.error('Run "npm run seed -- --force" if you really want to DELETE all data and start over.');
    process.exit(1);
  }
  const models = [User, Expo, Exhibitor, Booth, Session, Message, Registration, Notification, Visit];
  await Promise.all(models.map((m) => m.deleteMany({})));

  const admin = await User.create({ name: 'Aisha Organizer', email: 'admin@eventsphere.test', password: 'admin1234', role: 'admin' });
  const u1 = await User.create({ name: 'Bilal Khan', email: 'exhibitor@eventsphere.test', password: 'exhibitor123', role: 'exhibitor' });
  const u2 = await User.create({ name: 'Sana Malik', email: 'exhibitor2@eventsphere.test', password: 'exhibitor123', role: 'exhibitor' });
  const u3 = await User.create({ name: 'Imran Qureshi', email: 'exhibitor3@eventsphere.test', password: 'exhibitor123', role: 'exhibitor' });
  const a1 = await User.create({ name: 'Hamza Attendee', email: 'attendee@eventsphere.test', password: 'attendee123', role: 'attendee' });
  const a2 = await User.create({ name: 'Zara Ahmed', email: 'attendee2@eventsphere.test', password: 'attendee123', role: 'attendee' });
  const a3 = await User.create({ name: 'Omar Farooq', email: 'attendee3@eventsphere.test', password: 'attendee123', role: 'attendee' });

  const makeExpo = async (fields, rows, columns) => {
    const expo = await Expo.create({ organizer: admin._id, floorPlan: { rows, columns }, ...fields });
    const grid = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < columns; c++) {
        grid.push({
          expo: expo._id,
          boothNumber: `${String.fromCharCode(65 + r)}${c + 1}`,
          row: r,
          column: c,
          size: r === 0 ? 'large' : 'small',
          price: r === 0 ? 1500 : 800,
        });
      }
    }
    const booths = await Booth.insertMany(grid);
    return { expo, booths };
  };

  const tech = await makeExpo({
    title: 'TechExpo Karachi 2026', theme: 'AI for Everyone', category: 'Technology',
    location: 'Karachi', venue: 'Expo Centre', address: 'University Road, Karachi',
    description: 'Three days of products, talks and networking for the technology community. Meet the teams building the next generation of cloud, AI and security tools.',
    startDate: utcMidnight(14), endDate: utcMidnight(16), openTime: '10:00', closeTime: '18:00', capacity: 500,
  }, 4, 6);
  const health = await makeExpo({
    title: 'Health & Wellness Summit', theme: 'Prevention first', category: 'Healthcare',
    location: 'Lahore', venue: 'Pearl Convention Hall', address: 'Main Boulevard, Lahore',
    description: 'Clinicians, startups and suppliers share what is working in preventive care.',
    startDate: utcMidnight(40), endDate: utcMidnight(41), openTime: '09:00', closeTime: '17:00', capacity: 0,
  }, 3, 5);
  const food = await makeExpo({
    title: 'Future of Food 2026', theme: 'Local ingredients', category: 'Food & Beverage',
    location: 'Islamabad', venue: 'Jinnah Convention Centre', address: 'Constitution Avenue, Islamabad',
    description: 'A look at the people making food supply chains shorter and fairer.',
    startDate: utcMidnight(-30), endDate: utcMidnight(-28), capacity: 300,
  }, 3, 5);
  await makeExpo({
    title: 'Fashion Forward (draft)', theme: 'Sustainable textiles', category: 'Fashion',
    location: 'Karachi', venue: 'To be confirmed', status: 'draft',
    description: 'Not published yet: only organizers can see this event.',
    startDate: utcMidnight(90), endDate: utcMidnight(92),
  }, 3, 5);

  const nova = await Exhibitor.create({
    user: u1._id, companyName: 'NovaByte Systems', category: 'Technology',
    description: 'Cloud tools and AI assistants for small businesses.', website: 'https://example.com',
    products: [
      { name: 'NovaDesk', description: 'Customer support inbox with AI replies' },
      { name: 'NovaSync', description: 'Real-time file sync for teams' },
    ],
    staff: [{ name: 'Bilal Khan', email: 'exhibitor@eventsphere.test', position: 'Founder' }],
    applications: [
      { expo: tech.expo._id, status: 'approved', booth: tech.booths[1]._id, note: 'We would like a corner booth for live demos.', reviewedAt: new Date() },
      { expo: health.expo._id, status: 'pending', note: 'Our clinic scheduling tools fit this audience.' },
    ],
  });
  await Booth.findByIdAndUpdate(tech.booths[1]._id, { status: 'booked', exhibitor: nova._id, visitorCount: 12 });

  const green = await Exhibitor.create({
    user: u2._id, companyName: 'GreenLeaf Foods', category: 'Food & Beverage',
    description: 'Organic snacks made from local ingredients.',
    products: [{ name: 'Date Bars', description: 'No added sugar' }],
    applications: [
      { expo: tech.expo._id, status: 'pending', booth: tech.booths[8]._id },
      { expo: food.expo._id, status: 'approved', booth: food.booths[2]._id, reviewedAt: new Date() },
    ],
  });
  await Booth.findByIdAndUpdate(tech.booths[8]._id, { status: 'reserved', exhibitor: green._id });
  await Booth.findByIdAndUpdate(food.booths[2]._id, { status: 'booked', exhibitor: green._id, visitorCount: 5 });

  await Exhibitor.create({
    user: u3._id, companyName: 'Vitalis Health', category: 'Healthcare',
    description: 'Remote monitoring devices for chronic care.',
    products: [{ name: 'Vitalis Band', description: 'Wearable heart-rate and sleep tracker' }],
    applications: [{ expo: health.expo._id, status: 'rejected', reviewNote: 'Booth limits reached for this category.', reviewedAt: new Date() }],
  });

  const at = (expo, days, hour) => new Date(expo.startDate.getTime() + days * DAY + hour * 60 * 60 * 1000);
  const [s1, s2, s3] = await Session.insertMany([
    { expo: tech.expo._id, title: 'Opening Keynote: AI for Everyone', speaker: { name: 'Dr. Farah Ahmed', bio: 'AI researcher' }, location: 'Main Hall', startTime: at(tech.expo, 0, 10), endTime: at(tech.expo, 0, 11), capacity: 200 },
    { expo: tech.expo._id, title: 'Building Your First Startup', speaker: { name: 'Omar Siddiqui', bio: 'Serial founder' }, location: 'Room B', startTime: at(tech.expo, 0, 12), endTime: at(tech.expo, 0, 13), capacity: 60 },
    { expo: tech.expo._id, title: 'Cloud Security Basics', speaker: { name: 'Nida Raza', bio: 'Security engineer' }, location: 'Room C', startTime: at(tech.expo, 1, 11), endTime: at(tech.expo, 1, 12), capacity: 40 },
  ]);
  await Session.insertMany([
    { expo: health.expo._id, title: 'Preventive Care in Practice', speaker: { name: 'Dr. Hira Baig', bio: 'Family physician' }, location: 'Hall 1', startTime: at(health.expo, 0, 10), endTime: at(health.expo, 0, 11), capacity: 120 },
    { expo: health.expo._id, title: 'Wearables and Patient Privacy', speaker: { name: 'Tariq Mehmood', bio: 'Health-tech lawyer' }, location: 'Hall 2', startTime: at(health.expo, 0, 14), endTime: at(health.expo, 0, 15), capacity: 80 },
  ]);

  const firstDay = (e) => new Date(e.startDate).toISOString().slice(0, 10);
  const person = (u, company, jobTitle) => ({ fullName: u.name, email: u.email, phone: '+92 300 1234567', company, jobTitle });
  await Registration.insertMany([
    { user: a1._id, expo: tech.expo._id, status: 'confirmed', day: firstDay(tech.expo), passType: 'trade', ...person(a1, 'Acme Traders', 'Procurement Lead'), ticketToken: require('crypto').randomBytes(32).toString('hex') },
    { user: a2._id, expo: tech.expo._id, status: 'confirmed', day: firstDay(tech.expo), passType: 'conference', ...person(a2, 'Indus Labs', 'Software Engineer'), ticketToken: require('crypto').randomBytes(32).toString('hex') },
    { user: a3._id, expo: food.expo._id, status: 'confirmed', day: firstDay(food.expo), passType: 'media', ...person(a3, 'Karachi Bites', 'Food Blogger'), ticketToken: require('crypto').randomBytes(32).toString('hex') },
    { user: a3._id, expo: health.expo._id, status: 'pending', day: firstDay(health.expo), passType: 'trade', ...person(a3, 'Karachi Bites', 'Food Blogger') },
  ]);
  await Expo.updateOne({ _id: tech.expo._id }, { registeredCount: 2 });
  await Expo.updateOne({ _id: food.expo._id }, { registeredCount: 1 });
  await Expo.updateOne({ _id: health.expo._id }, { registeredCount: 1 });

  await Session.updateOne({ _id: s1._id }, { $addToSet: { attendees: { $each: [a1._id, a2._id] } }, bookmarkCount: 1 });
  await Session.updateOne({ _id: s3._id }, { bookmarkCount: 1 });
  await User.updateOne({ _id: a1._id }, { bookmarkedSessions: [s3._id] });
  await User.updateOne({ _id: a2._id }, { bookmarkedSessions: [s1._id] });

  await Message.insertMany([
    { sender: a1._id, receiver: u1._id, content: 'Hi! Will you be demoing NovaDesk at the expo?', type: 'inquiry', read: true },
    { sender: u1._id, receiver: a1._id, content: 'Yes, every day at booth A2. Come say hello!', read: false },
  ]);
  await Notification.insertMany([
    { user: u1._id, title: 'Application approved', message: 'Your application for "TechExpo Karachi 2026" was approved.', link: '/exhibitor/booths', type: 'application' },
    { user: admin._id, title: 'New application', message: 'GreenLeaf Foods applied for "TechExpo Karachi 2026".', link: '/admin/applications', type: 'application' },
    { user: a1._id, title: 'Welcome to EventSphere', message: 'Browse events, register and build your agenda.', link: '/attendee/events', type: 'info' },
  ]);

  console.log('Seed complete. Demo logins (local development only):');
  console.log('  admin@eventsphere.test       / admin1234');
  console.log('  exhibitor@eventsphere.test   / exhibitor123  (approved, booth A2)');
  console.log('  exhibitor2@eventsphere.test  / exhibitor123  (pending application)');
  console.log('  exhibitor3@eventsphere.test  / exhibitor123  (rejected application)');
  console.log('  attendee@eventsphere.test    / attendee123  (also attendee2, attendee3)');
  await mongoose.disconnect();
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
